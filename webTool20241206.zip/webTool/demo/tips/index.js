define([
    "$",
    "@/tips/index",
], function ($, Tips) {
        new Tips(".tips", {})
})
