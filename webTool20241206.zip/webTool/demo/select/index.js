define([
    "@/select/index"
], function () {


})
