define([
    "$",
    "@/listButton/index",
    "util/request/ajax",
], function ($, listButton, ajax) {

        listButton({
            list: [
                { name: "12",key:"/ddd/ddd"},
                { name: "12", key: "/ddd/ddd" },
                { name: "12", key: "/ddd/ddd" },
                { name: "12", key: "/ddd/ddd" },

            ],
            isShowChild:false,
            ele: $(".list_menu"),
            callBack: function (ele) {
                ajax({
                    url: ele.dataset.url,
                    success: function (res) {
                      //  alert(ele.dataset.url)
                    },
                    error: function (res) {
                      //  alert(res)
                    },
                    finally: function (res) {
                      // alert("finally")
                    },

                })
            }
        })
})
