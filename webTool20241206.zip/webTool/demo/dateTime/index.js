define([
    "@/dateTime/index"
], function (DateTime) {
        new DateTime(".date", {})

})
