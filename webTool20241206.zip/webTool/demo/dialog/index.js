define([
    "$",
    "@/dialog/index",
    "util/request/ajax",
], function ($, dialog, ajax) {


        dialog.alert("fff");
})
