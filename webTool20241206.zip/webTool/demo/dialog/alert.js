define([
    "$",
    "@/dialog/alert",
    "util/request/ajax",
], function ($, alert, ajax) {

        alert({
            messsage: "ff",
            type:"normal"
        });
})
