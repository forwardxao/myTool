define([
    "@/clickEffect/index"
], function (clickEffect) {

        clickEffect();
})
