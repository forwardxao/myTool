define([
    "@/waterMark/index"
], function (waterMark) {
        waterMark({txt: `机密文集,请勿泄密<br>水印提示`})
})