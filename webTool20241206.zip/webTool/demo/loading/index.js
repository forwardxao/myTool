define([
    "@/loading/loading"
], function () {


})
