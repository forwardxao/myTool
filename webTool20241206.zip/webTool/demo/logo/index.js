define([
    "@/logo/index",
    "util/request/ajax",
], function (logo, ajax) {
        logo(".logo",{})
})
