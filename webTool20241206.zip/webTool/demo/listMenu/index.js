define([
    "@/listMenu/index",
    "util/request/ajax",
], function (listMenu, ajax) {

        listMenu(".list_menu",{
            isShowChild:false,
            callBack: function (ele) {
                ajax({
                    url: ele.dataset.url,
                    success: function (res) {
                      //  alert(ele.dataset.url)
                    },
                    error: function (res) {
                      //  alert(res)
                    },
                    finally: function (res) {
                      // alert("finally")
                    },

                })
            }
        })


})
