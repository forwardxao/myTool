define([
    "$",
    "@/tips/index",
], function ($, LightTip) {
        new LightTip(".tips", {})
})
