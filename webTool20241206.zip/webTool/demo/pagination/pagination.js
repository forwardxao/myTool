define([
    "$",
    "@/pagination/pagination"
], function ($, pagination) {

        new pagination($(".pagination"),{
            count: 100,
            limit: 10,
             callBack: function (page) {
              //  alert("")
            
            }
        })();

})
