define([
    "@/pagination/index"
], function (pagination) {
         pagination(".pagination",{
            count: 100,
            limit: 10,
             callBack: function (page) {
              //  alert("")
            
            }
        });

})
