require.config({
    // urlArgs: "refreshCache=" + (localStorage.getItem("refreshCache") || (new Date().getDate()+""+new Date().getHours())),
    urlArgs: "refreshCache=" + new Date().getTime(),
    baseUrl: "../../",
    paths: {
        "@": "component",
        '$': 'util/Dom/selector' // 
    },
    map: {
        '*': {
            'css': 'util/module/css', // or whatever the path to require-css is
        }
    }
});

require(["@/url/index"]);