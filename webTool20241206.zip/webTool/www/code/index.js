﻿define([
    "util/request/ajax",
    "@/listMenu/index",
    "util/url/getUrlKey",
    "util/url/addParam",
    "util/copy/copyText",
    "util/Dom/title",
    "util/event/on",
    "$"
    ],
    function (ajax, ListMenu, getUrlKey, addParam,copyText, Title, on, $) {

        let listMenu;
        let title = Title();
        function getMenu() {
            ajax({
                url: "/contents.json",
                dataType:"json",
                success: function (res) {
                    listMenu = ListMenu(".listMenu", {
                        list: res,
                        callBack: function (ele, item) {
                            getContent(item)
                        }
                    })

                    listMenu.setActiveByPath(getUrlKey("path"));
                },
            })
        }

        let copyToClipboard = "";
        function getContent(item) {
            if (!item.url) {return; }
            title.set(item.url);
                ajax({
                    url: "/util/Dom/" + item.url,
                    success: function (res) {
                        $(".mt_content").html(`<div class="copyToClipboard scale8"><img src="/source/svg/copy.svg"/></div><pre class="pre">${res}</pre>`);
                        copyToClipboard=res
                    },
                })
            addParam("path", item.path)            
        }


        document.querySelector(".mt_content").on("click", ".copyToClipboard", function () {
            copyText(copyToClipboard);
        });

        title.prefix("js常用工具库");
        getMenu();
});
