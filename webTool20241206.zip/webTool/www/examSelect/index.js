﻿define([
    "util/request/ajax",
    "@/header/index",
    "@/drawer/index",
    "@/loading/loading",



    "util/url/getUrlKey",
    "util/url/addParam",
    "util/audio/play",
    "util/Dom/title",

    "www/examSelect/examItem",
    "www/examSelect/subjectTypeObject",
    "www/examSelect/content",
    "util/event/eventEmitter",
    "util/data/randomArray",
],
    function (ajax, Header, Drawer, Loading, getUrlKey, addParam, audioPlay, Title, ExamItem, subjectTypeObject, Content, eventEmitter, randomArray) {

        let title = Title();
        let drawer = Drawer(".drawerContainer", {
           // show:true
        });
       let header= Header(".headerContainer", {
            right: {
                callBack: function (ele) {
                    drawer.toggle();
                }
            }
        })
        let content = Content(".contentContainer");


        let examItem = ExamItem(".examContainer", {});
        let loading = Loading(".loadingContainer");

        

        let data = {
            "subjectType": "",
            "mp3List": [],
            "headerTitle": "",
            "otherInfo": {
                "left": 100,
                "top": 100,
                "nextIndex": 0,
                "currentIndex": 0,
                "editMenu": false,
                "isSelectTest": false, //选择了答案
                "showCompleteTest": false, //完场测试
                "isViewAnswer": false,
                "resultText": "你答对了 23/50 题",
                "testProgress": "0",
                "testProgressStyle": "width:0",
                "correctNum": 0,
                "correctPercent": 0,
                "correctPercentStyle": "width:0;",

                "showDrawer": false,
                "rightValue": "",
                "questions": '',
                "hardLevel": '1'
            },

            isCanEditAnswerKey: "",
            "selectList": [],
            "answerList": [],
            "toolList": [
                {
                    id: '1',
                    name: '目录',
                    selected: false
                },
                {
                    id: '2',
                    name: '索引',
                    selected: false
                },

                {
                    id: '3',
                    name: '搜索',
                    selected: false
                },

                {
                    id: '4',
                    name: '分析',
                    selected: false
                }
            ],
            "htmlContent": ""
        }
        let methods = {
            init: function () {
                let that = this;
                this.getFilter();
                this.getMp3List();

                eventEmitter.on("filterCardConfirm", (dataList) => {
                    that.makeSelectList(dataList)
                    data.otherInfo.showCompleteTest = false;
                    data.otherInfo.showDrawer = false;
                    data.otherInfo.nextIndex = 0;
                   
                    drawer.hide();

                });

                eventEmitter.on("getNextTest", (dataList) => {
                    that.selectList = [].concat(dataList)
                    that.getNextTest()
                });
            },
            getFilter: function () {
                let that = this;
                data.subjectType = getUrlKey("subjectType") || "addition"
                let subjectType = localStorage.getItem("subjectType")
                    if (data.subjectType !== subjectType) {
                    localStorage.setItem("selectList", "[]");
                }


                if (!subjectTypeObject[data.subjectType]) {
                    data.subjectType = "addition"
                }
                let item = subjectTypeObject[data.subjectType];
                title.set(item.title)

                localStorage.setItem("subjectType", data.subjectType)
                examItem.set("type", data.subjectType)

                data["isCanEditAnswerKey"] = localStorage.getItem("isCanEditAnswerKey")
                require([item.url], function (DrawerContent) {
                    DrawerContent(".m-drawer .content", {});
                })


               // data.$eventBus.$emit("dataUrlChange", url);
            },
            getMp3List: function () {
                let that = this;
                ajax({
                    url: "/source/mp3/tips/0.json",
                    method: "get",
                    dataType: "json",
                    data: {},
                    "originalData": true,
                    "originalUrl": true,
                    success: function (result) {
                        data.mp3List = [].concat(result)
                    },
                    error: function (error) {
                    }
                })
            },
            getMax: function () {
                return 100
            },
            degreeOfDifficultyChange: function (selectItem) {
                //  return 10
            },

            mathSelectFun: function (item) {
                let that = this;
                if (data.otherInfo.isSelectTest) {
                    return
                }
                data.otherInfo.isSelectTest = true;
                setTimeout(function () {
                    let mathObject = data.selectList[data.otherInfo.nextIndex - 1];
                    mathObject["selectItem"] = Object.assign(item);
                    for (let i = 0, len = data.answerList.length; i < len; i++) {

                        data.answerList[i]["selectAnswerResultIcon"] = " ";
                        data.answerList[i]["selectAnswerResultClass"] = " ";

                        if (mathObject["rightValue"] === data.answerList[i]["value"]) {
                            data.answerList[i]["selectAnswerClass"] = "rightSelect"
                        } else {
                            data.answerList[i]["selectAnswerClass"] = "errorSelect"
                        }
                    }

                    if (mathObject["rightValue"] === item["value"]) {
                        item.selectAnswerResultIcon = " el-icon-check";
                        mathObject["selectResult"] = "right";
                        audioPlay.play('/source/mp3/tips/right.mp3')

                    } else {
                        audioPlay.play('/source/mp3/tips/error.mp3')
                        item.selectAnswerResultIcon = " el-icon-close";
                        item.selectAnswerResultClass = " selectError";
                        mathObject["selectResult"] = "error";
                    }

                    if (data.otherInfo.nextIndex === data.selectList.length) {
                        // done the last question but not done all question
                        let notDoneNumber = 0;
                        for (let i = 0, len = data.selectList.length; i < len; i++) {
                            if (!data.selectList[i]["selectResult"]) {
                                data.otherInfo.nextIndex = i;
                                break;
                            }
                        }
                    }
                    else {
                        let completeQuestionFlag = true;
                        for (let i = 0, len = data.selectList.length; i < len; i++) {
                            if (!data.selectList[i]["selectResult"]) {
                                data.otherInfo.nextIndex = i;
                                completeQuestionFlag = false;
                                break;
                            }
                        }
                        if (completeQuestionFlag) {
                            data.otherInfo.nextIndex = data.selectList.length
                        }
                    }

                    localStorage.setItem("selectList", JSON.stringify(data.selectList))
                    //data.selectList[data.otherInfo.nextIndex-1]["answerList"]=[].concat(data.answerList);
                    setTimeout(function () {
                        //mathObject["answerList"]=[].concat(data.answerList);
                        data.getNextTest()
                    }, 1500)
                }, 500);
            },


            retryTestFun: function (item) {
                let that = this;
                data.otherInfo.isSelectTest = false;
                data.otherInfo.nextIndex = 0;
                loading.show();
                audioPlay.pause();

                setTimeout(function () {
                    localStorage.setItem("selectList", "[]")
                    data.$eventBus.$emit("getSelectList")
                }, 1000);
            },

            viewAnswerFun: function (item) {
                let that = this;
                data.otherInfo.isViewAnswer = true;
            },

            hideAnswerFun: function (item) {
                let that = this;
                data.otherInfo.isViewAnswer = false;
            },

            openSetFun: function (item) {
                let that = this;
                data.otherInfo.showDrawer = true;
            },


            makeSelectList: function (result) {
                let that = this;
                if (!(result instanceof Array)) {
                    result = []
                }
                result.forEach(v => {
                    v["selectItem"] = {};
                    v["selectResult"] = "";
                    v["answerList"].forEach(v2 => {
                        v2["selectAnswerClass"] = "";
                        v2["selectAnswerResultClass"] = "";
                        v2["selectAnswerResultIcon"] = "";
                    });
                });


                data.selectList = randomArray(result);
                that.getNextTest()
            },


            getSrc: function (type) {
                let that = this;
                let list = [];
                data.mp3List.forEach(v => {
                    if (v["type"] !== type) {
                        return;
                    }
                    list.push(v)
                })
                if (list.length < 1) {
                    return ""
                }
                let _object = list[window.$randomNumber(0, list.length - 1)];
                return _object["src"]
            },

            getNextTest: function () {
                let that = this, _object = {};
                if (data.otherInfo.nextIndex === data.selectList.length) {
                    that.getLastTest()
                    return
                }

                data.otherInfo.isSelectTest = false;

                loading.show();
                

                setTimeout(function () {
                    _object =data.selectList[data.otherInfo.nextIndex];
                    data.otherInfo.questions = _object["questions"];
                    data.answerList = _object["answerList"] || [];
                    data.otherInfo.currentIndex = data.otherInfo.nextIndex;
                    if (_object["selectItem"]["optionLetter"]) {
                        //already done this question
                        data.answerList.forEach(v => {
                            if (_object["selectItem"]["optionLetter"] === v["optionLetter"]) {
                                if (_object["rightValue"] === v["value"]) {
                                    v["selectAnswerResultIcon"] = "el-icon-check"
                                } else {
                                    v["selectAnswerResultIcon"] = "el-icon-close"
                                }
                            }
                        });
                    }

                    data.otherInfo.rightValue = _object["rightValue"];


                    examItem.refresh({
                        title: _object["questions"],
                        list: data.answerList
                    })

                    data.otherInfo.nextIndex++;
                    loading.hide();
                    let selectNumber = 0;
                    data.selectList.forEach(v => {
                        if (v["selectResult"]) {
                            // if this have select an option  selectNumber need add one
                            selectNumber++;
                        }
                    });

                    if (selectNumber < data.selectList.length) {
                        selectNumber++;
                    }

                    data.otherInfo.testProgress = parseFloat(100 * (selectNumber) / data.selectList.length).toFixed(1);
                    data.otherInfo.testProgressStyle = "width:" + data.otherInfo.testProgress + "%";
                }, 500)
            },


            getLastTest: function () {
                data.otherInfo.correctNum = 0;
                for (let i = 0, len = data.selectList.length; i < len; i++) {
                    if (data.selectList[i]["selectResult"] === "right") {
                        data.otherInfo.correctNum++
                    }
                }
                data.otherInfo.resultText = "你答对了 " + data.otherInfo.correctNum + "/" + data.selectList.length + " 题";

                let percent = parseFloat(100 * data.otherInfo.correctNum / data.selectList.length)
                let type = ""
                if (percent > 90) {
                    type = '/source/mp3/tips/all.right.mp3';
                } else if (percent > 70) {
                    type = '/source/mp3/tips/very.good.mp3';
                } else {
                    type = '/source/mp3/tips/notGood.mp3';
                }


                audioPlay.play(type)

                data.otherInfo.correctPercent = parseFloat(100 * data.otherInfo.correctNum / data.selectList.length).toFixed(1)
                data.otherInfo.correctPercentStyle = "width:" + data.otherInfo.correctPercent + "%";
                data.otherInfo.showCompleteTest = true;
                data.otherInfo.currentIndex = null;
            },

            getSelectItem: function (data) {
                let that = this;
                if (!(data instanceof Object)) {
                    return;
                }
                if (!data["id"]) {
                    return;
                }
                if (data.isCanEditAnswerKey === "disable") {
                    if (data["selectResult"]) {
                        return;
                    }
                }

                let len = data.selectList.length;
                for (let i = 0; i < len; i++) {
                    if (data["id"] === data.selectList[i]["id"]) {
                        data.otherInfo.nextIndex = i;
                        break;
                    }
                }

                if (data.otherInfo.showCompleteTest) {
                    data.otherInfo.showCompleteTest = false
                }
                data.getNextTest()
            },
        }
        methods.init();
       // drawer.setHtml(`sss`)
        
    });




