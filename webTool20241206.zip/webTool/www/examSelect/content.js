define([
    "css!./content.css",
    "util/data/returnValueByBool",
    "util/newFun/newObject",
    "util/copy/deepMerge",
    "util/event/eventEmitter"
],
    function (css, returnValueByBool, newObject, deepMerge, eventEmitter) {

        function Fun(param) {
            let that = this
            that.options = {
                ele: null,
                title: '标题',
                contentWidth: "80%",
                "position": "",
                "boxShadow": "",
            }
            deepMerge(that.options, param)

            that.options.ele.on("click", ".left", function (ele) {
                that.toggle();
            })

            that.options.ele.on("click", ".gua-navigation", function (ele) {
                that.toggle();
                let index = parseInt(ele.dataset.index || 0);
                eventEmitter.emit("guaIndex", index)
            })

        }
        Fun.prototype.refresh = function (otherInfo) {

            let html = `
                <div class="content">
                    <div class="math-content ${returnValueByBool("isSelect", otherInfo.isSelectTest)} ${otherInfo.subjectType||""}">
                        <div class="questions" >${otherInfo.questions}</div>
                        <div class="mathSelect-list">${getList(otherInfo,answerList)}</div>
                        <div class="loading ${returnValueByBool('isLoading',otherInfo.isLoading)}" >
                            <span class="icon-loading">
                                <img src="/source/svg/loading.svg" alt="加载..." class="icon-loading"/>
                            </span>
                        </div>
                        <div class="completeTest ${returnValueByBool("showCompleteTest", otherInfo.showCompleteTest)}">
                            <div class="resultProgress">
                                <div>
                                    <span style="${otherInfo.correctPercentStyle}"></span>
                                </div>
                                <div>
                                    <img src="/source/svg/start.yellow.svg" alt=""/>
                                </div>
                            </div>
                            <div class="resultText">${otherInfo.resultText}</div>
                            <div class="retry">
                                <div  class="retryTest">
                                    <img src="/source/svg/refresh.grey.svg" alt="查看"/>
                                    <span>重试</span>
                                </div>
                                <div></div>
                                <div  class="viewAnswer">
                                    <img src="/source/svg/view.grey.svg" alt="查看"/>
                                </div>
                            </div>
                            <div>

                            </div>
                        </div>
                    </div>
                    <div class="test-progress">
                        <span :style="${otherInfo.testProgressStyle}" ></span>
                    </div>
                </div>
            `
            this.options.ele.innerHTML = html;
            function getList(list) {
                let html = ``;
                for (let i = 0, len = list.length; i < len; i++) {
                    let v = list[i];
                    html += `
                            <div  class="selectItem ${v["selectAnswerClass"]} ${v["selectAnswerResultClass"]}" >
                                <span class="selectOptionLetter">${v.optionLetter}</span>
                                <div class="x-fill-auto textNumber">${v.name}}</div>
                                <span class="${v.selectAnswerResultIcon}"></span>
                            </div>
                    `
                }
                return html;
            }
        }
        Fun.prototype.toggle = function () {
          //  let ele = this.ele.querySelector(".navigation-container");
          //  ele.classList.toggle("active");
        }

        return function (selecor, param = {}) {
            return newObject(selecor, param, Fun);
        }
    });





