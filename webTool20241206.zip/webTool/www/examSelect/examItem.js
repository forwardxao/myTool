define([
    "css!./examItem.css",
    "util/data/returnValueByBool",
    "util/newFun/newObject",
    "util/copy/deepMerge",
    "util/event/eventEmitter"
],
    function (css, returnValueByBool, newObject, deepMerge, eventEmitter) {

        function Fun(param) {
            let that = this
            that.options = {
                ele: null,
                title: '标题',
                type:"addition",
                list:[],
            }
            deepMerge(that.options, param)
            that.options.ele.on("click", ".left", function (ele) {
                that.toggle();
            })

        }
        Fun.prototype.set = function (key,val) {
            let that = this
            that.options[key]=val
        
        }
        Fun.prototype.refresh = function (param) {
            let that = this
            let html = `
                <div class="examItem ${getClass()}">
                    <div class="questions" >${param.title}</div>
                    <div class="mathSelect-list">${getList(param.list)}</div>
                </div>
            `
            this.options.ele.innerHTML = html;
            function getList(list=[]) {
                let html = ``;
                for (let i = 0, len = list.length; i < len; i++) {
                    let v = list[i];
                    html += `
                            <div  class="selectItem ${v["selectAnswerClass"]} ${v["selectAnswerResultClass"]}" >
                                <span class="selectOptionLetter">${v.optionLetter}</span>
                                <div class="x-fill-auto textNumber">${v.name}</div>
                                <span class="${v.selectAnswerResultIcon}"></span>
                            </div>
                    `
                }
                return html;
            }

            function getClass() {

                return that.options.type
            }
        }
        return function (selecor, param = {}) {
            return newObject(selecor, param, Fun);
        }
    });





