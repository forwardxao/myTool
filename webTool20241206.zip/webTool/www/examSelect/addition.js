define([
    "css!@/btn/index.css",
    "css!./addition.css",
    "util/data/returnValueByBool",
    "util/data/JSONParse",
    "util/data/genId",
    "util/data/randomNumber",
    "util/data/randomArray",
    "util/newFun/newObject",
    "util/copy/deepMerge",
    "util/event/eventEmitter",
    "@/listButton/index",
    "@/inputNumber/index",
],
    function (btn,css, returnValueByBool, JSONParse, genId, randomNumber, randomArray, newObject, deepMerge, eventEmitter, ListButton, InputNumber) {
        function Fun(param) {
            let that = this
            that.options = {
                "ele": null,
                "degreeOfDifficultyList": [
                    {"text": "简单", key: "simple"},
                    {"text": "容易", key: "easy"},
                    {"text": "中度", key: "moderate"},
                    {"text": "困难", key: "difficult"}
                ],
                "isCanEditAnswerList": [
                    {"text": "不能修改", key: "disable"},
                    {"text": "能修改", key: "able"}
                ],
                "leftNumberList": ["1"],
                "rightNumberList": ["1-10"],
                "mathAdditionFilter": {
                    "degreeOfDifficultyKey": "simple",
                    "questionNumber": 10,
                    "leftAdditionKey": ["0"],
                    "rightAdditionKey": ["0-10"],
                    "isResultInRightNumber": false
                },
                "isCanEditAnswerKey": "disable",
            }
            deepMerge(that.options, param)
            that.init();
            
        }

         Fun.prototype.init=function() {
             let that = this;
             let mathAdditionFilter = JSONParse(localStorage.getItem("mathAdditionFilter"));
            // debugger
            if (mathAdditionFilter instanceof Object) {
                Object.assign(that.options.mathAdditionFilter, mathAdditionFilter)
            }
             that.options.isCanEditAnswerKey = localStorage.getItem("isCanEditAnswerKey") || "disable"
             that.degreeOfDifficultyChange(that.options.mathAdditionFilter["degreeOfDifficultyKey"], "created")
             that.getSelectList();
             that.refresh();

             that.options.ele.on("click", ".mtBtn", function (ele) {
                 that.confirmSubmit();
             })

            eventEmitter.on("getSelectList", () => {
                that.getSelectList();
            });
         } 

        Fun.prototype.refresh = function () {
            let that = this;
            let html = `
                <div class="m-filter-card">
                    <div class="label">难易度</div>
                    <div class="degreeOfDifficultyList"></div>
                    <div>
                        <div class="label">加法数</div>
                        <div class="leftNumberList"></div>
                        <div class="label">加范围</div>
                        <div  class="rightNumberList"></div>
                    </div>

                    <div class="label">问题数量</div>
                    <div class="inputNumber">

                        <m-input-number  controls-position="right" v-model="mathAdditionFilter.questionNumber" max="${that.getMax()}" min="1"></m-input-number>
                    </div>

                    <div  class="label">在未全部完成测试前是否可以修改答案</div>
                    <div class="isCanEditAnswerList"></div>

                    <div class="flex" >
                        <div class="x-fill-auto"></div>
                        <div class="mtBtn submit" size="mini" type="primary"><div class="scale8">确定</div></div>
                    </div>
                </div>
            `
            

            that.options.ele.innerHTML = html;

            ListButton(".degreeOfDifficultyList", {
                parent: that.options.ele,
                list: that.options.degreeOfDifficultyList,
                value:that.options.mathAdditionFilter["degreeOfDifficultyKey"],
                change: function (val) {
                    that.options.mathAdditionFilter["degreeOfDifficultyKey"] = val;
                    that.degreeOfDifficultyChange(val);
                }
            });


            that.leftNumberList= ListButton(".leftNumberList", {
                parent: that.options.ele,
                list: that.options.leftNumberList,
                value: that.options.mathAdditionFilter["leftAdditionKey"],
                multiple: true,
                change: function (val) {
                    that.options.mathAdditionFilter["leftAdditionKey"] = val;
                }
            });

            that.rightNumberList= ListButton(".rightNumberList", {
                parent: that.options.ele,
                list: that.options.rightNumberList,
                value: that.options.mathAdditionFilter["rightAdditionKey"],
                change: function (val) {
                    that.options.mathAdditionFilter["rightAdditionKey"] = val;
                }
            });

            ListButton(".isCanEditAnswerList", {
                parent: that.options.ele,
                list: that.options.isCanEditAnswerList,
                value: that.options.isCanEditAnswerKey,
                change: function (val) {
                    that.options.isCanEditAnswerKey= val;
                }
            });

            InputNumber(".inputNumber", {
                parent: that.options.ele,
                value: that.options.mathAdditionFilter.questionNumber,
                change: function (val) {
                    that.options.mathAdditionFilter.questionNumber = val;
                }
            });

            function getList(list) {
                let html = ``;
                for (let i = 0, len = list.length; i < len; i++) {
                    let v = list[i];
                    html += `
                            <div  class="selectItem ${v["selectAnswerClass"]} ${v["selectAnswerResultClass"]}" >
                                <span class="selectOptionLetter">${v.optionLetter}</span>
                                <div class="x-fill-auto textNumber">${v.name}}</div>
                                <span class="${v.selectAnswerResultIcon}"></span>
                            </div>
                    `
                }
                return html;
            }
        }

        Fun.prototype.getSelectList= function () {
            let that = this;
            let selectList= JSONParse(localStorage.getItem("selectList")) || [];
            if (selectList.length === 0) {
                that.confirmSubmit()
            } else {
                eventEmitter.emit("getNextTest", selectList)
            }
        }


        Fun.prototype.getMax= function () {
            let that = this;
            return 100
        }
        Fun.prototype.degreeOfDifficultyChange= function (val, methodEnter) {
            let that = this;
            let leftNumberList = []
            let express = val || ""
            let defaultFilter = {
                "leftAdditionKey": "",
                "rightAdditionKey": "",
                "questionNumber": "",
            }
            switch (express) {
                case "simple":
                    that.options.leftNumberList = [
                        {"text": "1", key: "1"},
                        {"text": "2", key: "2"},
                        {"text": "3", key: '3'},
                        {"text": "4", key: "4"}
                    ];
                    that.options.rightNumberList = [
                        {"text": "10以内的加法", key: "0-10"}
                    ];
                    defaultFilter.leftAdditionKey = ["1"]
                    defaultFilter.rightAdditionKey = ["0-10"]
                    defaultFilter.questionNumber = 10
                    break;
                case "easy":
                    for (let i = 1; i < 20; i++) {
                        leftNumberList.push({"text": i + "", key: i + ""})
                    }
                    that.options.leftNumberList = [].concat(leftNumberList)

                    that.options.rightNumberList = [
                        {"text": "10以内的加法", key: "0-10"},
                        {"text": "11-20之间加法", key: "11-20"},
                        {"text": "20以内的加法", key: "0-20"}
                    ];
                    defaultFilter.leftAdditionKey = ["1", "2"]
                    defaultFilter.rightAdditionKey = ["0-10"]
                    defaultFilter.questionNumber = 20
                    break;
                case "moderate":
                    this.options.leftNumberList = [
                        {"text": "简单的两位数", key: "simpleTwoDigit"},
                        {"text": "复杂的两位数", key: "complexTwoDigit"},
                    ]
                    this.options.rightNumberList = [
                        {"text": "简单的两位数", key: "simpleTwoDigit"},
                        {"text": "复杂的两位数", key: "complexTwoDigit"}
                    ];
                    defaultFilter.leftAdditionKey = ["simpleTwoDigit"]
                    defaultFilter.rightAdditionKey = ["simpleTwoDigit"]
                    defaultFilter.questionNumber = 20
                    break;
                case "difficult":
                    this.options.leftNumberList = [
                        {"text": "复杂的两位数", key: "complexTwoDigit"},
                    ]
                    this.options.rightNumberList = [
                        {"text": "复杂的两位数", key: "complexTwoDigit"}
                    ];

                    defaultFilter.leftAdditionKey = ["complexTwoDigit"]
                    defaultFilter.rightAdditionKey = ["complexTwoDigit"]
                    defaultFilter.questionNumber = 20
                    break;
            }
            if (methodEnter !== "created") {
                that.leftNumberList.refresh(that.options.leftNumberList);
                that.rightNumberList.refresh(that.options.rightNumberList);
                Object.assign(that.options.mathAdditionFilter, defaultFilter);



            }
        }


        Fun.prototype.confirmSubmit = function () {
            
            let that = this;
            localStorage.setItem("mathAdditionFilter", JSON.stringify(that.options.mathAdditionFilter));
            localStorage.setItem("selectList", "[]");
            let result = that.mathQuestionList({
                "questionNumber": that.options.mathAdditionFilter["questionNumber"],
                "leftNumberList": that.options.mathAdditionFilter["leftAdditionKey"],
                "rightNumberList": that.options.mathAdditionFilter["rightAdditionKey"],
                "isResultInRightNumber": that.options.mathAdditionFilter["isResultInRightNumber"],
                "mathType": "addition",
            })
          //  debugger
            localStorage.setItem("isCanEditAnswerKey", that.options.isCanEditAnswerKey);
            eventEmitter.emit("filterCardConfirm", result)
        }

        Fun.prototype.mathQuestionList=function (param) {
            let list = [];
            let questionNumber = param["questionNumber"] || 10;
            let leftNumberList = param["leftNumberList"] || [];
            let rightNumberList = param["rightNumberList"] || [];
            let isResultInRightNumber = false; // 结果值是否在范围内
            let leftAdditionNumberList = [];
            let rightAdditionNumberList = [];

            if (param.hasOwnProperty("isResultInRightNumber")) {
                isResultInRightNumber = param["isResultInRightNumber"];
            }

            let simpleTwoDigitList = [10, 20, 30, 40, 50, 60, 70, 80, 90, 11, 22, 33, 44];
            let complexTwoDigitList = [];
            for (let i = 10; i <= 99; i++) {
                if (simpleTwoDigitList.includes(i)) {
                    continue;
                }
                complexTwoDigitList.push(i);
            }

            for (let i = 0; i < leftNumberList.length; i++) {
                leftAdditionNumberList.push(...this.getNumberList(leftNumberList[i], simpleTwoDigitList, complexTwoDigitList));
            }

            for (let i = 0; i < rightNumberList.length; i++) {
                rightAdditionNumberList.push(...this.getNumberList(rightNumberList[i], simpleTwoDigitList, complexTwoDigitList));
            }
            let valueMap = {};
            leftAdditionNumberList.forEach(leftAddition => {
                rightAdditionNumberList.forEach(rightAddition => {
                    let map = {};
                    map["id"] = genId(3)

                    map["questions"] = "请问:" + leftAddition + "+" + rightAddition + "=...?"
                    map["rightValue"] = leftAddition + rightAddition
                    map["value"] = leftAddition + rightAddition

                    let correctValue = leftAddition + rightAddition;
                    map["answerList"] = this.getAnswerList(correctValue);
                    list.push(map);

                })
            })

            if (questionNumber < list.length) {
                list.length = questionNumber;
            }
            return list;
        }
        Fun.prototype.getAnswerList=function (correctValue) {
            let list = [];
            let optionLetter = ["A", "B", "C", "D"];

            let start = 0;
            let end = 0;

            if (correctValue < 10) {
                end = 10;
            } else if (correctValue < 20) {
                start = 6;
                end = 20;
            } else if (correctValue < 50) {
                start = 20;
                end = 50;
            } else if (correctValue < 100) {
                start = 50;
                end = 100;
            } else {
                start = 100;
                end = 200;
            }

            let i = 1;
            let valueList = [];
            valueList.push(correctValue);
            while (i < 4) {
                let optionValue =randomNumber(start, end);
                if (valueList.includes(optionValue)) {
                    continue;
                }
                valueList.push(optionValue);
                i++;
            }

            valueList =randomArray(valueList)
            i = 0;
            for (let size = valueList.length; i < size; i++) {
                let valueMap = {};
                let b = valueList[i];
                valueMap["id"] = b;
                valueMap["name"] = b;
                valueMap["value"] = b;
                valueMap["optionLetter"] = optionLetter[i];
                list.push(valueMap);
            }
            return list;
        }
        Fun.prototype.getNumberList=function (addition, simpleTwoDigitList, complexTwoDigitList) {
            addition = (addition || "") + ""
            let list = [];
            //debugger
            if (addition.indexOf("-") > -1) {
                // 区间数
                let additions = addition.split("-");
                for (let i = parseInt(additions[0]); i <= parseInt(additions[1]); i++) {
                    list.push(i);
                }
                return list;
            }
            if ("simpleTwoDigit" === addition) {
                // simpleTwoDigit
                list.push(...simpleTwoDigitList);
                return list;
            }
            if ("complexTwoDigit" === addition) {
                // 复杂的两位数
                list.push(...complexTwoDigitList);
                return list;
            }
            // debugger
            list.push(parseInt(addition));
            return list;
        }
        return function (selecor, param = {}) {
            return newObject(selecor, param, Fun);
        }
    });











