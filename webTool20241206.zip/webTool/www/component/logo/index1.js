define([
    "vue","text!@/logo/index.html",
    "css!@/logo/index.css"], function (Vue,html) {
    Vue.component('m-logo', {
        template: html,
        data: function() {
            return {
                navList: [],
            }
        },
        props: {
            //接收父组件的value
            "theme": {
                type: String,
                default:function () {
                    return "bright"
                }
            }
        },
        methods: {
            getTabs: function() {
                return this.$children.filter(function(item) {
                    return item.$options.name === 'm-tab-item';
                })
            },
        },
    })
});
