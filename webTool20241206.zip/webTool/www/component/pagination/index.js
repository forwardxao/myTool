define([
    "vue","text!@/pagination/index.html",
    "css!@/pagination/index.css"], function (Vue,template) {
    Vue.component("m-pagination", {
        template:template,
        props: {
            "model":{
                prop:"value",
                event:"input"
            },

            "totalNumber":{
                type:Number,
                required: false, //是否必填
                default:0
            },


            "listLength":{
                type:Number,
                default:0
            },

            "pageSize":{
                type:Number,
                required: false, //是否必填
                default:10
            },

            "pageNumber":{
                type:Number,
                required: false, //是否必填
                default:1
            },

            attribute: {
                handleChange() {}
            }
        },
        data:function(){
            return {
                "selfLevel":null,
                "displayNumberText":"",
                "totalPage":1,
                "pageSizeList":[
                    {"name":"每页显示10条",value:10},
                    {"name":"每页显示25条",value:25},
                    {"name":"每页显示50条",value:50},
                    {"name":"每页显示100条",value:100},
                    {"name":"显示全部",value:99999},
                ]
            }
        },
        created:function(){
            console.log("sss");
            this.totalPage=Math.ceil(this.totalNumber/this.pageSize)
        },
        methods: {
            getDisplayNumberText:function () {
                let start= this.pageSize*(this.pageNumber-1)+1;
                let str="显示";
                str+=start;
                str+=" - "+(start+this.listLength);
                str+="条";
                str+=" , 共";
                str+=this.totalNumber;
                str+="条";
                return str;
            },

            handleSizeChange(type) {
                this.$emit('update:pageNumber',this.pageNumber);
                if(type==="pageSize"){
                    this.$emit('update:pageSize',this.pageSize);
                }
                this.$emit("current-change","");
            },


            pageSizeChange:function (type) {

                this.pageNumber=1;
                this.totalPage=Math.ceil(this.totalNumber/this.pageSize)
                this.handleSizeChange("pageSize");
            },

            goPage:function (type) {



                if(type==="change"){
                    this.pageNumber=parseInt(this.pageNumber);
                    this.handleSizeChange("pageNumber");
                    return ;
                }

                if(type==="firstPage"){
                    if(this.pageNumber===1){
                        return ;
                    }
                    this.pageNumber=1;
                    this.handleSizeChange("pageNumber");

                    return ;
                }


                if(type==="prevPage"){
                    if(this.pageNumber<2){
                        return ;
                    }
                    this.pageNumber--;
                    this.handleSizeChange("pageNumber")
                    return ;
                }

                if(type==="nextPage"){
                    if(this.pageNumber>=this.totalPage){
                        return ;
                    }
                    this.pageNumber++;
                    this.handleSizeChange("pageNumber")
                    return ;
                }

                if(type==="lastPage"){
                    if(this.pageNumber===this.totalPage){
                        return ;
                    }
                    this.pageNumber=parseInt(this.totalPage);
                    this.handleSizeChange("pageNumber")
                    return ;
                }


                if(type==="refreshPage"){
                    this.$emit("current-change","");
                    return ;
                }


            }
        }
    });
});