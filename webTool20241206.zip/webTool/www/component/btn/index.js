define([
    "vue",
    "text!@/btn/index.html",
    "css!@/btn/index.css"
], function (Vue,template) {
    Vue.component ("m-btn", {

        template:template,
        props: {
            type: {
                type: String,
                default: 'default'
            },
            size: String,
            icon: {
                type: String,
                default: ''
            },
            nativeType: {
                type: String,
                default: 'button'
            },
            loading: Boolean,
            disabled: Boolean,
            plain: Boolean,
            autofocus: Boolean,
            round: Boolean,
            circle: Boolean
        },
        computed: {
            _elFormItemSize() {
                return (this.elFormItem || {}).elFormItemSize;
            },
            buttonSize() {
                return this.size || this._elFormItemSize || (this.$ELEMENT || {}).size;
            },
            buttonDisabled() {
                return this.$options.propsData.hasOwnProperty('disabled') ? this.disabled : (this.elForm || {}).disabled;
            }
        },
        methods: {
            handleClick(evt) {
                this.$emit('click', evt);
            }
        }
    });
});


