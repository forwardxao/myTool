define([
    "vue",
    "text!@/keyboard/index.html",
    "css!@/keyboard/index.css"
], function (Vue,template) {
    Vue.component ("m-keyboard", {
        template:template,
        props: {
            type: {
                type: String,
                default: 'default'
            },
        },
        data:function(){
          return {
              firstList:[
                      {"text": "q","key": "q","keyboardCode": ""},
                      {"text": "w","key": "w","keyboardCode": ""},
                      {"text": "e","key": "e","keyboardCode": ""},
                      {"text": "r","key": "r","keyboardCode": ""},
                      {"text": "t","key": "t","keyboardCode": ""},
                      {"text": "y","key": "y","keyboardCode": ""},
                      {"text": "u","key": "u","keyboardCode": ""},
                      {"text": "i","key": "i","keyboardCode": ""},
                      {"text": "o","key": "o","keyboardCode": ""},
                      {"text": "p","key": "p","keyboardCode": ""}
              ],
              secondList:[
                      {"text": "a","key": "a","keyboardCode": 65},
                      {"text": "s","key": "s","keyboardCode": ""},
                      {"text": "d","key": "d","keyboardCode": ""},
                      {"text": "f","key": "f","keyboardCode": ""},
                      {"text": "g","key": "g","keyboardCode": ""},
                      {"text": "h","key": "h","keyboardCode": ""},
                      {"text": "j","key": "j","keyboardCode": ""},
                      {"text": "k","key": "k","keyboardCode": ""},
                      {"text": "l","key": "l","keyboardCode": ""}
                  ],
              thirdList:[
                  {"text": "z","key": "z","keyboardCode": ""},
                  {"text": "x","key": "x","keyboardCode": ""},
                  {"text": "c","key": "c","keyboardCode": 67},
                  {"text": "v","key": "v","keyboardCode": ""},
                  {"text": "b","key": "b","keyboardCode": 66},
                  {"text": "n","key": "n","keyboardCode": ""},
                  {"text": "m","key": "m","keyboardCode": ""}
                  ],
              spaceItem: {"text": "跳过","key": "space","keyboardCode": ""},
              selectedKey: "",
          }
        },
        created:function(){},
        methods: {
            handleClick(evt) {
                this.$emit('click', evt);
            },

            itemClickFun(item) {
                this.selectedKey=item.key
                this.$emit('confirm', item);
            },
            getClassFun(item) {
                let that=this
                if(item.key===that.selectedKey){
                    return "selected"
                }
                return ""
            },




            clearSelectedFun() {
              //  debugger
                let that=this
                that.selectedKey=""
               // debugger
                that.$set(that, "selectedKey", "");
                that.$forceUpdate()
             //   debugger
            }

        }
    });
});


