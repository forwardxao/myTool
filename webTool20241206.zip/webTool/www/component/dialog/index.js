define([
    "vue",
    "text!@/dialog/index.html",
    "css!@/dialog/index.css"
], function (Vue,template) {
    Vue.component ("m-dialog", {

        template:template,
        props: {
            type: {
                type: String,
                default: 'default'
            },
        },
        data:function(){
          return {}
        },

        created:function(){
        },
        methods: {
            handleClick(evt) {
                this.$emit('click', evt);
            },

            itemClickFun(item) {

                this.$emit('confirm', item);
            },
            maskingFun() {
                this.$emit('maskingfun');
            }

        }
    });
});


