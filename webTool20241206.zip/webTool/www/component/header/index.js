define([
    "vue",
    "text!@/header/index.html",
    "css!@/header/index.css",

],function (Vue,template){
   // let app = Vue.createApp();
     Vue.component('m-header',{
        template:template,
        props: {
            position: {
                type: String,
                default:function () {
                    return "fixed"
                }
            },
            boxShadow: {
                type: Boolean,
                default:function () {
                    return false
                }
            }
        },
       data:function (){
           return {
               "audioMp3":new Audio(),
           }
       },
        created:function(){},
        methods: {
            normalFunction:function (item,type) {}
        },
    })



})

