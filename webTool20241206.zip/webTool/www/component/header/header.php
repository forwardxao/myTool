<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="initial-scale=1,maximum-scale=1,minimum-scale=1" />
    <meta name="keywords" content="君安智学、学习资料、高效学习、益智游戏、在线考试">
    <meta name="description" content="君安智学，海量学习资料轻松下载，成就高效卓越学习平台">
    <meta name="MSSmartTagsPreventParsing" content="True">
    <meta name="copyright" content="2008-2024 jazx.com">
    <title>example 君安智学网-www.mytool.xyz</title>
    <link rel="shortcut  icon" href="/source/image/favicon.ico" type="image/x-icon" />
