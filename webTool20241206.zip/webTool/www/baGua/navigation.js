define([
    "css!./navigation.css",
    "util/data/ternaryOperator",
    "util/newFun/newObject",
    "util/event/eventEmitter",
    "util/copy/deepMerge"
],
    function (css, ternaryOperator, newObject, eventEmitter, deepMerge) {

        function Fun(param) {
            let that = this;

            this.options = {
                ele:null,
            }
            deepMerge(that.options, param)


            that.options.ele.on("click", ".left", function (ele) {
                that.toggle();
            })

            that.options.ele.on("click", ".gua-navigation", function (ele) {
                that.toggle();
                let index = parseInt(ele.dataset.index || 0);
                eventEmitter.emit("guaIndex", index)
            })

        }
        Fun.prototype.getHtml = function (list, guaIndex) {

            let html = `
                <div  class="navigation-container">
                    <div class="flex title">
                        <div class="x-fill-auto left" style="padding-left: 2rem;">返回</div>
                        <div style="font-size: 1.5rem;">卦名</div>
                        <div class="x-fill-auto"></div>
                    </div>
                    <div class="gua-navigation-list">${getList(list, guaIndex)}</div>
                </div>
            `
            this.options.ele.innerHTML = html;
            function getList(list, guaIndex) {
                let html = ``;
                for (let i = 0, len = list.length; i < len; i++) {
                    let v = list[i];
                    if ((i % 8) === 0) {
                        html += `<div class="gua-br"></div>`
                    }
                    html += `
                        <div class="gua-navigation ${ternaryOperator(guaIndex, i,'selected')}" data-index="${i}">
                            <div>${v["name"]}</div>
                        </div>
                    `
                }
                return html;
            }
        }
        Fun.prototype.toggle = function () {
            let ele = this.options.ele.querySelector(".navigation-container");
            ele.classList.toggle("active");
        }

        return function (selecor, param = {}) {
            return newObject(selecor, param, Fun);
        }
    });





