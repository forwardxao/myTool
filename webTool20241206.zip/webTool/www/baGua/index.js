define([
    "@/header/index",
    "util/url/getUrlKey",
    "util/audio/play",
    "util/Dom/title",
    "www/baGua/list",
    "www/baGua/navigation",
    "www/baGua/item",
    "util/event/eventEmitter",
],
    function (Header, getUrlKey, title, audioPlay, list, Navigation, GuaItem, eventEmitter) {

        let navigation =  Navigation(".navigationContainer");
        let guaItem =  GuaItem(".itemContainer");
        let header= Header(".headerContainer", {
            center: {
                template:"卦象学习"
            },
            right: {
                callBack: function (ele) {
                    navigation.toggle();
                }
            }
        })

        let data = {
            "guaList": [],
            "guaItem": {
                "name": "",
                "detail": "",
                "yaoDetail": [],
                "html": ""
            },
            "guaIndex": 0
        }

        eventEmitter.on("guaIndex", function (val) {
            data.guaIndex = val;
            navigation.getHtml(data.guaList, data.guaIndex);
            methods.getGua();
        })

        eventEmitter.on("prevFun", function (val) {
            methods.prevFun()
        })
        eventEmitter.on("nextFun", function (val) {
            methods.nextFun()
        })


        let methods = {
            init: function () {
                let that = this;
                data.guaList = [].concat(list);

                data.guaIndex = parseInt(localStorage.getItem("guaIndex") || 0)
                that.getGua();
                navigation.getHtml(data.guaList, data.guaIndex)
            },
            "getBaGuaHtml": function (code="") {
                let that = this;
                let statusObject = {
                    "0": {
                        name: "yin",
                        html: `<div class="yin"></div>`,
                    },
                    "1": {
                        name: "yang",
                        html: `<div class="yang"></div>`,
                    }
                }

                let codeList = code.split("");
                let html = "";
                for (let i = 0, len = codeList.length; i < len; i++) {
                    let v = codeList[i];
                    if (!statusObject[v]) {
                        continue;
                    }
                    html+=statusObject[v].html
                }
                return html;
            },
            "getGua": function () {
                let that = this;
                if (data.guaIndex > (data.guaList.length - 1)) {
                    data.guaIndex = data.guaList.length - 1;
                    return;
                }
                if (data.guaIndex < 0) {
                    data.guaIndex = 0;
                    return;
                }

                localStorage.setItem("guaIndex", data.guaIndex);
                data.guaItem = Object.assign({}, data.guaList[data.guaIndex])
                data.guaItem["html"]=that.getBaGuaHtml(data.guaItem.code);
                guaItem.getHtml(data.guaItem)
            },

            "prevFun": function () {
                let that = this;
                data.guaIndex--;
                that.getGua()
            },
            "nextFun": function () {
                let that = this;
                data.guaIndex++;
                that.getGua()
            }
        }
        methods.init();
    });





