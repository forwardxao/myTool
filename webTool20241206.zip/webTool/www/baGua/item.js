define([
    "css!./item.css",
    "util/newFun/newObject",
    "util/data/ternaryOperator",
    "util/event/eventEmitter",
    "util/copy/deepMerge"
],
    function (css, newObject, ternaryOperator, eventEmitter, deepMerge) {

        function Fun(param) {
            let that = this;


            this.options = {
                ele: null,
            }
            deepMerge(that.options, param)
            that.options.ele.on("click", ".prevFun", function (ele) {
                eventEmitter.emit("prevFun")
            })
            that.options.ele.on("click", ".nextFun", function (ele) {
                eventEmitter.emit("nextFun")
            })
        }
        Fun.prototype.getHtml = function (guaItem) {

            let html = `
                <div class="baGua-list">
                    <div  class="prevFun scale8"><span></span></div>
                    <div class="baGua-item">
                        <div  class="guaPic">${guaItem.html}</div>
                        <div class="guaName">${guaItem.name}</div>
                        <div class="detail">卦辞：${guaItem.detail}</div>
                        <div class="yaoDetail">爻辞：${getYao(guaItem.yaoDetail)}</div>
                    </div>
                    <div  class="nextFun scale8"><span></span></div>
                </div>
            `
            this.options.ele.innerHTML = html;
            function getYao(list) {
                let html = ``;
                list = list || [];
                for (let i = 0, len = list.length; i < len; i++) {
                    let v = list[i];
                    html += `
                        <div  class="">${v}</div>
                    `
                }
                return html;
            }
        }

        return function (selecor, param = {}) {
            return newObject(selecor, param, Fun);
        }
    });





