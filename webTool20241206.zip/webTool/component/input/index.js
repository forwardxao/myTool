define([
    "vue",
    "text!@/input/index.html",
    "css!@/input/index.css"
],function (Vue,template) {
    Vue.component ("m-input",{
        template:template,
        props:{
            "model":{
                prop:"value",
                event:"input"
            },
            "value":{
                type:String,
                default:function () {
                    return ""
                }
            },
            "placeholder":{
                type:String,
                default:function () {
                    return ""
                }
            },
            "clear":{
                type:Boolean,
                default:function () {
                    return false
                }
            }
        },

        data:function(){
            return {
                show:true
            }
        },

        watch:{
          "value":function (newVal,oldVal){
             // debugger
              this.$emit("input",newVal)
          }
        },
        methods:{
            clearFun:function(){
                this.value=""
            }
        },
    })
})

