define([
    "css!./index.css",
    "util/event/on",
    "util/newFun/index",
],
    function (css, on, newFun) {
        function Fun(param) {
            let that = this
            that.options = {
                ele: null,
                count: 100,
                limit: 20,
                page:1,
                theme: "",
                template:{
                    first: `<span page="first" >��ҳ</span>`,
                    last: `<span page="last" >���һҳ</span>`,
                    prev: `<span page="prev" >��һҳ</span>`,
                    next: `<span page="next" >��һҳ</span>`,
                    skip: `<span class="skip">...</span>`
                },
                callBack: function (v, i) {

                }
            }
            for (let key in that.options) {
                if (param.hasOwnProperty(key) && param[key]) {
                    that.options[key] = param[key]
                }
            }
            if (this.options.limit < 1) {
                this.options.limit=1
            }

            that.html = ``;
            

            that.options.pageTotal = Math.ceil(this.options.count / this.options.limit);

            that.options.ele.on("click", "[page]", function (ele) {

                let page = ele.getAttribute("page");
                if (page.indexOf("skip")>-1) {
                    return;
                }

                if (page === "first") {
                    page = 1;
                }
                if (page === "last") {
                    page = that.options.pageTotal;
                }


                if (page === "prev") {
                    page = that.options.page - 1;
                    if (page < 1) {
                        page = 1;
                        return
                    }
                }

                if (page === "next") {
                    page = that.options.page + 1;
                    if (page > that.options.pageTotal) {
                        page = that.options.pageTotal;
                        return
                    }
                }


                that.options.page =parseInt(page);
                that.options.callBack();
                that.render();
            })
            this.getTemplate();

        };

        Fun.prototype.getTemplate = function (v, i) {
            let that = this;

            let list = [
                { name: "��ҳ", key: "first" },
                { name: "��һҳ", key: "prev" },
                { name: "...", key: "skipPrev" },
                { name: "1", key: "page" },
                { name: "1", key: "page" },
                { name: "1", key: "page" },
                { name: "1", key: "page" },
                { name: "1", key: "page" },
                { name: "...", key: "skipNext" },
                { name: "��һҳ", key: "next" },
                { name: "βҳ", key: "last" }
            ]

            this.template = ``;


            let html = ``;
            for (let i = 0, len = list.length; i < len; i++) {
                let v = list[i];
                html += `<span page="${v.key}" type="${v.key}">${v.name}</span>`;
            }

            this.options.ele.innerHTML = `<div class="mt_pagination">${html}</div>`;

            that.render();
        }

        Fun.prototype.render = function (v, i) {
            let that = this;

            function setPage(ele,current) {
                ele.innerText = current;
                if (that.options.page == current) {
                        ele.classList.add("active");
                    } else {
                        ele.classList.remove("active");
                    }
                ele.setAttribute("page", current);
            }
            let pagelist=this.options.ele.querySelectorAll("[type='page']")
            if (this.options.pageTotal < 5) {
                for (let i = 0, len = pagelist.length; i < len; i++) {
                    if (i > (this.options.pageTotal-1)) {
                        pagelist[i].style.display = "none";
                        break;
                    }
                    setPage(pagelist[i], i + 1);
                }
            } else {
                let start = this.options.page - 2;
                let end = this.options.page + 2;
                let html = ``;

                if (start < 1) {
                    start = 1;
                    end = 5;
                }

                if (end > this.options.pageTotal) {
                    end = this.options.pageTotal;
                    start = end - 4
                }


                for (let i = 0, len = pagelist.length; i < len; i++) {
                    setPage(pagelist[i], start + i);
                }


                if ((this.options.pageTotal / 2) > this.options.page) {
                    this.options.ele.querySelector("[type='skipPrev']").style.display = "none";
                    this.options.ele.querySelector("[type='skipNext']").style.display = "block";
                } else {
                    this.options.ele.querySelector("[type='skipPrev']").style.display = "block";
                    this.options.ele.querySelector("[type='skipNext']").style.display = "none";
                }
            }

        }
        return function (selecor,param) {
            newFun(selecor, param,Fun);
        }

       
    })