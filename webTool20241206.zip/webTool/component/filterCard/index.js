define(["vue","text!@/filterCard/index.html","css!@/filterCard/index.css"],function (Vue,template){
    Vue.component("m-filter-card", {
        template:template,
        props: {
            "model":{
                prop:"value",
                event:"input"
            },

            "subjectType":{
                type:String,
                default:"math"
            },

            filterData:{
                type:Object,
                required: false, //是否必填
                default:{
                    "degreeOfDifficultyKey":"",
                    "isCanEditAnswerKey":"disable",
                    "leftNumberList": "[]" ,
                    "rightNumberList":"[]",
                    "questionNumber":0,
                    "isResultInRightNumber":false,
                }
            }
        },

        data:function(){
            return {
                "degreeOfDifficultyList":[
                    {"text":"简单",key:"simple"} ,
                    {"text":"容易",key:"easy"} ,
                    {"text":"中度",key:"moderate"} ,
                    {"text":"困难",key:"difficult"}
                ],
                "isCanEditAnswerList":[
                    {"text":"不能修改",key:"disable"},
                    {"text":"能修改",key:"able"}
                ],

                "leftNumberList": [],
                "rightNumberList": [],
                "questionNumber":10,
                "isResultInRightNumber":false,

                "degreeOfDifficultyKey":"simple",
                "isCanEditAnswerKey":"disable",


                "leftAdditionKey":["0"],
                "rightAdditionKey":["0-10"],
                "selectKey":"",
            }
        },
        created:function(){
            let that=this;


            that.degreeOfDifficultyKey=that.filterData["degreeOfDifficultyKey"]
            that.isCanEditAnswerKey=that.filterData["isCanEditAnswerKey"]||"able"

            //debugger

            that.leftAdditionKey=that.filterData["leftNumberList"]
            that.rightAdditionKey=that.filterData["rightNumberList"]
            that.questionNumber=that.filterData["questionNumber"]

            that.degreeOfDifficultyChange(that.filterData["degreeOfDifficultyKey"],"created")
        },
        methods: {

            getMax:function (){
                let that=this;
                return 100
            },
            degreeOfDifficultyChange:function (val,methodEnter){
                let that=this;
                let leftNumberList=[]
                let express=val||""

                let defaultFilter={
                    "leftAdditionKey":"",
                    "rightAdditionKey":"",
                    "questionNumber":"",
                }
                switch (express){
                    case "simple":
                        this.leftNumberList=[
                            //  {"text":"0",key:"0"},
                            {"text":"1",key:"1"},
                            {"text":"2",key:"2"},
                            {"text":"3",key:'3'},
                            {"text":"4",key:"4"}
                        ];
                        this.rightNumberList=[
                            {"text":"10以内的加法",key:"0-10"}
                        ];
                        defaultFilter.leftAdditionKey=["1"]
                        defaultFilter.rightAdditionKey=["0-10"]
                        defaultFilter.questionNumber=10
                        break;
                    case "easy":
                        for(let i=1;i<20;i++){
                            leftNumberList.push({"text":i+"",key:i+""})
                        }
                        this.leftNumberList=[].concat(leftNumberList)

                        this.rightNumberList=[
                            {"text":"10以内的加法",key:"0-10"},
                            {"text":"11-20之间加法",key:"11-20"},
                            {"text":"20以内的加法",key:"0-20"}
                        ];
                        defaultFilter.leftAdditionKey=["1","2"]
                        defaultFilter.rightAdditionKey=["0-10"]
                        defaultFilter.questionNumber=20
                        break;
                    case "moderate":
                        this.leftNumberList=[
                            {"text":"简单的两位数",key:"simpleTwoDigit"},
                            {"text":"复杂的两位数",key:"complexTwoDigit"},
                        ]
                        this.rightNumberList=[
                            {"text":"简单的两位数",key:"simpleTwoDigit"},
                            {"text":"复杂的两位数",key:"complexTwoDigit"}
                        ];
                        defaultFilter.leftAdditionKey=["simpleTwoDigit"]
                        defaultFilter.rightAdditionKey=["simpleTwoDigit"]
                        defaultFilter.questionNumber=20
                        break;
                    case "difficult":
                        this.leftNumberList=[
                            {"text":"复杂的两位数",key:"complexTwoDigit"},
                        ]
                        this.rightNumberList=[
                            {"text":"复杂的两位数",key:"complexTwoDigit"}
                        ];

                        defaultFilter.leftAdditionKey=["complexTwoDigit"]
                        defaultFilter.rightAdditionKey=["complexTwoDigit"]
                        defaultFilter.questionNumber=20
                        break;
                }
                if(methodEnter!=="created"){
                    that.leftAdditionKey= defaultFilter.leftAdditionKey
                    that.rightAdditionKey= defaultFilter.rightAdditionKey
                    that.questionNumber= defaultFilter.questionNumber
                }
                //  return 10
            },
            confirmSubmit:function (){
                //debugger
                this.$emit("confirm",{
                    "degreeOfDifficultyKey":JSON.parse(JSON.stringify(this.degreeOfDifficultyKey)),
                    "isCanEditAnswerKey":JSON.parse(JSON.stringify(this.isCanEditAnswerKey)),
                    "leftNumberList":JSON.parse(JSON.stringify(this.leftAdditionKey)),
                    "rightNumberList":JSON.parse(JSON.stringify(this.rightAdditionKey)),
                    "questionNumber":JSON.parse(JSON.stringify(this.questionNumber)),
                    "isResultInRightNumber":false
                })

            },


        }
    });
})

