define([
        "vue",
        "text!@/treeMenu/index.html",
        "css!@/treeMenu/index.css"],
    function (Vue,template) {
        Vue.component("m-tree-menu", {
            template:template,
            props:{
                "list":{
                    type:Array,
                    default:[],
                    required:false
                },
                "text":{
                    type:String,
                    default:function (){
                        return "text"
                    },
                    required:false
                },
                "node":{
                    type:String,
                    default:function (){
                        return "children"
                    },
                    required:false
                }
            },
            data:function () {
                return {
                    childList:[]
                }
            },
            created:function(){

            },
            methods:{
                getChildren:function (item){
                    let that=this;
                    //debugger
                    if(item.hasOwnProperty(that.node)){
                        if(item[that.node] instanceof Array)
                        {
                            return item[that.node]
                        }
                        return []
                    }else{
                        return []
                    }
                },
            }
        })
    });


