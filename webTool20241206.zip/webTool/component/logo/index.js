define([
    "css!./index.css",
    "util/event/on",
    "util/newFun/newObject",
    "util/copy/deepMerge",
    "util/check/isMobileMode",
    "util/event/eventEmitter",
],
    function (css, on, newObject, deepMerge, isMobileMode, eventEmitter) {
    function Fun(param) {
        let that = this
        that.options = {
            ele: null,
            url: "url",
            target: "_blank",
            logo:" ",
            domain: "mytool.xyz",
            isMobileMode: isMobileMode(),
            name: "我的常用工具",
            callBack: function (v, i) {

            }
        }
        deepMerge(that.options, param)

        that.setHtml();
        that.options.ele.on("click", ".x-fill-auto,.mobile-menu-toggle", function (ele) {
            eventEmitter.emit("toogleMenu");
        })
    };

    Fun.prototype.setHtml = function (v) {
        let that = this;
        
        let html = `
                <div class="logo-env ${getModeClass()}">
                    <div class="logo">
                        <a href="/www/index/index.html" class="logo-expanded">
                            <img src="${that.options.logo}" width="100%" alt="" />
                        </a>
                    </div>
                    ${MobileMode()}
                </div>
            `;

        that.options.ele.innerHTML = html;
        function getModeClass() {
            if (that.options.isMobileMode) {
                return "mobile";
            }
            return "";
        }
        function MobileMode() {
            if (that.options.isMobileMode) {
                return `
                    <div  @click.stop="toggleMenu()" class="x-fill-auto"></div>
                    <div class="mobile-menu-toggle " >
                        <img  src="/source/svg/arrow-right-bold.svg" />
                    </div>
                `;
            }
            return "";
        }
    }
    return function (selecor, param) {
        return newObject(selecor, param, Fun);
    }
});
