define([
    "vue",
    "text!@/pmsTree/index.html",
    "css!@/pmsTree/index.css"], function (Vue,template) {
    Vue.component("pms-tree",{
        props:{
            "treeList":{
                type:Array,
                default:function () {
                    return []
                }
            },
            "optionValue":{
                type:String,
                default:function () {
                    return "value"
                }
            },
            "optionLabel":{
                type:String,
                default:function () {
                    return "label"
                }
            },
        },
        data:function () {
            return {
                thisList:[]
            }
        },
        created:function(){
            let  that=this
            this.$nextTick(function () {
                let _array= that.treeList.map(function (v,i) {
                    return {
                        "label":v[that.optionLabel],
                        "value":v[that.optionValue],
                        "children":v["children"]||[],
                        "toggleChildren":false
                    }
                })
                that.thisList=_array
            })
        },
        methods:{
            normalFunction:function (item,type,otherInfo) {
                let  that=this
                if(type==='itemClick'){
                    return
                }
                if(type==='toggleChildren'){
                    item["toggleChildren"]=!item["toggleChildren"]
                    return
                }
                if(type==='selectItem'){
                    this.$emit("input",item)
                    return
                }
                console.log('test')
            },
        },
        template:template
    })
});

