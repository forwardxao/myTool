define([
    "vue",
    "text!@/lyjm/index.html",
    "css!@/lyjm/index.css"
], function (Vue,template) {
    Vue.component ("m-lyjm", {
        template:template,
        props: {
            type: {
                type: String,

                default: 'default'
            },
        },
        data:function(){
          return {
              selectedKey: "",
              url:"https://lyjm88.taobao.com/search.htm?spm=a1z10.1-c-s.w5002-25173892049.1.1c6413592HsSgZ&search=y",
          }
        },
        created:function(){},
        methods: {
            handleClick(evt) {
                this.$emit('click', evt);
            },
            openUrl(evt) {
                window.location.href=this.url
            }


        }
    });
});


