﻿define([
    "css!./loading.css",
    "util/event/on",
    "util/newFun/newObject",
    "util/copy/deepMerge"
],
    function (css, on, newObject, deepMerge) {
        function Fun(param) {
            let that = this
            that.options = {
                ele: null,
                show: false,
            }
            deepMerge(that.options, param)

            that.options.ele.classList.add("loadingContainer")
            that.setHtml();
        };

        Fun.prototype.setHtml = function () {
            let that = this;
            that.options.ele.innerHTML = `
                    <div class="mt_loading ${getClass()}">
                        <div class="container1">
                            <div class="circle circle1"></div>
                            <div class="circle circle2"></div>
                            <div class="circle circle3"></div>
                            <div class="circle circle4"></div>
                        </div>
                        <div class="container2">
                            <div class="circle circle1"></div>
                            <div class="circle circle2"></div>
                            <div class="circle circle3"></div>
                            <div class="circle circle4"></div>
                        </div>
                    </div>
            `

            function getClass(v) {
                if (that.options.show) {
                    return "show"
                }
                return "";
            }

        }
        Fun.prototype.toggle = function () {
            let that = this;
            that.options.ele.classList.toggle("show")
        }

        Fun.prototype.show = function () {
            let that = this;
            that.options.ele.classList.add("show")
        }
        Fun.prototype.hide = function () {
            let that = this;
            that.options.ele.classList.remove("show")
        }

        return function (selecor, param) {
            return newObject(selecor, param, Fun);
        }

    })
