define([
    "vue",
    "text!@/tab/index.html",
    "text!@/tab/tabItem.html",
    "css!@/tab/index.css"], function (Vue,template,tabItem) {

    Vue.component('m-tab-item',{
        template:tabItem,
        data:function(){
            return {
                show:true
            }
        },
        //props为来自父组件的变量，实现父组件与子组件通信
        props:{
            //设置tabItem的标识
            name:{
                type:String
            },
            //label是设置标题
            label:{
                type:String,
                default:''
            }
        },
        methods:{
            updateNav:function(){
                //$parent 父链，通知父组件（tabs）进行更新。
                //说明：在业务中尽可能不要使用$parent来操作父组件，$parent适合标签页这样的独立组件
                this.$parent.updateNav();
            }
        },
        //监听label
        watch:{
            label(){
                this.updateNav();
            }
        },
        mounted(){
            //初始化tabs
            this.updateNav();
        }
    })
    Vue.component('m-tab', {
        template: template,
        data: function() {
            return {
                //将tabItem的标题保存到数组中
                navList: [],
                //保存父组件的value到currentValue变量中，以便在本地维护
                currentValue: this.value
            }
        },
        props: {
            //接收父组件的value
            value: {
                type: [String]
            }
        },
        methods: {
            //使用$children遍历子组件，得到所有的tabItem组件
            getTabs: function() {
                return this.$children.filter(function(item) {
                    return item.$options.name === 'm-tab-item';
                })
            },
            //更新tabs
            updateNav() {
                this.navList = [];
                let _this = this;
                this.getTabs().forEach(function(tabItem, index) {
                    _this.navList.push({
                        label: tabItem.label,
                        name: tabItem.name || index
                    });
                    //如果没有设置name，默认设置为索引值
                    if(!tabItem.name) {
                        tabItem.name = index;
                    }
                    //设置第一个tabItem为当前显示的tab
                    if(index === 0) {
                        if(!_this.currentValue) {
                            _this.currentValue = tabItem.name || index;
                        }
                    }
                });
                this.updateStatus();
            },
            updateStatus() {
                let tabs = this.getTabs();
                let _this = this;
                //显示当前选中的tab对应的tabItem组件，隐藏没有选中的
                tabs.forEach(function(tab) {
                    return tab.show = tab.name === _this.currentValue;
                })
            },
            tabCls: function(item) {
                return [
                    'tabs-tab',
                    {
                        //为当前选中的tab加一个tabs-tab-active class
                        'tabs-tab-active': item.name === this.currentValue
                    }
                ]
            },
            //点击tab标题触发
            handleChange: function(index) {
                let nav = this.navList[index];
                let name = nav.name;
                //改变当前选中的tab，触发watch
                this.currentValue = name;
                //实现子组件与父组件通信
                this.$emit('input', name);
            }
        },
        watch: {
            value: function(val) {
                this.currentValue = val;
            },
            currentValue: function() {
                //tab发生变化时，更新tabItem的显示状态
               // debugger
                this.updateStatus();
            }
        }
    })
});
