﻿define([
    "css!./index.css",
    "util/event/on",
    "util/check/isFunction",
    "util/Dom/isDom",
    
    "util/check/isArray",
    "util/check/isObject",
    "util/newFun/newObject",
    "util/copy/copyObject",
    "util/data/getItemByPath",

],
    function (css, on, isFunction, isDom, isArray, isObject, newObject, copyObject, getItemByPath) {
        function Fun(param) {
            let that=this
             that.options = {
                ele:null,
                 list: [{ name: "示例菜单", url: 'mytool.xyz', target: "_blank", list: [{ name: "子菜单", url: 'mytool.xyz', target: "_blank"}]}],

                 openStatus: {},
                 isShowChild: true,
                 childKey: "list",
                 name: "name",
                 url: "url",
                 target: "_blank",
                 template: function (v, i) {
                     return `${v[that.options.name]||""}`;
                 },
                 callBack: function (v,i) {

                 }
            }

            copyObject(that.options, param)


            that.html = ``;

            that.getOpenStatus();
            that.getList(that.options.list,""); 
            that.options.ele.innerHTML = that.html;
            that.options.ele.on("click", ".mt_toggle_child", function (ele) {
                let parent = ele.closest(".mt_menu_item_container")
                let path = parent.dataset.path;

                if (parent.classList.contains("active")) {
                    parent.classList.remove("active")
                    that.options.openStatus[path] = false
                } else {
                    parent.classList.add("active")
                    that.options.openStatus[path] = true
                }
                localStorage.setItem("openStatus", JSON.stringify(that.options.openStatus));
                
            })

            that.options.ele.on("click", ".mt_menu_name", function (ele) {
                that.itemClick(ele)
            })
        };

        Fun.prototype.getOpenStatus = function () {
            let that = this;
            that.options.openStatus = JSON.parse(localStorage.getItem("openStatus") || "{}");
            if (!isObject(that.options.openStatus)) {
                that.options.openStatus = {};
            }
        }

        Fun.prototype.getActiveClass = function (v) {
            let that = this;
            if (that.options.openStatus[v["path"]]) {
                return "active";
            }
            return "";
        }

        Fun.prototype.toggleChild = function () {
            alert('sss')
        }

        Fun.prototype.getToggle = function (v) {
            let that = this;
            if (isArray(v[that.options.childKey])) {
                return `<div class="mt_toggle_child" ></div>`;
            }
            return `<div class="mt_toggle_none"></div>`;
        }


        Fun.prototype.getItem = function (v, i, path) {
            let that = this;
            that.html += `
                    <div class="mt_menu_item_container ${that.getActiveClass(v)}" data-path="${path}">
                    <div class="mt_menu_item" >
                        ${that.getToggle(v)} 
                        <div class="mt_menu_name" >
                            ${that.options.template(v, i)}
                        </div>
                    </div>
            `;
            if (that.options.isShowChild) {
                that.getList(v[that.options.childKey], path)
            }
            that.html += `</div>`;
        }

        Fun.prototype.getList = function (list,path) {
            if (!isArray(list)) { return; }
            if (list.length < 1) { return; }
            let that = this;
            that.html += `<div class="mt_menu_list">`;
            for (let i = 0, len = list.length; i < len; i++) {
                let v = list[i];
                v["path"] = path+"/"+i;
                that.getItem(v, i, v["path"])
            }

            that.html += `</div>`;
        }
        Fun.prototype.getItemByPath = function (path) {
            let that = this;
            return getItemByPath({ list: that.options.list, path: path, children: that.options.childKey} );
        }

        Fun.prototype.itemClick = function (ele) {
            let that = this;
            let activeEle = that.options.ele.querySelectorAll(".mt_menu_name.active")
            activeEle.forEach(child => {
                child.classList.remove("active")
            });
            ele.classList.add("active");
            if (!isFunction(that.options.callBack)) {
                return;
            }

            let parent = ele.closest(".mt_menu_item_container")
            let path = parent.dataset.path || "";
            let item = that.getItemByPath(path);
            that.options.callBack(ele, item)
        }

        Fun.prototype.setActiveByPath = function (path) {
            let that = this;
            let ele = that.options.ele.querySelector("[data-path='" + path + "']");
            if (isDom(ele)) {
                ele = ele.querySelector(".mt_menu_name");
                if (isDom(ele)) {
                    that.itemClick(ele);
                }
            }
        }

        return function (selecor, param) {
            return newObject(selecor, param, Fun);
        }

})