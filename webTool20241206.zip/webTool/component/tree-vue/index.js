(function () {
    'use strict';
    var addNode = function (node) {
        node.isOpen = true;
        node.children.push({
            name: 'child node ' + node.children.length,
            parent: node,
            isParent: true,
            children: [],
            buttons: [
                {
                    title: 'Add',
                    icon: 'fa fa-plus',
                    click: addNode
                }, {
                    title: 'Delete',
                    icon: 'fa fa-trash',
                    click: function (node) {
                        node.parent.children.splice(node.parent.children.indexOf(node), 1);
                    }
                }
            ]
        });
    };
    var VueTreeItem = Vue.extend({
        template: `
            <li :class="{parent_li: node.isParent}" class="tree-item">
                <i 
                    v-if="node.isParent" 
                    @click.stop="toggle(node)" 
                    class="fa icon-open-state" 
                    :class="{'el-icon-circle-plus-outline': !node.isOpen, 'el-icon-remove-outline': node.isOpen}"
                ></i>
                <span :title="node.title">
                    <i v-if="showIcon(node)" :class="nodeClass(node)"></i> {{node.name}}
                </span>
                <a v-for="btn in node.buttons" class="ml5" href="javascript:" :title="btn.title" v-on:click="btnClick(btn, node)"><i :class="btn.icon"></i></a>
                <ul v-show="node.isOpen" class="tree-list">
                    <li v-show="node.showLoading && node._loading"><i class="fa fa-spinner fa-pulse"></i></li>
                    <vue-tree-item v-for="item in node.children" :node="item" v-key="node.id"></vue-tree-item>
                </ul>
            </li>
`,
        props: {
            node: {
                type: Object
            }
        },
        methods: {
            showIcon: function (node) {
                return node.icon || node.openedIcon || node.closedIcon;
            },
            nodeClass: function (node) {
                if (node.isOpen) {
                    return node.openedIcon || node.icon;
                } else {
                    return node.closedIcon || node.icon;
                }
            },
            toggle: function (node) {
                if (node.hasOwnProperty('isOpen')) {
                    node.isOpen = !node.isOpen;
                } else {
                    Vue.set(node, 'isOpen', true);
                }
            },
            btnClick: function (btn, node) {
                if (typeof btn.click === 'function') {
                    btn.click(node);
                }
            }
        },
        watch: {
            'node.isOpen': function (val) {
                if (!this.node.hasOwnProperty('_loading')) {
                    Vue.set(this.node, '_loading', false);
                }
                if (val) {
                    if (typeof this.node.onOpened === 'function') {
                        this.node.onOpened(this.node);
                    }
                } else {
                    if (typeof this.node.onClosed === 'function') {
                        this.node.onClosed(this.node);
                    }
                }
            }
        }
    });

    var VueTree = Vue.extend({
        template: `
        <div class="vue-tree">
            <ul v-for="item in treeList">
                <tree-item :node.sync="item"></tree-item>
            </ul>
        </div>
        `,
        props: {
            treeList: {
                type: Array,
                default:function () {
                    return []
                }
            }
        },
        components: {
            'tree-item': VueTreeItem
        }
    });

    Vue.component("vue-tree-item", VueTreeItem);
    Vue.component("vue-tree", VueTree);
})();