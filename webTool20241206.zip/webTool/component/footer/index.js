define(["vue","text!@/footer/index.html","css!@/footer/index.css"],function (Vue,template){
    Vue.component("m-footer", {
        template:template,
        props: {
            position: {
                type: String,
                default:function () {
                    return "fixed"
                }
            },
            boxShadow: {
                type: Boolean,
                default:function () {
                    return false
                }
            },


            footerMenu: {
                type: Array,
                default:function () {
                    return []
                }
            },


            selectMenu: {
                type: Object,
                default:function () {
                    return {
                        "name":"",
                        "key":""
                    }
                }
            },


        },
        data:function(){
            return {
                "audioMp3":new Audio(),
            }
        },
        created:function(){

        },
        methods: {
            normalFunction:function (item,type) {},

            footerMenuClick:function (item,type) {

                let that=this
                Object.assign(this.selectMenu,item)
                this.$emit("change",item)


                that.audioMp3.src="/source/mp3/restart.mp3";
                that.audioMp3.load()
                that.audioMp3.play().then(r => {})
            }


        },
    });
})
