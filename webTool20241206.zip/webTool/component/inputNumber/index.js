define([
    "css!./index.css",
    "util/event/on",
    "util/newFun/newObject",
    "util/copy/deepMerge"
],
    function (css, on,  newObject, deepMerge) {
        function Fun(param) {
            let that = this
            that.options = {
                ele: null,
                key: "key",
                name: "text",
                value: 0,
                min: 0,
                max:99999,
                controlsPosition:"right",
                list: [],
                chnage: function (v, i) { }
            }
            deepMerge(that.options, param)

            that.refresh();


            that.options.ele.on("click", ".handleDown", function (ele) {

                if (that.options.value > that.options.min) {
                    that.options.value--;
                } else {
                    that.options.value = that.options.min;
                }
                that.refreshValue()
                that.options.chang && that.options.chang(that.options.value);
            })

            that.options.ele.on("click", ".handleUp", function (ele) {

                if (that.options.value < that.options.max) {
                    that.options.value++;
                } else {
                    that.options.value = that.options.max;
                }
                that.refreshValue()
                that.options.chang && that.options.chang(that.options.value);
            })

            that.options.ele.on("blur", ".inputNumber", function (ele) {
                let value = ele.value;
                if (value > that.options.max) {
                    ele.v
                } else {
                    that.options.value = that.options.max;
                }
                that.refreshValue()
                that.options.chang && that.options.chang(that.options.value);
            })



            that.options.ele.on("change", ".inputNumber", function (ele) {

                if (!ele) { return;}
                let value = ele.value;
                if (value > that.options.max) {
                    ele.value = that.options.max;
                }
                if (value < that.options.min) {
                    ele.value = that.options.min;
                }
                that.options.value = ele.value;             
                that.options.chang && that.options.chang(that.options.value);
            })
        };



        Fun.prototype.refreshValue = function () {
            let that = this;
            let input = that.options.ele.querySelector(".inputNumber");
            if (input) {
                input.value = that.options.value;
            }
        }



        Fun.prototype.refreshValue = function () {
            let that = this;
            let input=  that.options.ele.querySelector(".inputNumber");
            if (input) {
                input.value = that.options.value;
            }
        }
        Fun.prototype.refresh = function () {
            let that = this;
            that.html = `
                <div class="input-number ${that.options.controlsPosition}">
                    <input type="number" value="${that.options.value}" class="inputNumber" name="inputNumber" min="${that.options.min}" max="${that.options.max}">
                    <span class="handleDown">-</span>
                    <span  class="handleUp" >+</span>
                </div>
            `;
           
            that.options.ele.innerHTML = that.html;
        }

        return function (selecor, param) {
            return newObject(selecor, param, Fun);
        }
    })

