define(["vue","text!@/headerPc/index.html","css!@/headerPc/index.css"],function (Vue,template){
    Vue.component("header-pc",{
        props:{
            "headerList": {
                type:Array,
                required: true,
                default:function () {
                    return []
                }
            },
        },
        data:function () {
            return {
                thisList:[]
            }
        },
        created:function(){
            let  that=this
            this.$nextTick(function () {})
        },
        methods:{
            normalFunction:function (item,type,otherInfo) {
                let  that=this
                if(type==='redirectUrl'){
                    if(!item||!item.url){
                        return
                    }
                    window.location=item.url
                    return
                }
                console.log('test')
            },
        },
        template:template
    })
})
