define([
    "vue","text!@/navCard/index.html",
    "css!@/navCard/index.css"],
    function (Vue,html) {
    // 导航卡片
    Vue.component('m-nav-card', {
        template: html,
        data: function() {
            return {
                navList: [],
            }
        },
        props: {
            //接收父组件的value
            "theme": {
                type: String,
                default:function () {
                    return "bright"
                }
            },
            "cardInfo":{
                type:Object,
                default:function () {
                    return {
                        "name":"",
                        "description":"",
                        "url":""
                    }
                }
            }
        },
        methods: {
            openUrlFun:function (item) {
                window.location.href=this.cardInfo["url"];
            },

        },
    })
});
