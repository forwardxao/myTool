﻿define([
    "css!./index.css",
    "util/event/on",
    "util/Dom/isDom",
    "util/check/isFunction",
    "util/check/isArray",
    "util/check/isObject",
    "util/newFun/newObject",
    "util/copy/deepMerge"
], function (css, on, isDom, isFunction, isArray, isObject, newObject, deepMerge) {
        function Fun(param) {



        let that = this
        that.options = {
            ele: null,
            title: '标题',
            contentWidth: "80%",
            show:false,
            "position": "",
            "boxShadow": "",
        }

        deepMerge(that.options, param)
        that.getHtml();

        that.options.ele.on("click", ".close-drawer", function (ele) {
            that.toggle();
        })

    };
        Fun.prototype.getHtml = function () {
            let that = this;
            let html = `
                <div class="m-drawer ${getClass()}" >
                  <div class="close-drawer " ></div>
                  <div class="content" style="width:${that.options.contentWidth};">
                  </div>
                </div>
            `

            
            that.options.ele.innerHTML = html;

            function getClass() {
                if (that.options.show) {
                    return "show";
                }
                return "";
            }
        }


        Fun.prototype.setHtml = function (html) {
            let that = this;
            that.options.ele.querySelector(".content").innerHTML = html;
        }


        Fun.prototype.toggle = function () {
            let that = this;
            that.options.ele.querySelector(".m-drawer").classList.toggle("show")
        }

        Fun.prototype.show = function () {
            let that = this;
            that.options.ele.querySelector(".m-drawer").classList.add("show")
        }
        Fun.prototype.hide = function () {
            let that = this;
            that.options.ele.querySelector(".m-drawer").classList.remove("show")
        }

        return function (selecor, param = {}) {
            return newObject(selecor, param, Fun);
        }

})

