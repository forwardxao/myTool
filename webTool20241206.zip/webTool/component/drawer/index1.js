define(["vue","text!@/drawer/index.html","css!@/drawer/index.css"],function (Vue,template){
    Vue.component("m-drawer", {
        template:template,
        props: {
            model:{
                prop:"value",
                event:"input"
            },

            position:{
                type: String,
                default:function () {
                    return "fixed"
                }
            },
            headerTitle:{
                type: String,
                default:function () {
                    return "myTool"
                }
            },

            headerList: {
                type: Array,
                default:function () {
                    return []
                }
            },


            visible: {
                type: Boolean,
                default: false
            },


            //showDrawer
            size: {
                type: [Number, String],
                default: '80%'
            },

        },

        computed: {
            isHorizontal() {
                return this.direction === 'rtl' || this.direction === 'ltr';
            },
            drawerSize() {
                let _style="width:"+this.size;
                if(typeof this.size === 'number'){
                    _style+="px";
                }
                return _style;
            }
        },
        data:function(){
            return {}
        },
        created:function(){},
        methods: {
            normalFunction:function (item,type) {},
            closeDrawer:function () {
                this.$emit("update:visible",!1)
            },
            afterEnter() {
                this.$emit('opened');
            },
            afterLeave() {
                this.$emit('closed');
            },
        },
    });
})
