define([
    "vue",
    "text!@/searchBox/index.html",
    "css!@/searchBox/index.css"
],function (Vue,template) {
    Vue.component ("m-search-box",{
        template:template,
        props:{
            "model":{
                prop:"value",
                event:"input"
            },
            "value":{
                type:String,
                default:function () {
                    return ""
                }
            },
            "placeholder":{
                type:String,
                default:function () {
                    return ""
                }
            },
            "size":{
                type:String,
                default:function () {
                    return "middle"
                }
            },
            "clear":{
                type:Boolean,
                default:function () {
                    return false
                }
            }
        },

        data:function(){
            return {
                show:true
            }
        },

        watch:{
            "value":function (newVal,oldVal){
                // debugger
                this.$emit("input",newVal)
            }
        },
        methods:{
            clearFun:function(){
                this.value=""
            },



            enterEvent:function(){
                this.$emit("enterevent",this.value);
            },

            notEmpty:function(){
                return true
                // return !this.value
            }


        },
    })
})

