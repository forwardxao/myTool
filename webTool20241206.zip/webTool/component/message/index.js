define([
    "vue",
    "text!@/message/index.html",
    "css!@/message/index.css"
], function (Vue,template) {

    function s(selector) {
        let selectors = document.querySelectorAll(selector);
        return selectors[selectors.length - 1];
    }
    let Message= Vue.extend({

        template:template,
        props: {
            type: {
                type: String,
                default: "default"
            },
        },
        data:function(){
            return {
                activeView: "",
                show: false,
                options: {
                    "content":"",
                    "confirmText":"确认",
                    "cancelText":"取消",
                    "showClose":true,
                    "showConfirm":true,
                    "showCancel":true
                }
            }
        },

        mounted () {
            setTimeout(()=>{
                s('.wc-messagebox__btn--then') && s('.wc-messagebox__btn--then').addEventListener('click', this.success, false);
                s('.wc-messagebox__btn--catch') && s('.wc-messagebox__btn--catch').addEventListener('click', this.fail, false);
            }, 401);
        },
        created:function(){

        },
        methods: {
            handleClick(evt) {
                this.$emit('click', evt);
            },


            closeFun:function(){
                let that=this
                that.show=false;
                this.fail()
            },
            cancelFun:function(){
                let that=this
                that.show=false;
                this.fail()

            },
            confirmFun:function(){
                let that=this
                that.show=false;
                this.success()
            },

            success () {
                this.show = false;
            },

            fail () {
                this.show = false;
            }
        }
    })
    let isShowing = false;
    let q = [];
    let message = (options) => {
        let instance
        if (!isShowing) {
            /* 创建 instance */
            instance = new Message({
                el: document.createElement('div')
            })
            /* 追加到 DOM 元素上面 */
            document.body.appendChild(instance.$el)
            isShowing = true
        } else {
            q.push(options);
            return;
        }
        /* 用来支持 this.$alert(string) 的调用方式 */
        if (typeof options === 'string') {
            options = {
                content: options
            }
        }

        Object.assign(instance.$data.options,options)
        return new Promise((resolve, reject) => {
            instance.show = true
            let success = instance.success
            let fail = instance.fail;

            instance.success = () => {
                success()
                resolve('ok')
                isShowing = false
                if (q.length > 0) {
                    message(q.shift())
                }
                instance.$data.options.success&&instance.$data.options.success()
            }
            instance.fail = () => {
                fail();
                reject&&reject('fail');
                isShowing = false
                if (q.length > 0) {
                    message(q.shift())
                }
                instance.$data.options.fail&&instance.$data.options.fail()

            }



        })
    }

    Vue.prototype.$message = message
});


