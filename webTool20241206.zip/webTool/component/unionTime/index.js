define([
        "vue",
        "text!@/selectButton/index.html",
        "css!@/selectButton/index.css"],
    function (Vue,template) {
        Vue.component("m-uniontime",{
            props: ["value"],
            model:{
                prop:"value",
                event:"input"
            },
            watch:{
                value: {
                    handler(newVal, oldVal) {
                        if(!newVal){
                            this.baseInfo.dataTips="点击选择时间"
                        }
                    },
                    immediate: false
                }

            },


            data:function () {
                return {
                    baseInfo: {
                        moreYear:0,
                        yearSelect:null,
                        timeTypeSelect:null,
                        frequencySelect:null,
                        timeTypeName:'',
                        tipsLeft:'120px',
                        dataTips:"点击选择时间",
                        tipsText:"",
                        tipsShow:false,
                        selectShow:false
                    },
                    timeTypeList:[
                        {name:'月份',value:'01',type:'month',isSelected:false},
                        {name:'季度',value:'001',type:'quarter',isSelected:false},
                        {name:'年度',value:'0001',type:'year',isSelected:false}
                    ],
                    monthList:[
                        {name:'1月份', value:'01',type:'month', isSelected:false},
                        {name:'2月份', value:'02', type:'month',isSelected:false},
                        {name:'3月份', value:'03', type:'month',isSelected:false},
                        {name:'4月份', value:'04',type:'month', isSelected:false},
                        {name:'5月份', value:'05', type:'month',isSelected:false},
                        {name:'6月份', value:'06', type:'month',isSelected:false},
                        {name:'7月份', value:'07',type:'month', isSelected:false},
                        {name:'8月份', value:'08',type:'month', isSelected:false},
                        {name:'9月份', value:'09',type:'month', isSelected:false},
                        {name:'10月份', value:'10',type:'month', isSelected:false},
                        {name:'11月份', value:'11',type:'month', isSelected:false},
                        {name:'12月份', value:'12', type:'month',isSelected:false},

                        {name:'1季度', value:'001',type:'quarter', isSelected:false},
                        {name:'2季度', value:'002',type:'quarter', isSelected:false},
                        {name:'3季度', value:'003', type:'quarter',isSelected:false},
                        {name:'4季度', value:'004', type:'quarter',isSelected:false},

                        {name:'上半年', value:'0001',type:'year', isSelected:false},
                        {name:'下半年', value:'0002',type:'year', isSelected:false},
                        {name:'年度', value:'00001',type:'year', isSelected:false}
                    ],
                    frequencyList:[],
                    yearList: [],
                    timeSelectList:[],
                }
            },
            created:function(){
                let  that=this
                let _date=new Date()

                let nowYear= _date.getFullYear()
                that.baseInfo.moreYear=nowYear
                that.normalFunction('','moreYear')
            },
            methods:{
                normalFunction:function (item,type,otherInfo) {
                    var  that=this

                    if(type==='blur'){
                        that.baseInfo.selectShow=false
                        return
                    }
                    if(type==='toggleSelectShow'){
                        that.baseInfo.selectShow=!that.baseInfo.selectShow
                        return
                    }
                    if(type==='moreYear'){
                        if(that.baseInfo.moreYear<1970){
                            return
                        }
                        for(let i=0;i<6;i++){
                            that.yearList.push({
                                name:that.baseInfo.moreYear-i,
                                value:that.baseInfo.moreYear-i,
                                isSelected:false
                            })
                        }
                        that.baseInfo.moreYear=that.baseInfo.moreYear-6
                        return
                    }

                    if(otherInfo==='current'){
                        if(that.baseInfo[type]===item.value){ //已选
                            return
                        }
                        that.baseInfo[type]=item.value

                        if(type==="yearSelect"){
                            let  timeTypeCurrentList=that.timeSelectList.filter(v=>v["type"]==="timeTypeSelect"&&v["yearSelect"]===that.baseInfo["yearSelect"])
                            let  frequencyCurrentList=that.timeSelectList.filter(v=>v["type"]==="frequencySelect"&&v["yearSelect"]===that.baseInfo["yearSelect"]&&v["timeTypeSelect"]===that.baseInfo["timeTypeSelect"])

                            that.timeTypeList.forEach(v=>v.isSelected=false) //取消选中
                            that.frequencyList.forEach(v=>v.isSelected=false)

                            for(let j=0,len2=timeTypeCurrentList.length;j<len2;j++){
                                for(let i=0,len=that.timeTypeList.length;i<len;i++){
                                    if(timeTypeCurrentList[j]["timeTypeSelect"]===that.timeTypeList[i]["value"]){
                                        that.timeTypeList[i]["isSelected"]=true //符合条件的选中
                                        break
                                    }
                                }
                            }

                            for(let j=0,len2=frequencyCurrentList.length;j<len2;j++){
                                for(let i=0,len=that.frequencyList.length;i<len;i++){
                                    if(frequencyCurrentList[j]["frequencySelect"]===that.frequencyList[i]["value"]){
                                        that.frequencyList[i]["isSelected"]=true
                                        break
                                    }
                                }
                            }
                        }

                        if(type==="timeTypeSelect"){
                            that.baseInfo.timeTypeName=item.name
                            that.frequencyList= that.monthList.filter(word => word.type===item.type);

                            let  frequencyCurrentList=that.timeSelectList.filter(v=>v["type"]==="frequencySelect"&&v["yearSelect"]===that.baseInfo["yearSelect"]&&v["timeTypeSelect"]===that.baseInfo["timeTypeSelect"])

                            that.frequencyList.forEach(v=>v.isSelected=false)
                            for(let j=0,len2=frequencyCurrentList.length;j<len2;j++){
                                for(let i=0,len=that.frequencyList.length;i<len;i++){
                                    if(frequencyCurrentList[j]["frequencySelect"]===that.frequencyList[i]["value"]){
                                        that.frequencyList[i]["isSelected"]=true
                                        break
                                    }
                                }
                            }
                        }
                        return
                    }
                    if(type==='yearSelect'){
                        item.isSelected=!item.isSelected
                        that.baseInfo[type]=item.value
                        that.baseInfo.tipsShow=false
                        that.normalFunction(item,"filterTimeList",type)
                        return
                    }
                    if(type==='timeTypeSelect'){
                        if(!that.baseInfo['yearSelect']){
                            that.baseInfo.tipsLeft='120px'
                            that.baseInfo.tipsShow=true
                            that.baseInfo.tipsText="请选择年度"
                            return
                        }
                        item.isSelected=!item.isSelected
                        that.baseInfo[type]=item.value
                        that.frequencyList= that.monthList.filter(word => word.type===item.type);
                        that.baseInfo.timeTypeName=item.name
                        that.normalFunction(item,"filterTimeList",type)
                        return
                    }
                    if(type==='frequencySelect'){
                        item.isSelected=!item.isSelected
                        that.baseInfo[type]=item.value
                        that.normalFunction(item,"filterTimeList",type)
                        return
                    }

                    if(type==='filterTimeList'){
                        if(item.isSelected){
                            let _item={
                                value:item.value,
                                name:item.name,
                                type:otherInfo,
                                "yearSelect":that.baseInfo['yearSelect'],
                                "timeTypeSelect":null,
                                "frequencySelect":null
                            }

                            if(otherInfo==="timeTypeSelect"){
                                for(let i=0,len=that.yearList.length;i<len;i++){
                                    if(that.yearList[i].value===that.baseInfo["yearSelect"]){
                                        if(!that.yearList[i].isSelected){
                                            that.yearList[i].isSelected=true
                                            that.timeSelectList.push(
                                                {
                                                    value:that.baseInfo['yearSelect'],
                                                    name:that.baseInfo['yearSelect'],
                                                    type:"yearSelect",
                                                    "yearSelect":that.baseInfo['yearSelect'],
                                                    "timeTypeSelect":null,
                                                    "frequencySelect":null
                                                }
                                            )
                                        }
                                        break
                                    }
                                }

                                _item["timeTypeSelect"]=that.baseInfo['timeTypeSelect']
                            }
                            if(otherInfo==="frequencySelect"){

                                for(let j=0,len2=that.timeTypeList.length;j<len2;j++){
                                    if(that.timeTypeList[j].value===that.baseInfo["timeTypeSelect"]){
                                        if(!that.timeTypeList[j].isSelected){
                                            that.timeTypeList[j].isSelected=true

                                            that.timeSelectList.push(
                                                {
                                                    value:that.baseInfo['timeTypeSelect'],
                                                    name:that.baseInfo['timeTypeSelect'],
                                                    type:"timeTypeSelect",
                                                    "yearSelect":that.baseInfo['yearSelect'],
                                                    "timeTypeSelect":that.baseInfo['timeTypeSelect'],
                                                    "frequencySelect":null
                                                }
                                            )

                                            for(let i=0,len=that.yearList.length;i<len;i++){
                                                if(that.yearList[i].value===that.baseInfo["yearSelect"]){
                                                    if(!that.yearList[i].isSelected){
                                                        that.timeSelectList.push(
                                                            {
                                                                value:that.baseInfo['yearSelect'],
                                                                name:that.baseInfo['yearSelect'],
                                                                type:"yearSelect",
                                                                "yearSelect":that.baseInfo['yearSelect'],
                                                                "timeTypeSelect":null,
                                                                "frequencySelect":null
                                                            }
                                                        )
                                                        that.yearList[i].isSelected=true
                                                    }
                                                    break
                                                }
                                            }
                                        }
                                        break
                                    }
                                }
                                _item["timeTypeSelect"]=that.baseInfo['timeTypeSelect']
                                _item["frequencySelect"]=that.baseInfo['frequencySelect']
                            }
                            that.timeSelectList.push(_item)

                        }else{
                            let _list=[]
                            for(let i=0,len=that.timeSelectList.length;i<len;i++){
                                if(that.timeSelectList[i][otherInfo]===item.value){
                                    continue
                                }
                                _list.push(that.timeSelectList[i])
                            }
                            that.timeSelectList=_list
                        }

                        if(otherInfo==="yearSelect"){
                            that.timeTypeList.forEach(item=>{
                                item.isSelected=false
                            })
                            that.frequencyList.forEach(item=>{
                                item.isSelected=false
                            })
                        }

                        if(otherInfo==="timeTypeSelect"){
                            that.frequencyList.forEach(item=>{
                                item.isSelected=false
                            })
                        }
                        return
                    }

                    if(type==='confirm'){
                        let str=""
                        for(let i=0,len=that.timeSelectList.length;i<len;i++){
                            if(that.timeSelectList[i]["type"]==="yearSelect"){
                                continue
                            }
                            if(that.timeSelectList[i]["type"]==="timeTypeSelect"){
                                continue
                            }
                            str+=","+that.timeSelectList[i]["yearSelect"]+"-"+that.timeSelectList[i]["frequencySelect"]
                        }
                        str=str.substr(1)
                        that.baseInfo.dataTips=str.length>0?"已选择":"点击选择时间"
                        this.$emit("input",str)
                        that.baseInfo.selectShow=false
                        return
                    }
                    console.log('test')
                }
            },
            template:template
        })
    });
