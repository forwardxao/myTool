define(function () {
   return function (param) {
        //Ĭ������
        var defaultSettings = {
            txt: "",
            x: 20, 
            y: 70, 
            rows: 10, //ˮӡ����
            cols: 10, //ˮӡ����
            x_space: 350, //ˮӡx����
            y_space: 260, //ˮӡy����
            color: '#999999', //ˮӡ������ɫ
            alpha: 0.5, //ˮӡ͸����
            fontsize: '14px', //ˮӡ�����С
            fontFamily: '΢���ź�', 
            width: 'auto', 
            height: 'auto', 
            angle: -15, //ˮӡ��б����
            zIndex: 999
        };

        //�����������滻Ĭ��ֵ
        Object.assign(defaultSettings, param)

        var x;
        var y;
        var page_width = Math.max(document.body.scrollWidth, document.body.clientWidth);
        var page_height = Math.max(document.body.scrollHeight, document.body.clientHeight);
        var style = `
            font-family: ${defaultSettings.fontFamily};
            transform: rotate(${defaultSettings.angle}deg);
            opacity: ${defaultSettings.alpha};
            font-size: ${defaultSettings.fontsize};
            color: ${defaultSettings.color};
            width: ${defaultSettings.width};
            height: ${defaultSettings.height};
            z-index: ${defaultSettings.zIndex};
            pointer-events: none;
            position: fixed;
            overflow: hidden;
            text-align: center;
            display: inline-block;
            white-space: nowrap;
            user-select: none;
        `;

       let html = ``;
        for (var i = 0; i < defaultSettings.rows; i++) {
            y = defaultSettings.y + (defaultSettings.y_space) * i;
            if (y > page_height) {
                // ������Ļ�Ĳ���Ⱦ
                break;
            }
            for (var j = 0; j < defaultSettings.cols; j++) {
                x = defaultSettings.x + (defaultSettings.x_space) * j;

                if (x > page_width) {
                    // ������Ļ�Ĳ���Ⱦ
                    break;
                }

                let stylexy = `left:${x}px;top:${y}px;`;
                html += `<div id="mask_div${i}${j}" style="${style}${stylexy}">${defaultSettings.txt}</div>`
            };
       };

       let div = document.createElement("div");
       div.innerHTML = html
       document.body.appendChild(div);
    }
})

