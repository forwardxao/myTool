define([
    "vue",
    "text!@/selectButton/index.html",
    "css!@/selectButton/index.css"],
    function (Vue,html) {
    Vue.component("m-select-button", {
        template:html,
        props: {
            model:{
                prop:"value",
                event:"input"
            },
            value:{
                type:Array||String,
                default:function () {
                    return []
                }
            },
            text: {
                type: String,
                default: "text"
            },
            key: {
                type: String,
                default: "key"
            },

            list: {
                type: Array,
                default: function () {
                    return []
                }
            },

            multiple: {
                type: Boolean,
                default: false
            },
        },

        data:function(){
            return {
                //selectKeyObject:{ }
            }
        },
        created:function(){
            let that=this
            // if((typeof that.value) ==="string" ){
            //     that.value=[that.value]
            // }
           // debugger
        },
        methods: {
            getClass:function (item){
                let that=this
                let _class="";
                if(!item.hasOwnProperty(this.key)){
                    return _class
                }
                if(that.multiple){
                    if(this.value.includes(item[this.key])){
                        _class="selected";
                    }
                }else{
                    // debugger
                    if(this.value===item[this.key]){
                        _class="selected";
                    }
                }
                return _class
            },

            selectItemFun:function (item){

                if(!item.hasOwnProperty(this.key)){
                    return
                }

                let that=this
                let _value=[]

                if(that.multiple){
                    //debugger
                    let selectKeyObject={}
                    if(!(this.value in  Array)){
                        this.value=[]
                    }
                    this.value.forEach(v=>{
                        selectKeyObject[v]=""
                    })

                    if(selectKeyObject.hasOwnProperty(item[that.key])){
                        delete selectKeyObject[item[that.key]]
                    }else{
                        selectKeyObject[item[that.key]]=""
                    }
                    for(let x in selectKeyObject){
                        _value.push(x)
                    }
                }else{
                    _value=item[this.key]
                }
                if(JSON.stringify(_value)===JSON.stringify(this.value)){
                    return;
                }

                if(that.multiple){
                    this.value=[].concat(_value)
                }else{
                    this.value=_value
                }
                this.$emit("input",_value)
                this.$emit("change", _value)
            }
        },
    });
});


