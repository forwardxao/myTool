define(["vue","text!@/footerPc/index.html","css!@/footerPc/index.css"],function (Vue,template){
    Vue.component("footer-pc",{
        template:template,
        props:{},
        data() {
            return { }
        },
        methods:{
            go_page:function (item){},
        },

    })
})






