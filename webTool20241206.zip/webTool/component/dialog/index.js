define(["css!./index.css"], function (css) {

    var DIALOG = 'dialog';
    var CL = {
        add: function () {
            return ['ui', DIALOG].concat([].slice.call(arguments)).join('-');
        },
        toString: function () {
            return 'ui-' + DIALOG;
        }
    };
    // �ر�SVG
    var strCloseSvg = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><path d="M116.152,99.999l36.482-36.486c2.881-2.881,2.881-7.54,0-10.42 l-5.215-5.215c-2.871-2.881-7.539-2.881-10.42,0l-36.484,36.484L64.031,47.877c-2.881-2.881-7.549-2.881-10.43,0l-5.205,5.215 c-2.881,2.881-2.881,7.54,0,10.42l36.482,36.486l-36.482,36.482c-2.881,2.881-2.881,7.549,0,10.43l5.205,5.215 c2.881,2.871,7.549,2.871,10.43,0l36.484-36.488L137,152.126c2.881,2.871,7.549,2.871,10.42,0l5.215-5.215 c2.881-2.881,2.881-7.549,0-10.43L116.152,99.999z"/></svg>';

    var isSupportDialog = false;

    function Dialog(options) {
        var defaults = {
            title: '',
            // ��ͬ������������
            content: '',
            // ����Ŀ���
            width: 'auto',
            // ����߶�
            height: 'auto',
            // ��ͬ����Ĭ�ϰ�ť
            buttons: [],
            // ������ʾ�����ء��Ƴ��Ļص�
            onShow: function () { },
            onHide: function () { },
            onRemove: function () { }
        };
        // ���ղ���
        var objParams = Object.assign({}, defaults, options || {});


        // ����Ԫ�ش���
        // ����-����͸�����ֱ���
        var eleContainer = document.createElement(DIALOG);
        eleContainer.classList.add(CL.add('container'));
        // ʹ��Ԫ��Ҳ���Ա�focus
        eleContainer.setAttribute('tabindex', '-1');

        // �Ƿ�֧��ԭ������
        isSupportDialog = ('open' in eleContainer);

        // ��֧�ֵ�������������ϰ�������Ϣ
        if (isSupportDialog == false) {
            eleContainer.setAttribute('role', DIALOG);
        }

        // ��������
        var eleDialog = document.createElement('div');
        eleDialog.classList.add(CL);
        // ���óߴ�ͼ��̷�������
        // ����������õ��Ǵ���ֵ������Ϊ��px��λ
        if (/^\d+$/.test(objParams.width)) {
            eleDialog.style.width = objParams.width + 'px';
        } else {
            eleDialog.style.width = objParams.width;
        }
        // �߶�
        if (/^\d+$/.test(objParams.height)) {
            eleDialog.style.height = objParams.height + 'px';
        } else if (objParams.height == 'stretch') {
            eleDialog.classList.add(CL.add(objParams.height));
        } else if (objParams.height != 'auto') {
            eleDialog.style.height = objParams.height;
        }

        // ����
        var eleTitle = document.createElement('h4');
        eleTitle.classList.add(CL.add('title'));
        eleTitle.innerHTML = objParams.title;

        // �رհ�ť
        // ���id��ESC��ݼ��رյ����õ�
        var strIdClose = ('lulu_' + Math.random()).replace('0.', '');
        // �رհ�ťԪ�ش���
        var eleClose = document.createElement('button');
        eleClose.classList.add(CL.add('close'));
        eleClose.classList.add('ESC');
        // ���ϰ�֧��
        eleClose.setAttribute('aria-label', '�ر�');
        eleClose.id = strIdClose;
        eleClose.setAttribute('data-target', strIdClose);
        eleClose.innerHTML = strCloseSvg;

        // ��������
        var dataContent = objParams.content || '';
        // content�����Ǻ���
        if (typeof dataContent == 'function') {
            dataContent = dataContent();
        }

        // �������ݵ��������ͣ�ʹ�ò�ͬ��Ĭ�ϵĵ���رշ�ʽ
        if (typeof dataContent == 'string') {
            this.closeMode = 'remove';
        } else {
            this.closeMode = 'hide';
        }

        // ��������Ԫ��
        var eleBody = document.createElement('div');
        eleBody.classList.add(CL.add('body'));

        if (this.closeMode == 'remove') {
            eleBody.innerHTML = dataContent;
        } else {
            eleBody.appendChild(dataContent);
        }

        // �ײ�Ԫ��
        var eleFooter = document.createElement('div');
        eleFooter.classList.add(CL.add('footer'));

        // ��װ
        eleDialog.appendChild(eleClose);
        eleDialog.appendChild(eleTitle);
        eleDialog.appendChild(eleBody);
        eleDialog.appendChild(eleFooter);

        eleContainer.appendChild(eleDialog);

        // �����ϸ��
        // 1. ��������dialog��ǰ��
        // 2. ���û�У������ҳ�����
        var eleAllDialog = document.querySelectorAll(DIALOG);

        if (eleAllDialog.length) {
            eleAllDialog[0].insertAdjacentElement('beforebegin', eleContainer);
        } else {
            (objParams.container || document.body).appendChild(eleContainer);
        }

        // ��¶Ԫ��
        this.element = {
            container: eleContainer,
            dialog: eleDialog,
            close: eleClose,
            title: eleTitle,
            body: eleBody,
            footer: eleFooter
        };

        // ��¶һЩ����
        this.params = {
            title: objParams.title,
            width: objParams.width,
            buttons: objParams.buttons,
            content: dataContent
        };

        this.callback = {
            show: objParams.onShow,
            hide: objParams.onHide,
            remove: objParams.onRemove
        };

        this.display = false;

        // ��ť����
        this.button();

        // �¼�
        this.events();

        if (dataContent) {
            this.show();
        }

        return this;
    };

    Dialog.prototype.button = function () {
        var objParams = this.params;
        var objElement = this.element;

        objElement.footer.innerHTML = '';

        for (var keyElement in objElement) {
            if (/^button/.test(keyElement)) {
                delete objElement[keyElement];
            }
        }

        // ��ťԪ�ش���
        objParams.buttons.forEach(function (objButton, numIndex) {
            // objButton������null��
            objButton = objButton || {};

            // ��ť���ͺ�ֵ�Ĵ���
            var strType = objButton.type;
            var strValue = objButton.value;

            if (strType == 'remind' || (!strType && numIndex == 0)) {
                strType = 'primary';
            }

            if (!strValue) {
                strValue = ['ȷ��', 'ȡ��'][numIndex];
            }

            var eleButton = document.createElement('button');
            if (objButton['for']) {
                eleButton = document.createElement('label');
                eleButton.setAttribute('for', objButton['for']);
            }
            // �Զ��������
            if (objButton.className) {
                eleButton.className = objButton.className;
            }
            // ��ť��ʽ
            eleButton.classList.add(String(CL).replace(DIALOG, 'button'));
            if (strType) {
                eleButton.setAttribute('data-type', strType);
            }
            // ��ť����
            eleButton.innerHTML = strValue;

            // ���ڵײ�Ԫ����
            objElement.footer.appendChild(eleButton);

            // ���Ⱪ¶
            objElement['button' + numIndex] = eleButton;
        });

        // ��ť�¼�
        // �ײ�ȷ��ȡ����ť
        objParams.buttons.forEach(function (objButton, numIndex) {
            var eleButton = objElement['button' + numIndex];

            if (!eleButton || objButton['for']) {
                return;
            }

            var objEvents = objButton.events || {
                click: function () {
                    this[this.closeMode]();
                }.bind(this)
            };

            if (typeof objEvents == 'function') {
                objEvents = {
                    click: objEvents
                };
            }

            for (var strEventType in objEvents) {
                eleButton.addEventListener(strEventType, function (event) {
                    // ��ʵ��������
                    event.dialog = this;
                    // �¼�ִ��
                    objEvents[strEventType](event);
                }.bind(this));
            }

            // �����focus�¼�֧��
            eleButton.addEventListener('focus', function () {
                if (window.isKeyEvent) {
                    this.style.outline = '';
                } else {
                    this.style.outline = 'none';
                }
            });
        }.bind(this));
    };

    Dialog.prototype.events = function () {
        var objElement = this.element;

        // IE10+����CSS3����֧��
        var eleContainer = objElement.container;
        eleContainer.addEventListener('animationend', function (event) {
            if (event.target.tagName.toLowerCase() == DIALOG) {
                eleContainer.classList.remove(CL.add('animation'));
            }
        });
        if (isSupportDialog == true) {
            eleContainer.addEventListener('close', function () {
                // ����������
                this.scrollbar();
                // ��ʾ״̬�л�
                this.display = false;
                // ���̽���Ԫ�ػ�ԭ
                this.tabindex();
            }.bind(this));
        }

        // �رյ���ť
        var eleClose = objElement.close;
        if (eleClose) {
            eleClose.addEventListener('click', function () {
                // ��������ESCԪ�ش���ʱ�򣬵��򲻹ر�
                var eleActiveElement = document.activeElement;
                var attrActiveElement = eleActiveElement.getAttribute('data-target');
                var eleTargetElement = null;

                if (attrActiveElement) {
                    eleTargetElement = document.getElementById(attrActiveElement);
                }

                // ���������Ԫ�صļ��̷���
                if (window.isKeyEvent && eleTargetElement && eleActiveElement != eleClose && document.querySelector('a[data-target="' + attrActiveElement + '"],input[data-target="' + attrActiveElement + '"],button[data-target="' + attrActiveElement + '"]') && eleTargetElement.clientWidth > 0) {
                    return;
                }

                // �رյ���
                this[this.closeMode]();
            }.bind(this));
        }

        return this;
    };


    Dialog.prototype.open = function (content, options) {
        var objElement = this.element;

        // Ĭ�ϲ���
        // ֻ֧�ֱ���Ͱ�ť���Զ���
        var defaults = {
            title: '',
            buttons: []
        };

        var dataContent = content || '';
        // content�����Ǻ���
        if (typeof dataContent == 'function') {
            dataContent = dataContent();
        }

        // �������ݵ��������ͣ�ʹ�ò�ͬ��Ĭ�ϵĵ���رշ�ʽ
        if (typeof dataContent == 'string') {
            this.closeMode = 'remove';
        } else {
            this.closeMode = 'hide';
        }

        // ���ղ���
        this.params = Object.assign({}, defaults, options || {}, {
            content: dataContent
        });

        // ������ԭΪ��ʼ
        objElement.container.className = CL.add('container');

        // �滻��ǰ��������ݣ�������ť��
        if (this.closeMode == 'remove') {
            objElement.body.innerHTML = dataContent;
        } else {
            objElement.body.appendChild(dataContent);
        }
        objElement.title.innerHTML = this.params.title;
        // ��ť
        this.button();
        // ��ʾ
        this.show();

        return this;
    };

    Dialog.prototype.loading = function () {
        var objElement = this.element;

        objElement.container.className = [CL.add('container'), CL.add('loading')].join(' ');
        objElement.body.innerHTML = '<ui-loading rows="10" size="3"></ui-loading>';

        this.show();

        return this;
    };


    Dialog.prototype.alert = function (content, options) {
        var objElement = this.element;

        if (!content) {
            return;
        }

        var strContent = content;

        // alert���Ĭ�ϲ���
        var defaults = {
            title: '',
            // ����, 'remind', 'success', 'warning', danger', �������� 'custom'
            type: 'remind',
            buttons: [{}]
        };
        // ���ղ���
        var objParams = Object.assign({}, defaults, options || {});

        if (objParams.type == 'error' || objParams.type == 'fail') {
            objParams.type = 'danger';
        }
        if (objParams.type == 'primary') {
            objParams.type = 'remind';
        }

        if (objParams.buttons.length && !objParams.buttons[0].type) {
            objParams.buttons[0].type = objParams.type;
            // ������Զ������ͣ���ʹ��'primary'��Ϊ��ť����
            if (/^remind|success|warning|danger$/.test(objParams.type) == false) {
                objParams.buttons[0].type = defaults.type;
            }
        }

        // �滻��ǰ��������ݣ�������ť��
        objElement.container.className = [CL.add('container'), CL.add('container', 'alert')].join(' ');

        // �ߴ�
        objElement.dialog.style.width = 'auto';

        objElement.title.innerHTML = objParams.title;
        // ����Ǵ��ı�
        if (/<[\w\W]+>/.test(strContent) == false) {
            strContent = '<p>' + strContent + '</p>';
        }

        objElement.body.innerHTML = '<div class="' + CL.add(objParams.type) + ' ' + CL.add('alert') + '">' + strContent + '</div>';

        this.params = {
            width: 'auto',
            title: objParams.title,
            buttons: objParams.buttons,
            content: strContent
        };

        this.button();

        this.show();

        if (objElement.button0) {
            objElement.button0.focus();
        }

        return this;
    };

    Dialog.prototype.confirm = function (content, options) {
        var objElement = this.element;

        if (!content) {
            return;
        }

        var strContent = content;

        // confirm���Ĭ�ϲ���
        var defaults = {
            title: '',
            type: 'danger',
            buttons: [{}, {}]
        };
        // ���ղ���
        var objParams = Object.assign({}, defaults, options || {});

        if (objParams.type == 'error' || objParams.type == 'fail') {
            objParams.type = 'danger';
        }
        if (objParams.type == 'primary') {
            objParams.type = 'remind';
        }

        // danger���͵İ�ť��ȱʡ
        if (objParams.buttons.length && !objParams.buttons[0].type) {
            objParams.buttons[0].type = objParams.type;
            // ������Զ������ͣ���ʹ��'primary'��Ϊ��ť����
            if (/^remind|success|warning|danger$/.test(objParams.type) == false) {
                objParams.buttons[0].type = defaults.type;
            }
        }

        // �滻��ǰ��������ݣ�������ť��
        objElement.container.className = [CL.add('container'), CL.add('container', 'confirm')].join(' ');

        // �ߴ�
        objElement.dialog.style.width = 'auto';

        objElement.title.innerHTML = objParams.title;
        // ����Ǵ��ı�
        if (/<[\w\W]+>/.test(strContent) == false) {
            strContent = '<p>' + strContent + '</p>';
        }

        objElement.body.innerHTML = '<div class="' + CL.add(objParams.type) + ' ' + CL.add('confirm') + '">' + strContent + '</div>';

        this.params = {
            width: 'auto',
            title: objParams.title,
            buttons: objParams.buttons,
            content: strContent
        };

        this.button();

        this.show();

        if (objElement.button0) {
            objElement.button0.focus();
        }


        return this;
    };


    Dialog.prototype.scrollbar = function () {
        var eleAllDialog = document.querySelectorAll(DIALOG);

        // �Ƿ�����ʾ�ĵ���
        var isDisplayed = [].slice.call(eleAllDialog).some(function (eleDialog) {
            return window.getComputedStyle(eleDialog).display != 'none';
        });

        // ��Ϊȥ���˹����������Կ�����Ҫƫ�ƣ���֤ҳ������û�лζ�
        if (isDisplayed) {
            var widthScrollbar = 17;
            if (this.display != true) {
                widthScrollbar = window.innerWidth - document.documentElement.clientWidth;
            }
            // ����PC���������������
            document.documentElement.style.overflow = 'hidden';

            if (this.display != true) {
                document.body.style.borderRight = widthScrollbar + 'px solid transparent';
            }
        } else {
            document.documentElement.style.overflow = '';
            document.body.style.borderRight = '';
        }

        return this;
    };

    Dialog.prototype.tabindex = function () {
        var eleDialog = this.element.dialog;
        var eleLastActiveElement = this.lastActiveElement;

        if (this.display == true) {
            var eleActiveElement = document.activeElement;
            if (eleDialog != eleActiveElement) {
                this.lastActiveElement = eleActiveElement;
            }

            // ����������ʼλ�ñ�Ϊ�ڵ���Ԫ����
            if (eleDialog) {
                eleDialog.focus();
            }
        } else if (eleLastActiveElement && eleLastActiveElement.tagName.toLowerCase() != 'body') {
            // ���̽���Ԫ�ػ�ԭ
            eleLastActiveElement.focus();
            eleLastActiveElement.blur();
            this.lastActiveElement = null;
        }

        return this;
    };

    Dialog.prototype.zIndex = function () {
        var eleContainer = this.element.container;
        // ����eleTarget���ǵ���ʽ�������
        var objStyleTarget = window.getComputedStyle(eleContainer);
        // ��ʱԪ�صĲ㼶
        var numZIndexTarget = objStyleTarget.zIndex;
        // �����ԱȵĲ㼶��Ҳ����С�㼶
        var numZIndexNew = 19;

        // ֻ��<body>��Ԫ�ؽ��в㼶��󻯼��㴦��
        document.body.childNodes.forEach(function (eleChild) {
            if (eleChild.nodeType != 1) {
                return;
            }

            var objStyleChild = window.getComputedStyle(eleChild);

            var numZIndexChild = objStyleChild.zIndex * 1;

            if (numZIndexChild && eleContainer != eleChild && objStyleChild.display != 'none') {
                numZIndexNew = Math.max(numZIndexChild + 1, numZIndexNew);
            }
        });

        if (numZIndexNew != numZIndexTarget) {
            eleContainer.style.zIndex = numZIndexNew;
        }
    };


    Dialog.prototype.show = function () {
        var eleContainer = this.element.container;
        // �����ʾ
        if (isSupportDialog) {
            if (!eleContainer.open) {
                eleContainer.show();
            }
        } else {
            eleContainer.setAttribute('open', 'open');
            // �㼶���
            this.zIndex();
        }

        if (this.display != true) {
            eleContainer.classList.add(CL.add('animation'));
        }
        this.scrollbar();
        this.display = true;

        this.tabindex();

        if (typeof this.callback.show == 'function') {
            this.callback.show.call(this, eleContainer);
        }

        return this;
    };


    Dialog.prototype.hide = function () {
        var eleContainer = this.element.container;

        if (isSupportDialog) {
            eleContainer.close();
        } else {
            eleContainer.removeAttribute('open');
        }

        // ����������
        this.scrollbar();
        // ��ʾ״̬�л�
        this.display = false;
        // ���̽���Ԫ�ػ�ԭ
        this.tabindex();

        if (typeof this.callback.hide == 'function') {
            this.callback.hide.call(this, eleContainer);
        }

        return this;
    };


    Dialog.prototype.remove = function () {
        var eleContainer = this.element.container;

        eleContainer.remove();
        // ����������
        this.scrollbar();
        // ��ʾ״̬�л�
        this.display = false;
        // ���̽���Ԫ�ػ�ԭ
        this.tabindex();

        if (typeof this.callback.remove == 'function') {
            this.callback.remove.call(this, eleContainer);
        }

        return this;
    };

    return new Dialog({});
})