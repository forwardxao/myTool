define([
    "css!./index.css",
    "util/event/on",
    "util/copy/copyObject",
],
    function (css, on, copyObject) {
        function Fun(param) {
            let that = this
            that.options = {
                messsage: "ff",
                type: "normal",
                title: "��ʾ��",
                confirm:"ȷ��",
                className: "dialog_alert",
                preFix: "mt_",
                callBack: function (v, i) {

                }
            }

            copyObject(that.options, param);

            that.html = ``;

            this.getTemplate();
        };

        Fun.prototype.getTemplate = function (v, i) {
            let that = this;

            let dialogAlert = document.querySelector("." + that.options.preFix+that.options.className);
            if (dialogAlert == null) {
                let div = document.createComment("div");
                div.classList.add(that.options.preFix + that.options.className)

                let html = `
                    <div class="masking"></div>
                    <div class="content_container">
                        <div class="title">
                            <div class="content">${that.options.title}</div>
                            <div></div>
                        </div>
                        <div class="content">${that.options.messsage}</div>
                        <div class="action">
                            <div>${that.options.confirm}</div>
                        </div>
                    </div>
                `

                html.replace(/class="/)


                document.body.appendChild(div);
            } else {


            }

        }

        Fun.prototype.hide = function (v, i) {
            let that = this;
            let dialogAlert = document.querySelector("." + that.options.preFix + that.options.className);
            dialogAlert.classList.add("hide");

        }
        Fun.prototype.hide = function (v, i) {
            let that = this;
            let dialogAlert = document.querySelector("." + that.options.preFix + that.options.className);
            dialogAlert.classList.add("show");

        }



        return function (param) {
            new Fun(param);
        }

    })