define([],
    function () {
        return  function(msg, duration) {
                //��ʾ��Ϣ ��װ
            duration = isNaN(duration) ? 3000 : duration;

            var m = document.querySelector(".mt_toast");
            if (m == null) {
                m = document.createElement('div');
                m.classList.add("mt_toast");
                m.style.cssText = `
                    font-size: .32rem;
                    color: rgb(255, 255, 255);
                    background-color: rgba(0, 0, 0, 0.6);
                    padding: 10px 15px;
                    margin: 0 0 0 0;
                    border-radius: 4px;
                    position: fixed;
                    top: 5%;
                    left: 50%;
                    text-align: center;
                    z-index:9999;
                    display:inline-block;
                `;
                document.body.appendChild(m);
            }
                m.innerHTML = msg;
                setTimeout(function () {
                    var d = 0.5;
                    m.style.opacity = '0';
                }, duration);
            }  
    })