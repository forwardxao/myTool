﻿define([
    "css!./index.css",
    "util/newFun/index",
    "util/copy/copyObject",
    "util/request/ajax",
],
    function (css, newFun, copyObject, ajax) {
        function Fun(param) {
            let that=this
             that.options = {
                ele:null,
                url: "",
                callBack: function (v,i) {

                }
            }
            copyObject(that.options, param);
            ajax({
                url: that.options.url,
                success: function (res) {
                    that.options.ele.innerHTML = `<pre>${res}</pre>`;
                },
            })
        };

        return function (selecor, param) {
            newFun(selecor, param, Fun);
        }

})