define([
    "util/time/timeFormat",
    "util/url/addParam",
],
    function (timeFormat, addParam) {
    addParam("time",timeFormat("","yyyyMMddhh"))
})