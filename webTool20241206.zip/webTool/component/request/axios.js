define([
    "util/request/axios",
    "util/copy/copyObject",
],
    function (axios, copyObject) {
        function Fun(param) {
            let that = this
            that.options = {
                method: "GET",
                url:"",
                originalUrl: false,
                success: function (res) {

                },
                error: function (res) {

                },
                finally: function (res) {

                },
            }

            copyObject(that.options, param)

            let data = {
                method: that.options.method
            };

            if (param["originalUrl"]) {
                data["url"] = that.options.url
            } else {
                data["url"] = baseUrl + that.options.url
            }
            if (that.options.method === "get") {
                that.options.data["refreshCache"] = localStorage.getItem("refreshCache") || (Date.now() + "")
                data["params"] = that.options.data
            }
            if (that.options.method === "post") {
                data["data"] = that.options.data
            }
            if (!that.options.hasOwnProperty("convertToHumpNaming")) {
                param["convertToHumpNaming"] = true;
            }
            axios(data).then(function (result) {
                let data = result.data || {};
                if (that.options.originalData) {
                    that.options.success && that.options.success(data)
                    return;
                }

                if (data.code !== 200) {
                    that.options.error && that.options.error(data.msg);
                    return;
                }
                that.options.success && that.options.success(data.data)
            })
                .catch(function (error) {
                    that.options.error && that.options.error(error)
                })
                .finally(() => {
                    that.options.finally && that.options.finally()
                });

        };

        return function (param) {
            new Fun(param)
        }

    })


