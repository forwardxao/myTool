define([
    "vue",
    "text!@/introduction/index.html",
    "css!@/introduction/index.css",

    "component/selectButton/index",


],function (Vue,template){
    Vue.component("m-introduction", {
        template:template,
        props: {
            "model":{
                prop:"value",
                event:"input"
            }
        },
        data:function(){
            return {
                "selectCode":"",
                "usualList":[
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},

                ],
                "lifeList":[
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},

                ],

                "workList":[
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},

                ],

                "studyList":[
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},
                    {name:"ww", code:"cc"},

                ],


            }
        },
        created:function(){

        },
        methods: {

        }
    });
})