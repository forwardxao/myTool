define([
    "css!./index.css",
    "util/event/on",
    "util/check/isArray",
    "util/check/isFunction",
    "util/Dom/isDom",
    "util/Dom/siblings",
    "util/newFun/newObject",

    "util/copy/deepMerge"
],
    function (css, on, isArray, isFunction, isDom, siblings, newObject,deepMerge) {
        function Fun(param) {

            let that=this
            that.options = {
                 ele: null,
                 key: "key",
                 name: "text",
                 multiple:false,
                 value:"",
                 list: [],
                change: function (v,i) {}
            }
            deepMerge(that.options, param)

            that.refresh();

           
            that.options.ele.on("click", ".mt_item", function (ele) {

                if (that.options.multiple) {
                    that.selectItemMultiple(ele)
                } else {
                    that.selectItem(ele)
                }
            })
        };


        Fun.prototype.selectItem = function (ele) {
            let that = this;
            if (ele.classList.contains("active")) {
                return;
            }

            ele.classList.add("active");
            let siblings = ele.siblings(".active");

            for (let i = 0, len = siblings.length; i < len; i++) {
                let v = siblings[i];
                v.classList.remove("active");
            }

            that.options.change && that.options.change(ele.dataset.key);
        }


        Fun.prototype.selectItemMultiple = function (ele) {
            let that = this;
            
            ele.classList.toggle("active");

            let activeList = ele.parentNode.querySelectorAll(".active");

            let vals = [];
            for (let i = 0, len = activeList.length; i < len; i++) {
                let v = activeList[i];
                vals.push(v.dataset.key);
            }
            that.options.change && that.options.change(vals);
        }

        Fun.prototype.refresh = function (list) {
            let that = this;
            that.html = `<div class="mt_list_button">`;

            if (isArray(list)) {
                that.options.list = list;
            }
            for (let i = 0, len = that.options.list.length; i < len; i++) {
                let v = that.options.list[i];
                that.html += `<div data-key="${v[that.options.key]}" class="mt_item ${getClass(v)}">${v[that.options.name]}</div>`;
            }
            that.html += `</div>`;
            that.options.ele.innerHTML = that.html;

            function getClass(v) {
                if (that.options.multiple) {
                    if (that.options.value.includes(v[that.options.key])) {
                        return "active"
                    }
                }

                if (v[that.options.key] === that.options.value) {
                    return "active"
                }
                return "";
            }
        }

        return function (selecor, param) {
            return newObject(selecor, param, Fun);
        }

})