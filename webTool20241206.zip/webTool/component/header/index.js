﻿define([
    "css!./index.css",
    "util/event/on",
    "util/check/isFunction",
    "util/check/isArray",
    "util/check/isObject",
    "util/newFun/newObject",
    "util/copy/deepMerge"
], function (css, on, isFunction, isArray, isObject, newObject, deepMerge) {

    function Fun(param) {
        let that = this
        that.options = {
            ele: null,
            title: '标题',
            "position": "",
            "boxShadow": "",

            left: {
                callBack: function (v, i) {

                },
                template:`<div>返回</div>`
            },
            center: {
                callBack: function (v, i) {

                },
                template: `<div>标题</div>`
            },
            right: {
                callBack: function (v, i) {

                },
                template: `<div>设置</div>`
            }

        }

        deepMerge(that.options, param)
        that.getHtml();

        that.options.ele.on("click", ".left", function (ele) {
            if (!isFunction(that.options.left.callBack)) {
                return;
            }
            that.options.left.callBack(ele)
        })
        that.options.ele.on("click", ".center", function (ele) {
            if (!isFunction(that.options.center.callBack)) {
                return;
            }
            that.options.center.callBack(ele)
        })
        that.options.ele.on("click", ".right", function (ele) {
            if (!isFunction(that.options.right.callBack)) {
                return;
            }
            that.options.right.callBack(ele)
        })


    };

        Fun.prototype.getHtml = function () {
            let that = this;
            let html = `
                <div class="header ${that.options.position} ${that.options.boxShadow}">
                    <div class="left">${that.options.left.template}</div>
                    <div class="x-fill-auto center">${that.options.center.template}</div>
                    <div class="right">${that.options.right.template}</div>
                </div>
            `
            that.options.ele.innerHTML = html;

        }

        return function (selecor, param) {
            return newObject(selecor, param, Fun);
        }

})

