﻿define([
    "css!./navigation.css",
    "util/newFun/index",
    "util/copy/copyObject",
    "util/request/ajax",

],
    function (css, newFun, copyObject, ajax) {
        function Fun(param) {
            let that = this
            that.options = {
                ele: null,
                url: "",
                callBack: function (v, i) {

                }
            }
            copyObject(that.options, param);
            ajax({
                url: that.options.url,
                dataType:"json",
                success: function (res) {
                    that.getHtml(res)
                },
            })
        };

        Fun.prototype.getHtml = function (list) {
            let that = this;
           
            let html = "";
            for (var i = 0; i < list.length; i++) {
                let v = list[i];
                html += `
                    <div class="item-card">
                        <a  href="${v.url}"  target="${v.target}" class="navigation">
                          <div class="xe-user-img">
                            <img src="${v.icon}" >
                          </div>
                          <div class="xe-comment">
                            <div class="name">${v.name}</div>
                            <div class="desc">${v.desc}</div>
                          </div>
                        </a>
                    </div>
                `
            }
            that.options.ele.innerHTML = html;

        }


        return function (selecor, param) {
            newFun(selecor, param, Fun);
        }

    })