define([
    "vue",
    "text!@/bookCard/index.html",
    "css!@/bookCard/index.css"
], function (Vue,template) {
    Vue.component ("m-book-card", {

        template:template,
        props: {
            bookItem: {
                type: Object,
                default: function () {
                    return {

                    }
                }
            }
        },

        methods: {
            handleClick(evt) {

            }
        }
    });
});


