define([
    "vue",
    "text!@/header2/index.html",
    "css!@/header2/index.css",

],function (Vue,template){

  //  import()
   // debugger
    let app = Vue.createApp();


    let object= {
        "name":"m-header",
        template:template,
        props: {
            position: {
                type: String,
                default:function () {
                    return "fixed"
                }
            },
            boxShadow: {
                type: Boolean,
                default:function () {
                    return false
                }
            }
        },
        data:function (){
            return {}
        },
        created:function(){},
        methods: {
            normalFunction:function (item,type) {}
        },
    }
    return object
    app.component('m-header',{
        template:template,
        props: {
            position: {
                type: String,
                default:function () {
                    return "fixed"
                }
            },
            boxShadow: {
                type: Boolean,
                default:function () {
                    return false
                }
            }
        },
       data:function (){
           return {}
       },
        created:function(){},
        methods: {
            normalFunction:function (item,type) {}
        },
    })



})

