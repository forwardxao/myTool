define(["vue","text!@/answerMark/index.html","css!@/answerMark/index.css"],function (Vue,template) {
    Vue.component("answer-mark", {
        template:template,
        props: {
            model:{
                prop:"value",
                event:"input"
            },
            answerList: {
                type: Array,
                default:function () {
                    return []
                }
            },

            currentIndex: {
                type: Number,
                default:function () {
                    return 1
                }
            }

        },
        data:function(){
            return {}
        },
        created:function(){
            let me=this;
        },
        methods: {
            normalFunction:function (item,type) {
                let me=this;
                if(me[type+"Fun"] instanceof  Function){
                    me[type+"Fun"](item);
                }
            },

            selectItemFun:function (item) {
                this.$emit("select-item",item);
            },

            viewAnswerFun:function () {
                this.$emit("view-answer");
            },



            getItemClass:function (item,index) {
                let that=this;
                let _class=" ";
                if(that.currentIndex===index){
                    _class+=" currentItem ";
                }
                _class+=item.selectResult;
                return _class
            },

            isShowAnswer:function () {
                let that=this;
                let _flag=true
                if(that.answerList.length<1){
                    return
                }

                that.answerList.forEach(v=>{
                    if(!v["selectResult"]){_flag=false;}
                })
                return _flag
            }
        },
    });
})
