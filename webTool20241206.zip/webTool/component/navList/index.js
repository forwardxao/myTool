define(["vue","text!@/navList/index.html","css!@/navList/index.css"],function (Vue,template) {
    Vue.component('m-nav-list',{
        template:template,
        data:function(){
            return {
                show:true
            }
        },
        "model":{
            prop:"value",
            event:"input"
        },

        props:{
            "value":{
                type:Object,
                default:function () {
                    return {

                    }
                }
            },
            "list":{
                type:Array,
                default:function () {
                    return []
                }
            },

        },
        methods:{
            "switchTabFun":function (item) {
                let  that=this;
                if(item.fileName===that.value.fileName){
                    return
                }
                Object.assign(that.value,item)
                that.$emit("change",that.value)
            },
        },
    })
})

