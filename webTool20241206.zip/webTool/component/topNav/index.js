define([
    "css!@/sidebar/index.css",
    "other/forEach",
    "check/isArray",
    "check/isFunction"
],
    function (css, forEach, isArray, isFunction) {
	    return function(param) {
            const option = {
                list:[],
                isShowChild: true,
                childKey: "list",
                itemName:"name",
                itemUrl: "url",
                itemTarget: "_blank",
                itemTemplate: function (v, i) {
                    return `<div>${v[option.itemName]}</div>`;
                }
            }

            Object.assign(option,param)
            let html = ``;

            function getItem(v, i) {
                html += `<div class="mt_sideBar_item">` + option.itemTemplate(v,i);
                if (option.isShowChild) {
                    getList(v[option.childKey])
                }
                html += `</div>`;
            }

            function getList(list) {
                if (!isArray(list)) { return; }
                if (list.length<1) { return; }

                html += `<div class="mt_sideBar_list">`;
                forEach({list: list || [],callBack: getItem});
                html += `</div>`;
            }
            getList(option.list)
            console.log(html)
            return html;

	    }
})