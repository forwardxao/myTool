define([
        "vue",
        "text!@/singleSelectTree/index.html",
        "css!@/singleSelectTree/index.css",
        "component/singleSelectTree/tree",
    ],
    function (Vue,template) {
        Vue.component("single-select-tree",{
            template:template,
            props: {
                "treeList":{
                    type:Array,
                    default:function () {
                        return []
                    }
                },
                "optionValue":{
                    type:String,
                    default:function () {
                        return "value"
                    }
                },
                "optionLabel":{
                    type:String,
                    default:function () {
                        return "label"
                    }
                },
                "value":{
                    type:String,
                    default:function () {
                        return ""
                    }
                },
                "toggleChildren":{
                    type:Boolean,
                    default:function () {
                        return false
                    }
                },

            },
            model:{
                prop:"value",
                event:"input"
            },
            data:function () {
                return {
                    baseInfo: {
                        dataTips:'请选择',
                        selectShow:true
                    },
                    thisList:[]
                }
            },
            created:function(){
                let  that=this
                this.$nextTick(function () {})
            },
            methods:{
                toggleSelectShowFun:function () {
                    let  that=this
                    that.baseInfo.selectShow=!that.baseInfo.selectShow
                },
                getList:function () {

                },
                initData:function () {
                    console.log(this.treeList)
                }



            },

        })
});


