define([
        "vue",
        "text!@/singleSelectTree/tree.html"
    ],
    function (Vue,template) {
        Vue.component("m-tree",{
            template:template,
            props:{
                "treeList":{
                    type:Array,
                    default:function () {
                        return []
                    }
                },
                "optionValue":{
                    type:String,
                    default:function () {
                        return "value"
                    }
                },
                "optionLabel":{
                    type:String,
                    default:function () {
                        return "label"
                    }
                },

                "toggleChildren":{
                    type:Boolean,
                    default:function () {
                        return false
                    }
                },

                "value":{
                    type:String,
                    default:function () {
                        return ""
                    }
                },


            },
            model:{
                prop:"value",
                event:"input"
            },


            data:function () {
                return {
                    thisList:[]
                }
            },
            created:function(){
                let  that=this
                that.$nextTick(function () {
                    let _array= that.treeList.map(function (v,i) {
                        return Object.assign(v, {
                            "label":v[that.optionLabel],
                            "value":v[that.optionValue],
                            "children":v["children"]||[],
                            "toggleChildren":that.toggleChildren
                        })
                    })
                    that.thisList=_array
                })
            },
            methods:{
                toggleChildrenFun:function (item){
                    item["toggleChildren"]=!item["toggleChildren"]
                },

                selectItemFun:function (item){
                    let that=this
                    that.$emit("input",item.value)
                    that.$emit("change",Object.assign({},item))
                },

                getClass:function (item){
                    let that=this
                    //debugger
                    if(item.value===that.value){
                        return "selected"
                    }

                }












            },
        })
});


