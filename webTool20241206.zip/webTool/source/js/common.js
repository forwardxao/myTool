define(["vue","axios"],function(Vue,axios){
    Vue.prototype.$eventBus = new Vue()
    let baseUrl="";
    window.$vAxios=function (param) {
        let data={
            method:param.method
        };

        if(param["originalUrl"]){
            data["url"]=param.url
        }else{
            data["url"]=baseUrl+param.url
        }
        if(param.method==="get"){
            param.data["refreshCache"]=localStorage.getItem("refreshCache")||(Date.now()+"")
            data["params"]=param.data
        }
        if(param.method==="post"){
            data["data"]=param.data
        }
        if(!param.hasOwnProperty("convertToHumpNaming")){
            param["convertToHumpNaming"]=true;
        }
        axios(data).then(function (result) {
            let data=result.data||{};
            if(param.originalData){
                param.success&&param.success(data)
                return;
            }

            if(data.code!==200){
                param.error&&param.error(data.msg);
                return;
            }
            param.success&&param.success(data.data)
        })
        .catch(function (error) {
            param.error&&param.error(error)
        })
        .finally(()=>{
            param.finally && param.finally()
        });
    }
    Vue.prototype.$goBackFun = function () {
        location.href = "http://qn.jazx.com/webStack/index/index.html"
    }

    Vue.prototype.$MTTitle = function (text) {
        new Vue({
            el: "#MTTitle",
            data: function () {
                return {}
            },
            methods: {
                getText: function () {
                    return text + "_更加高效的学习_君安智学_jazx.com";
                }
            }
        });

    }

    window.$audioMp3 = {
        "audioMp3": new Audio(),
        "play": function (mp3,callBack) {
            let that = this
           // debugger
            if(mp3){
                that.audioMp3.src = mp3;
            }

            if (that.audioMp3.src !== mp3) {
                that.audioMp3.load();
            }
            let playPromise = that.audioMp3.play()
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    that.audioMp3.play().then(r => {
                        console.log(r)
                    })
                }).catch(() => {
                })
            }
            callBack&&callBack()
        },
        "pause": function () {
            let that = this
            that.audioMp3.pause()
        }
    }
    window.$randomArray = function (arr) {
        let iRand, temp, len
        let newArr = [].concat(arr)
        len = newArr.length
        for (let i = 0; i < len; i++) {
            iRand = parseInt(len * Math.random())
            temp = newArr[i]
            newArr[i] = newArr[iRand]
            newArr[iRand] = temp
        }
        return newArr;
    }
    window.$randomItem = function (arr, key) {
        let item = arr[Math.floor(Math.random() * arr.length)]
        if (!key) {
            return item
        }
        return item[key]
    }
    window.$randomNumber = function (n, m) {
        return Math.floor(Math.random() * (m - n + 1)) + n;
    }
    window.$genId = function (length) {
        return Number(Math.random().toString().substr(3, length) + Date.now()).toString(36)
    }
    window.$getUrlKey=function (name) {
        return decodeURIComponent((new RegExp("[?|&]" + name + "=" + "([^&;]+?)(&|#|;|$)").exec(location.href) || [, ""])[1].replace(/\+/g, "%20")) || null
    };



    window.$renderObject = {}
    window.$getHtmlContent = function (callBack) {
        let getHtmlContent = {
            data() {
                return {
                    html: null,
                };
            },
            mounted() {
              let that=this;
              that.getHtml()
            },
            created() {
                let that=this;
                that.$eventBus.$on("dataUrlChange", (dataUrl) => {
                    callBack=dataUrl
                    that.getHtml()
                });
            },

            methods: {
                getHtml:function (){
                    let that=this;
                    let dataUrl=""

                    if(!callBack){return;}

                    if(callBack instanceof Function){
                        dataUrl=callBack()
                    }else{
                        dataUrl=callBack
                    }
                    window.$vAxios({
                        url:dataUrl,
                        method:"get",
                        data:{},
                        "originalData":true,
                        "originalUrl":true,
                        success:function (result) {
                            that.html=result
                        },
                        error:function (error) {
                        }
                    })
                }
            },
            render(h) {
                let that=this
                if(!that.html){
                    return
                }
                let script = window.$getStr(that.html, "<script>", "</script>")
                    .replace("<script>", "").replace("</script>", "")
                let style = window.$getStr(that.html, "<style>", "</style>")
                    .replace("<style>", "").replace("</style>", "")
                let template = window.$getStr(that.html, "<template>", "</template>")
                if (style) {
                    var styleNode = document.createElement('style');
                    styleNode.type = 'text/css';
                    styleNode.innerHTML = style;
                    document.getElementsByTagName('body')[0].append(styleNode);
                }
                let renderFun = new Function("return renderFun= " + script);
                if (!renderFun) {
                    console.log("js格式错误")
                }
                let renderObject = renderFun()();
                renderObject["template"] = `${template}`
                const com = Vue.extend(renderObject)
                return h(com, {});
            }
        }

       // debugger
        return getHtmlContent;
    }
    window.$getStr =function (str,start,end) {
        let _str="";
        if(!str||!start||!end){
            return _str
        }
         let startIndex=str.indexOf(start)
         let endIndex=str.indexOf(end)
        return  str.slice(startIndex,endIndex+end.length)
    }
})





