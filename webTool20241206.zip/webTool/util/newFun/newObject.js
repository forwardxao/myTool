define(function () {
	function Fun(selecor="", param = {}, newFun) {
		var isDom = function (obj) {
			try {
				return obj instanceof HTMLElement;
			}
			catch (e) {
				return (typeof obj === "object") &&
					(obj.nodeType === 1) && (typeof obj.style === "object") &&
					(typeof obj.ownerDocument === "object");
			}
		}

		let ele = null;
		if (isDom(param.parent)) {
			ele = param.parent.querySelector(selecor);
		} else {
			ele = document.querySelector(selecor);
        }
		if (!isDom(ele)) {
			return;
        }
		param["ele"] = ele;
		return new newFun(param);
	};
	return Fun;
})