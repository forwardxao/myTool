define(function () {
		function Fun(selector="", param = {}, newFun) {

			var $ = function (selector) {
				var type = selector.substring(0, 1);
				if (type === '#') {
					this.eleList = document.querySelector(selector);
				} else {
					this.eleList = document.querySelectorAll(selector);
				}
				return this.eleList;
			}
			var isDom = function (obj) {
				try {
					return obj instanceof HTMLElement;
				}
				catch (e) {
					return (typeof obj === "object") &&
						(obj.nodeType === 1) && (typeof obj.style === "object") &&
						(typeof obj.ownerDocument === "object");
				}
			}
			let ele = $(selector);
			if (!ele instanceof NodeList) {
				if (!isDom(ele)) {
					return;
				}
				ele = [ele];
			}
			for (let i = 0, len = ele.length; i < len; i++) {
				param.ele = ele[i]
				new newFun(param)
			}
		};
		return Fun;
})