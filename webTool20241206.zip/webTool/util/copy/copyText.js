﻿define(function () {
    return function (text) {
            // 复制到剪切板
        var textArea = document.createElement("textarea");
        debugger
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        try {
            document.execCommand('copy');
            console.log("Text copied to clipboard!");
        } catch (err) {
            console.log("Failed to copy text", err);
        }
        document.body.removeChild(textArea);
    }
})