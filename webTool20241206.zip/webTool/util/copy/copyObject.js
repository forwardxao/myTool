define(function () {
	return function (options,param) {
		for (let key in options) {
			if (param.hasOwnProperty(key) && param[key]) {
				options[key] = param[key]
			}
		}

    }
})