define(function () {
    return function (param) {
        if (!Object.prototype.toString.call(param.list) === '[object Array]') {
            return false;
        }
        for (let i = 0, len = param.list.length; i < len; i++) {
            param.callBack && param.callBack(param.list[i],i)
        }
	};
})