define(function () {
	return class {

		constructor() {
			this.isFirst = true;
			this.isFirst2 = true;
		}

    }






	function(ele) {
		return document.querySelector(ele);
	}
})