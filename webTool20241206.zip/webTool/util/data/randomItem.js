define(function () {
    return function(arr, key) {
        let item = arr[Math.floor(Math.random() * arr.length)]
        if (!key) {
            return item
        }
        return item[key]
    }
})