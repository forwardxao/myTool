define(function () {
    return function (list,index) {
        let nextIndex = index + 1
        if ((nextIndex + 1) > list.length) {
            return 0;
        }
        return nextIndex;
    }
})