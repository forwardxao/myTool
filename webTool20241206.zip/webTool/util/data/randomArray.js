define(function () {
    return function (arr) {
        let iRand, temp, len
        let newArr = [].concat(arr)
        len = newArr.length
        for (let i = 0; i < len; i++) {
            iRand = parseInt(len * Math.random())
            temp = newArr[i]
            newArr[i] = newArr[iRand]
            newArr[iRand] = temp
        }
        return newArr;
    }
})