define(function () {

    function fun(list, key, val) {
        if (!Array.isArray(list) || list.length === 0) {
            return {}
        }
        for (let i = 0, len = list.length; i < len; i++) {
            let v = list[i];
            if (v[key] === val) {
                return v;
            }
        }
        return {}
    }

    return function (list = [], key = "mtKey", val = "1") {
        return fun(list, key, val);
    }

})