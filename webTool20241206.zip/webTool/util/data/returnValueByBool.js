define(function () {
    return function (val,b) {
        if (b) {
            return val;
        }
        return "";
    }

})