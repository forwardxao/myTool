define(function () {
    return function(arr, index) {
        let firstPart = arr.slice(index);
        let secondPart = arr.slice(0, index);
        return firstPart.concat(secondPart)
    }
})