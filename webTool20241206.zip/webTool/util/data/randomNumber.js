define(function () {
    return function (n, m) {
        return Math.floor(Math.random() * (m - n + 1)) + n;
    }
})