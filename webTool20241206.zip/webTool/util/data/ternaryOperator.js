define(function () {
    return function (one, two,val) {
        if (one === two) {
            return val;
        }
        return "";
    }
})