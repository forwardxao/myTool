define(function () {

    function fun(tree, key, val, children) {
        if (!Array.isArray(tree) || tree.length === 0) {
            return false
        }
        for (let i = 0, len = tree.length; i < len; i++) {
            let v = tree[i];
            if (v[key] === val) {
                return v;
            }

            let item = fun(v[children], key, val, children);
            if (item) {
                return item
            }
            //return 
        }
    }

    return function (tree = [], key = "mtKey", val = "1", children = "list") {

        return fun(tree, key, val, children);
    }

})