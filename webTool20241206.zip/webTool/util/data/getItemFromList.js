(function () {
    return function(list,param={
        "key":"key",
        "val":""
    }){
        let item = {};
        let options = {
            list: list||[],
            "key": param["key"]||"key",
            "val": param["val"] ||""
        }

        for(let i=0,len=options.list.length;i<len;i++) {
            let v = options.list[i];
            if (v[options.key] === options.val){
                item=v
                break;
            }
        }
        return item
    }
})()