define(function () {
    return function (str, start, end) {
        let _str = "";
        if (!str || !start || !end) {
            return _str
        }
        let startIndex = str.indexOf(start)
        let endIndex = str.indexOf(end)
        return str.slice(startIndex, endIndex + end.length)
    }
})