define(function () {
    return function (str, key) {
        var index = str.lastIndexOf(key);
        return str.substring(index + 1, str.length);
    }
})