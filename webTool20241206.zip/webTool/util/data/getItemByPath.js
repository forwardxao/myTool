define(function () {

    function fun(list, pathList, children) {
        if (!Array.isArray(list) || list.length === 0) {
            return false
        }
        let path = getPath(pathList);

        let item = list[path];

        if (pathList.length>0) {
            return fun(item[children], pathList, children);
        }
        return item || false;
    }
    function getPath(pathList) {

        if (pathList.length < 1) { return 0;}
        let path = pathList.splice(0, 1);
        path = path[0];
        if (!path) {
           return getPath(pathList)
        }
        return parseInt(path);
    }

    return function (param = {list :[],children:"list", path : "/0", split : "/"}) {
        let options = {
            list: [],
            children: "list",
            path: "/0",
            split: "/"
        }
        Object.assign(options,param)
        let pathList = (options.path || "").split(options.split);
        return fun(options.list, pathList, options.children);
    }

})