define(function () {
    return function (val = "") {
        try {
            return JSON.parse(val);
        } catch (error) {
            return "";
        }
    }
})