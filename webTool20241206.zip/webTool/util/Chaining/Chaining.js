var test = {
    a: function () {
        console.log('a');
        return this;
    },
    b: function () {
        console.log('b');
        return this;
    },
    c: function () {
        console.log('c');
    }
}
test.a().b().c();