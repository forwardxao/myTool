define(function () {

    function Fun() {
        this.audioMp3 = new Audio();
    };

    Fun.prototype.play = function (mp3, callBack) {
        let that = this
        if (mp3) {
            that.audioMp3.src = mp3;
        }

        if (that.audioMp3.src !== mp3) {
            that.audioMp3.load();
        }
        let playPromise = that.audioMp3.play()
        if (playPromise !== undefined) {
            playPromise.then(() => {
                that.audioMp3.play().then(r => {
                    console.log(r)
                })
            }).catch(() => {
            })
        }
        callBack && callBack()
    }

    Fun.prototype.pause = function () {
        let that = this
        that.audioMp3.pause()
    }

    return new Fun();

})




