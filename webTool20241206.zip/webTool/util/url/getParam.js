define(function () {
    return function () {
        const searchParams = window.location.search.substring(1).split('&');
        const params = {};
        for (const param of searchParams) {
            const [key, value] = param.split('=');
            try {
                params[decodeURIComponent(key)] = decodeURIComponent(value);
            } catch{
                break;
            }
        }
        return params;
    };
})

