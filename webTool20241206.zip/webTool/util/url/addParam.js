define(function () {
    return function (key,val) {
        let url = new URL(window.location.href);
        url.searchParams.set(key, val);
        window.history.pushState({}, '', url);
	};
})



