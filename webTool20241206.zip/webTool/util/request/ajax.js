define(function () {
    function Ajax(options) {
        this.options = {
            url: options.url||"",
            type: (options.type || 'get').toLowerCase(),
            async: options.async || true,
            data: options.data || {},
            dataType: options.dataType || '',
            success: options.success || function () { },
            error: options.error || function () { },
            finally: options.finally || function () { },

            
        };

        this.xhr = new XMLHttpRequest();
        this.init();
    }
    Ajax.prototype = {
        init: function () {
            this.param();
            this.get();
            this.post();
            this.ready();
        },

        param: function () {
          //  this.options.data["refreshCache"] = localStorage.getItem("refreshCache") || (new Date().getDate() + "" + new Date().getHours() + "")


            this.options.data["refreshCache"] = new Date().getTime()

          //  urlArgs: "refreshCache=" + new Date().getTime(),

            if (this.options.data !== null) {
                var str = '';
                for (var x in this.options.data) {
                    str += x + '=' + this.options.data[x] + '&';
                }
                this.options.data = str.replace(/&$/, '');
            }

        },

        get: function () {
            if (this.options.type === 'get') {

                if (this.options.data !== null) {
                    this.xhr.open(this.options.type, this.options.url + '?' + this.options.data, this.options.async);
                } else {
                    this.xhr.open(this.options.type, this.options.url, this.options.async);
                }
                this.xhr.send();
            }
        },

        post: function () {
            if (this.options.type === 'post') {
                // 2.���ӷ������������������ַ��true:�첽���䣩
                this.xhr.open(this.options.type, this.options.url, this.options.async);
                // 3.post��ʽ��Ҫ�Լ�����http������ͷ����ģ�±����ύ��
                this.xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
                this.xhr.send(this.options.data);
            }
        },

        ready: function () {
            this.xhr.onreadystatechange = (function () {
                if (this.xhr.readyState === 4) {
                    if (this.xhr.status === 200 || this.xhr.status === 304) {
                        let res = "";
                        switch (this.options.dataType) {
                            case "json":
                                res = JSON.parse(this.xhr.responseText);
                                break;
                            case "xml":
                                res = this.xhr.responseXML;
                                break;
                            default:
                                res = this.xhr.responseText;
                                break;
                        }
                        this.options.success(res);
                    } else {
                        if (this.options.error) {
                            this.options.error(this.xhr.responseText);
                        }
                    }
                        this.options.finally(this.xhr.responseText);
                }
            }).bind(this);

            /*
            this.xhr.onerror = function (err) {
                this.options.error(err);
            }.bind(this);
*/
        }
    };
    return function (options) {
        new Ajax(options);
    }
})





