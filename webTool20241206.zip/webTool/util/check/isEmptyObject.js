define(function () {
	return function(o) {
			for (var a in o) {
				return false;
			}
			return true;
	};
})