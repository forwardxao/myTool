define(function () {
    return function () {

        let options = {
            "PC": 800,
            "mobile":799
        }

        let windowWidth = document.documentElement.clientWidth
        that.isMobile = windowWidth < 800
        that.showMenu = !(windowWidth < 800)

        return windowWidth < 800;
	};
})