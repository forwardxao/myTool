define(function () {
	return function(a) {
			return typeof a === 'number';
		};
})