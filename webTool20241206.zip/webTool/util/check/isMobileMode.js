define(function () {
    return function () {
      return document.documentElement.clientWidth < 800
	};
})