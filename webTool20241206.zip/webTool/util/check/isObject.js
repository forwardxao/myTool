define(function () {
	return function(a) {
			return Object.prototype.toString.call(a) === '[object Object]';
	};
})