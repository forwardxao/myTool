define(function () {
    return function (param) {
        var { name } = param;
        var value = getCookie(name);
        var array = document.cookie.split(';');
        var value = null;
        for (var i = 0, len = array.length; i < len; i++) {
            var item = array[i].split("=");
            if (item[0].trim() == name) {
                value = item[1];
                break;
            }
        }

        if (value != null) {
            document.cookie = name + "=" + value + ";expires=" + new Date(0).toUTCString();
        }
	};
})