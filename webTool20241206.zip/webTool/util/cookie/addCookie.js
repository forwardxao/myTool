define(function () {
    return function (param) {
        var { name, value, time}=param
        var exp = new Date();
        exp.setTime(exp.getTime() + time * 1000);
        //����cookie�����ơ�ֵ��ʧЧʱ��
        document.cookie = name + "=" + value + ";expires=" + exp.toGMTString();  
	};
})