define(function () {
	function Fun(events = {}) {
		this.events = events || {};
	};
	Fun.prototype.on = function (name,cb) {
		(this.events[name] || (this.events[name] = [])).push(cb);
		return {
			unBind: () =>
				this.events[name] && this.events[name].splice(this.events[name].indexOf(cb) >>> 0, 1)
		};
    }
	Fun.prototype.emit = function (name, ...args) {
		(this.events[name] || []).forEach(fn => fn(...args));
	}
	return new Fun();

})