define(function () {
	return function (param) {
        document.oncontextmenu = function (e) {
            var tagName = e.target.tagName?.toUpperCase();
            var id = e.target.id;
            if (tagName == "INPUT") {
                if (id == "UserCode" || id == "PassWord") {
                    return false;
                }
                return true;
            }
            return false;
        };
	};
})