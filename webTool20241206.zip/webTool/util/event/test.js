define(function () {
	return function (param) {
		
	};
})