﻿define(function () {

    Element.prototype.on = function ( type="click", selector= ".class", callBack=function (ele) { }) {
        let that = this
        if (Object.prototype.toString.call(callBack) !== '[object Function]'){
            return
        }

        function includes(eleList, ele) {
            for (let i = 0, len = eleList.length; i < len; i++) {
                if (eleList[i].isSameNode(ele)) {
                    return true;
                }
            }
            return false
        }


        function getOnEle(tar, item) {
            var eleList = that.querySelectorAll(item.selector)
            while (!includes(eleList, tar)) {
                if (tar === that) {
                    tar = null
                    break;
                }
                tar = tar.parentNode
                if (tar == null) {
                    // 重新渲染导致元素与当前元素不相等
                    break;
                }
            }
            if (tar) {
                item.callBack(tar)
            }
        }

        if (that.eventObject === undefined) {
            that.eventObject = {};
        }

        if (!that.eventObject[type]) {
            that.eventObject[type] = [];
            that.addEventListener(type, function (e) {
                let tar = e.target
                let list = that.eventObject[type] || [];
                for (let i = 0, len = list.length; i < len; i++) {
                    getOnEle(tar,list[i])
                }
            });
        }

        that.eventObject[type].push({
            selector: selector,
            callBack: callBack
        })

        return this;

	};
})