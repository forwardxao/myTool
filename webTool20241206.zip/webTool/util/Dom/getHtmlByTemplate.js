define(function () {
    return function (data,template) {
        let _data = {
            name: '_BuzzLy',
            age: 25
        };

        let data = new Proxy(_data, {
            set(obj, name, value) {
                obj[name] = value;
                render();
            }
        });

        render();
        let innerHTML = "";

        function render() {
            innerHTML = template.replace(/\{\{\w+\}\}/g, str => {
                str = str.substring(2, str.length - 2);
                return _data[str];
            });
        }
        data.name="hello world"

    }

})