define(function () {
	return function () {
		return document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen || document.msFullscreenElement;
	};

})