define(function () {
    function observe(data) {
        if (!data || typeof data !== 'object') return
        for (let key in data) {
            let val = data[key]
            let subject = new Subject()
            if (typeof val === 'object') {
                observe(val)
            }
            Object.defineProperty(data, key, {
                configurable: true,
                enumerable: true,
                get() {
                    if (currentObserver) {
                        currentObserver.subscribeTo(subject)
                    }
                    return val
                },
                set(newVal) {
                    val = newVal
                    subject.notify()
                }
            })
        }
    }
    let id = 0
    class Subject {
        constructor() {
            this.id = id++
            this.observers = []
        }
        addObserver(observer) {
            this.observers.push(observer)
        }
        notify() {
            this.observers.forEach(observer => {
                observer.update()
            })
        }
    }
    let currentObserver = null
    class Observer {
        constructor(vm, key, cb) {
            this.subjects = {}
            this.vm = vm
            this.key = key
            this.cb = cb
            this.value = this.getValue()
        }
        update() {
            let oldVal = this.value
            let value = this.getValue()
            if (value !== oldVal) {
                this.value = value
                this.cb.call(this.vm, value, oldVal)
            }
        }
        subscribeTo(subject) {
            if (!this.subjects[subject.id]) {
                subject.addObserver(this)
                this.subjects[subject.id] = subject
            }
        }
        getValue() {
            currentObserver = this
            let value = this.vm.data[this.key]
            currentObserver = null
            return value
        }
    }
    class mvvm {
        constructor(options) {
            this.init(options)
            observe(this.data)
            this.compile()
        }
        init(options) {
            this.el = document.querySelector(options.el)
            this.data = options.data
        }
        compile() {
            this.traverse(this.el)
        }
        traverse(node) {
            node.childNodes.forEach(childNode => {
                if (childNode.nodeType === 1) {
                    this.traverse(childNode)
                } else if (childNode.nodeType === 3) {
                    this.renderText(childNode)
                }
            })
        }
        renderText(textNode) {
            let reg = /{{([^}]*)}}/g
            let match
            while (match = reg.exec(textNode.textContent)) {
                let raw = match[0]
                let key = match[1].trim()
                textNode.textContent = textNode.textContent.replace(raw, this.data[key])
                new Observer(this, key, function (val, oldVal) {
                    textNode.textContent = textNode.textContent.replace(oldVal, val)
                })
            }
        }
    }
    let vm = new mvvm({
        el: '#app',
        data: {
            name: 'uccs',
            age: 20
        }
    })
    setInterval(function () {
        vm.data.age++
    }, 2000)

})