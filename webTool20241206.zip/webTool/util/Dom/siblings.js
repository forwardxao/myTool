define(function () {

    Element.prototype.siblings = function (selector= "") {
        let that = this
        var nodes = []; 
        var previ = this.previousSibling;
        while (previ) { 
            if (previ.nodeType === 1) {
                if (selector && previ.matches(selector) || !selector) {
                        nodes.push(previ);
                } 
            }
            previ = previ.previousSibling; 
        }
        nodes.reverse(); 
        var nexts = this.nextSibling; 
        while (nexts) { 
            if (nexts.nodeType === 1) {
                if (selector && nexts.matches(selector) || !selector) {
                    nodes.push(nexts);
                }
            }
            nexts = nexts.nextSibling;
        }
        return nodes; 
	};

})