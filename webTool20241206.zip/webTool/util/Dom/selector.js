define(function () {
		function Fun(selector) {
			var type = selector.substring(0, 1);
			if (type === '#') {
				this.eleList = document.querySelector(selector);
			} else {
				this.eleList = document.querySelectorAll(selector);
			}
		};
		Fun.prototype.html = function (htmlString) {
			if (this.eleList==null) {
				return;
			}
			if (htmlString) {
				for (let i = 0, len = this.eleList.length; i < len; i++) {
					this.eleList[i].innerHTML = htmlString;
				}
			} else {

				return this.eleList[0].innerHTML
            }
		}
		return function (selector) {
			return new Fun(selector)
		};
})