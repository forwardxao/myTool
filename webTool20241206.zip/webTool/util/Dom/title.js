define(function () {
	function Fun() {
		this.options = {
			prefix: "",
			title: "",
			suffix: "",
		}
	};
	Fun.prototype.prefix = function (str) {
		this.options.prefix = str;
	}
	Fun.prototype.suffix = function (str) {
		this.options.suffix = str;
	}
	Fun.prototype.set = function (str) {
		let separate = "";
		let separate2 = "";
		if (this.options.prefix && str) {
			separate = "_";
		} 
		if (this.options.suffix && str) {
			separate2 = "_";
		} 

		if (this.options.suffix && this.options.prefix) {
			separate = "_";
		} 
		document.title = this.options.prefix + separate + str + separate2+this.options.suffix;
	}

	return function () {
		return new Fun();
	}

})