define(function () {
    return function (element) {
        if (document.mozFullScreenEnabled) {
            return Promise.reject(new Error("ȫ��ģʽ������"));
        }
        let result = null;
        if (element.requestFullscreen) {
            result = element.requestFullscreen();
        } else if (element.mozRequestFullScreen) {
            result = element.mozRequestFullScreen();
        } else if (element.msRequestFullscreen) {
            result = element.msRequestFullscreen();
        } else if (element.webkitRequestFullscreen) {
            result = element.webkitRequestFullScreen();
        }
        return result || Promise.reject(new Error("��֧��ȫ��"));
	};

})