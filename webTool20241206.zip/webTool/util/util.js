/**
 * 判断一个元素是否在数组中
 * @param arr 数组
 * @param val 判断的值
 */
function contains(arr, val) {
    return arr.indexOf(val) != -1 ? true : false;
}

/**
 * 数组进行去重
 * @param arr 数组
 * @return {any[]|Array} 去重后的数组
 */
function unique(arr) {
    if (Array.hasOwnProperty('from')) {
        return Array.from(new Set(arr));
    } else {
        var n = {}, r = [];
        for (var i = 0; i < arr.length; i++) {
            if (!n[arr[i]]) {
                n[arr[i]] = true;
                r.push(arr[i]);
            }
        }
        return r;
    }
}

/**
 * 数组合并
 * @param a
 * @param b
 * @return {any[]|Array}
 */
function union(a, b) {
    var newArr = a.concat(b);
    return unique(newArr);
}

/**
 * 将类数组转换为数组的方法
 * 
 */
function formArray(ary) {
    var arr = [];
    if (Array.isArray(ary)) {
        arr = ary;
    } else {
        arr = Array.prototype.slice.call(ary);
    };
    return arr;
}

/**
 * 获取数组中最大值
 * @param arr
 * @return {number}
 */
function arrayMax(arr) {
    return Math.max(...arr)
}

/**
* 获取数组中最小值
* @param arr
* @return {number}
*/
function arrayMin(arr) {
    return Math.min(...arr)
}

/**
* 计算某值在数组中出现的次数
* @param arr
* @param value
* @return {*}
*/
function countOccurrences(arr, value) {
    return arr.reduce((a, v) => v === value ? a + 1 : a + 0, 0)
}

/**
 * 去除数组中假值元素，比如undefined,null,0,"",NaN都是假值
 * @param   {Array}    arr
 * @return  {Array}
 */
function compact(arr) {
    let index = -1,
        resIndex = -1,
        result = [],
        len = arr ? arr.length : 0
    while (++index < len) {
        let value = arr[index]
        if (value) {
            result[++resIndex] = value
        }
    }
    return result;
}

/**
 * 获取数组的最后一项
 * @since 1.2.1
 * @param array
 * @returns {boolean}
 * @example
 * last(['1,2,3']);
 * // => '3';
 */
function last(array) {
    return Array.isArray(array) && array.slice(-1)[0];
}

/**
 * 匹配rgba的正则
 * @returns {RegExp}
 */
function regexRgba() {
    return /^[rR][gG][Bb][Aa]?[\(]([\s]*(2[0-4][0-9]|25[0-5]|[01]?[0-9][0-9]?),){2}[\s]*(2[0-4][0-9]|25[0-5]|[01]?[0-9][0-9]?),?[\s]*(0\.\d{1,2}|1|0)?[\)]{1}$/g
}

/**
 * 匹配透明度为0的rgba正则
 * @returns {RegExp}
 */
function regexRgbaByZeroOpacity() {
    return /^[rR][gG][Bb][Aa]?[\(]([\s]*(2[0-4][0-9]|25[0-5]|[01]?[0-9][0-9]?),){2}[\s]*(2[0-4][0-9]|25[0-5]|[01]?[0-9][0-9]?),?[\s]*0[\)]{1}$/
}

/**
* hex转换为RGBA
* @param hex 格式颜色
* @param opacity 透明度
* @return {string}
*/
function hexToRgbA(hex, opacity = 1) {
    let c;
    if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
        c = hex.substring(1).split('');
        if (c.length === 3) {
            c = [c[0], c[0], c[1], c[1], c[2], c[2]];
        }
        c = '0x' + c.join('');
        return 'rgba(' + [(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',') + `,${opacity})`;
    }
    throw new Error('Bad Hex');
}

/**
* rgb转Hex
* @constructor
*/
function RGBToHex(r, g, b) {
    return ((r << 16) + (g << 8) + b).toString(16).padStart(6, "0")
}

/**
 * 获得随机的颜色值
 * @return {String} 返回随机的颜色字符串
 */
function getRandomColor() {
    return (
        '#' +
        Math.random()
            .toString(16)
            .substring(2)
            .substr(0, 6)
    );
}

/**
 * 是否为有效的16进制颜色
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidHexadecimalColor('#f00');
 * // => true
 * isValidHexadecimalColor('#fe9de8');
 * // => true
 */
function isValidHexadecimalColor(val) {
    const reg = /^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/;
    return reg.test(val);
}

/**
 * 获取cookie 里的值
 * @param {String} key
 */
export const getCookie = (key) => {
    const arr = document.cookie.match(new RegExp(`(^| )${key}=([^;]*)(;|$)`));
    if (arr != null) return unescape(arr[2]);
    return null;
}

/**
 * 设置cookie
 * @param name
 * @param value
 * @param day expires的时间
 */
function setCookie(name, value, day) {
    let setting = arguments[0];
    if (Object.prototype.toString.call(setting).slice(8, -1) === 'Object') {
        for (let i in setting) {
            let oDate = new Date();
            oDate.setDate(oDate.getDate() + day);
            document.cookie = i + '=' + setting[i] + ';expires=' + oDate;
        }
    } else {
        let oDate = new Date();
        oDate.setDate(oDate.getDate() + day);
        document.cookie = name + '=' + value + ';expires=' + oDate;
    }

}

/** 
 * 删除cookie
 */
function removeCookie(name) {
    setCookie(name, 1, -1);
}

/**
 * 获取一级子节点
 * @param obj 父节点
 * @return {Array}
 */
getChildren(obj) {
    let objChild = [];
    let objs = obj.getElementsByTagName('*');
    for (let i = 0, j = objs.length; i < j; ++i) {
        if (objs[i].nodeType !== 1) {
            alert(objs[i].nodeType)
            continue
        }
        let temp = objs[i].parentNode;
        if (temp.nodeType == 1) {
            if (temp == obj) {
                objChild[objChild.length] = objs[i]
            }
        } else if (temp.parentNode == obj) {
            objChild[objChild.length] = objs[i]
        }
    }
    return objChild
}

/**
 * 获取兄弟节点
 */
function siblings(element) {
    let chid = element.parentNode.children, eleMatch = [];
    for (let i = 0, len = chid.length; i < len; i++) {
        if (chid[i] != element) {
            eleMatch.push(chid[i]);
        }
    }
    return eleMatch;
}

/**
 * 获取元素相对于视口的位置信息
 *
 * @param {Element} ele
 */
const getOffsetRect = (ele) => {
    const box = ele.getBoundingClientRect();
    const body = document.body;
    const docElem = document.documentElement;
    // 获取页面的scrollTop,scrollLeft(兼容性写法)
    const scrollTop = window.pageYOffset || docElem.scrollTop || body.scrollTop;
    const scrollLeft = window.pageXOffset || docElem.scrollLeft || body.scrollLeft;
    const clientTop = docElem.clientTop || body.clientTop;
    const clientLeft = docElem.clientLeft || body.clientLeft;
    const top = box.top + scrollTop - clientTop;
    const left = box.left + scrollLeft - clientLeft;
    return {
        // Math.round 兼容火狐浏览器bug
        top: Math.round(top),
        left: Math.round(left)
    };
};

/**
* 判定节点里是否有class
* @param elements dom节点
* @param cName class名
* @return {boolean}
*/
function hasClass(element, cName) {
    return !!element.className.match(new RegExp('(\\s|^)' + cName + '(\\s|$)'))
}

/**
* 添加class
* @param elements
* @param cName
*/
function addClass(element, cName) {
    if (!hasClass(element, cName)) {
        element.className += ' ' + cName
    }
}

/**
* 删除class
* @param elements
* @param cName
*/
function removeClass(element, cName) {
    if (hasClass(element, cName)) {
        element.className = element.className.replace(new RegExp('(\\s|^)' + cName + '(\\s|$)'), ' ')
    }
}

/**
 * 替换class
 * */
function replaceClass(element, newName, oldName) {
    removeClass(element, oldName);
    addClass(element, newName);
}

/**
 * 将dom对象转换成字符串
 * @param node
 * @returns {string}
 */
function nodeToString(node) {
    let tmpNode = document.createElement('div');
    //appendChild()  参数Node对象   返回Node对象  Element方法
    //cloneNode()  参数布尔类型  返回Node对象   Element方法
    tmpNode.appendChild(node.cloneNode(true));
    let str = tmpNode.innerHTML;
    tmpNode = node = null; // prevent memory leaks in IE
    return str;
}

/**
 * 给页面添加js和css
 * @type {Array}
 */
let loadedPaths = [];

function delayLoadJSAndCSS(path, type, title, preFn) {

    if (loadedPaths.includes(path)) {
        return Promise.resolve();
    } else {
        return new Promise(function (resolve) {
            let s = null;
            let js = null;
            let less = null;
            let i = 0;
            if (!type) {
                type = path.substr(path.lastIndexOf('.') + 1);
            }
            if (type === 'js') {
                let ss = document.getElementsByTagName('script');
                for (i = 0; i < ss.length; i++) {
                    if (ss[i].src && ss[i].src.indexOf(path) != -1 || ss[i].title == title) {
                        js = ss[i];
                        resolve(ss[i]);
                    }
                }
                if (!js) {
                    s = document.createElement('script');
                    s.type = 'text/javascript';
                    s.src = path;

                    if (preFn) {
                        preFn(s);
                    }

                    if (title) {
                        s.title = title;
                    }
                    loadedPaths.push(path);
                }
            } else if (type === 'css') {
                let ls = document.getElementsByTagName('link');
                for (i = 0; i < ls.length; i++) {
                    if (ls[i].href && ls[i].href.indexOf(path) != -1 || ls[i].title == title) {
                        less = ls[i];
                        resolve(ls[i]);
                    }
                }
                if (!less) {
                    s = document.createElement('link');
                    s.rel = 'stylesheet';
                    s.type = 'text/css';
                    s.href = path;
                    if (title) {
                        s.title = title;
                    }
                    s.disabled = false;
                    loadedPaths.push(path);
                }
            } else {
                resolve(false);
            }

            if (s) {
                let head = document.getElementsByTagName('head')[0];
                head.appendChild(s);
                s.onload = function () {
                    resolve(s);
                };
            }
        });
    }
}

/**
* 禁用浏览器的默认行为
*/
function disableScreenElasticity() {
    // ios
    // 禁用不需要的浏览器默认行为
    let $win = $(window);
    // 禁止ios的浏览器容器弹性
    $win
        .on('scroll.elasticity', function (e) {
            e.preventDefault();
        })
        .on('touchmove.elasticity', function (e) {
            e.preventDefault();
        });

    // 禁止拖动图片
    $win.delegate('img', 'mousemove', function (e) {
        e.preventDefault();
    });
}

/**
 * 获取当前元素，或窗口的滚动位置
 * @param el
 * @return {{x: number, y: number}}
 */
function getScrollPosition(el = window) {
    return {
        x: (el.pageXOffset !== undefined) ? el.pageXOffset : el.scrollLeft,
        y: (el.pageYOffset !== undefined) ? el.pageYOffset : el.scrollTop
    }
}

/**
 * 判断一个对象是否为Dom对象
 * @param   {Object}   obj
 * @return  {Boolean}
 */
function isDom(obj) {
    return obj && obj.nodeType === 1 && typeof (obj.nodeName) == 'string'
}

/**
 * 获取HTML里的文字内容
 * @param {string} str html字符串
 * @return {string} 处理后的文字
 * @example
 * getDecodeHTMLText('<li>111<span>222</span></li>')
 */
function getDecodeHTMLText(str) {
    const element = document.createElement('div');
    if (str && typeof str === 'string') {
        // strip script/html tags
        str = str.replace(/<script[^>]*>([\S\s]*?)<\/script>/gmi, '');
        str = str.replace(/<\/?\w(?:[^"'>]|"[^"]*"|'[^']*')*>/gmi, '');
        element.innerHTML = str;
        str = element.textContent;
        element.textContent = '';
    }
    return str;
}

/**
 * 字符串的转义,将`&`, `<`, `>`, `"`, `'`分别转义为`&amp;`, `&lt;`,  `&gt;`, `&quot;`, `&#x27;`
 * @param {string} text处理前字符串
 * @return {string} 处理后的字符串
 * @runkit true
 * @example
 * getEscapeText('<hello>')
 * // '&lt;hello&gt;'
 */
function getEscapeText(text) {
    const _escape = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;'
    }
    const escapeExpr = /(&|<|>|"|')/g
    return ('' + text).replace(escapeExpr, function (match) {
        return _escape[match]
    });
}

/**
 * 字符串的反转义,将`&amp;`, `&lt;`,  `&gt;`, `&quot;`, `&#x27;`替换为转义前的符号
 * @param {string} text 处理前字符串
 * @return {string} 处理后的字符串
 * @runkit true
 * @example
 * getUnescapeText('&lt;hello&gt;')
 * // '<hello>'
 */
function getUnescapeText(text) {
    const _unescape = {
        '&amp;': '&',
        '&lt;': '<',
        '&gt;': '>',
        '&quot;': '"',
        '&#x27;': "'"
    }
    const unescapeExpr = /(&amp;|&lt;|&gt;|&quot;|&#x27;)/g;
    return ('' + text).replace(unescapeExpr, function (match) {
        return _unescape[match];
    });
}

/**
 * 将文本插入到文本区域的光标位置
 * _应用场景：_如在评论框里，在光标位置里插入emoji等
 * @param {object} dom对象
 * @param {string} str
 * @example
 * <textarea name="textarea" rows="10" cols="50">你好世界~</textarea>
 * const editText = document.querySelector('#editText');
 * insertText(editText, 'hello world');
 * // =>
 */
function insertAtCaret(dom, str = '') {
    if (document.selection) { // IE
        let sel = document.selection.createRange();
        sel.text = str;
    } else if (typeof dom.selectionStart === 'number' && typeof dom.selectionEnd === 'number') {
        let startPos = dom.selectionStart;
        let endPos = dom.selectionEnd;
        let cursorPos = startPos;
        let tmpStr = dom.value;

        dom.value = tmpStr.substring(0, startPos) + str + tmpStr.substring(endPos, tmpStr.length);
        cursorPos += str.length;
        dom.selectionStart = dom.selectionEnd = cursorPos;
    } else {
        dom.value += str;
    }
}
/**
 * 全屏
*/
let toFullScreen = () => {
    let el = document.documentElement;
    let rfs = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen;

    //typeof rfs != "undefined" && rfs
    if (rfs) {
        rfs.call(el);
    } else if (typeof window.ActiveXObject !== "undefined") {
        //for IE，这里其实就是模拟了按下键盘的F11，使浏览器全屏
        let wscript = new ActiveXObject("WScript.Shell");
        if (wscript != null) {
            wscript.SendKeys("{F11}");
        }
    } else {
        alert("浏览器不支持全屏");
    }
}

/**
 * 退出全屏
*/
let exitFullscreen = function () {
    let el = parent.document;
    let cfs = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullScreen;

    //typeof cfs != "undefined" && cfs
    if (cfs) {
        cfs.call(el);
    } else if (typeof window.ActiveXObject !== "undefined") {
        //for IE，这里和fullScreen相同，模拟按下F11键退出全屏
        let wscript = new ActiveXObject("WScript.Shell");
        if (wscript != null) {
            wscript.SendKeys("{F11}");
        }
    } else {
        alert("切换失败,可尝试Esc退出")
    }
}
/**
* 是否是Element
* @param el
* @return {*|boolean}
*/
function isElement(el) {
    return el && el.nodeType === Node.ELEMENT_NODE
}

/**
 * @name 防抖
 * @param {function} [fn=v=>v] 函数
 * @param {number} [dura=50] 时延
 */
function Debounce(fn = v => v, dura = 50) {
    let timer = null;
    return function (...args) {
        timer && clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), dura);
    };
}

/**
 * @name 节流
 * @param {function} [fn=v=>v] 函数
 * @param {number} [dura=50] 时延
 */
function Throttle(fn = v => v, dura = 50) {
    let pass = 0;
    return function (...args) {
        const now = +new Date();
        if (now - pass > dura) {
            pass = now;
            fn.apply(this, args);
        }
    };
}
// function handle() {      
//     console.log(Math.random());
// } 
// window.addEventListener('scroll', Throttle(handle, 1000));

/**
 * @name 等待
 * @param {number} [dura=1000] 时延
 */
async function WaitFor(dura = 1000) {
    return new Promise(resolve => setTimeout(() => resolve(true), dura));
}

/**
 * 格式化银行卡 
 * 用户在输入银行卡号时，需要以4位4位的形式显示，就是每隔4位加个空格，方便用户校对输入的银行卡是否正确<br>
 * **注：**一般数据库里面存的都是不带格式的原始数据，所以提交的时候记得过滤下空格再提交哦。毕竟格式化这种算是表现层，前端展示的时候处理下就好，业务逻辑什么用到的卡号可不是格式化后的呢。<br>
 * 还原`val.replace(/\s/g, '');`
 * @param {string} val
 * @returns {*}
 * @example
 * formatBankCard('6225365271562822');
 * // => 6225 3652 7156 2822
 */
function formatBankCard(val) {
    if (typeof val !== 'string') throw new Error('输入值必须为字符串');

    const len = val.length;
    const reg = /(\d{4})(?=\d)/g;

    if (len < 4) {
        return val;
    } else {
        return val.replace(reg, '$1 ');
    }
}

/**
 * @desc 对css属性针对不同浏览器加私有前缀
 * @desc 先计算下当前浏览器支持那个前缀，支持哪个，就增加那个前缀。并不是把所有的前缀。
 * style: 是字符串，例如： transform
 * return: 字符串 。例如： webkitTransform （驼峰模式，js插入css的属性都是驼峰格式）
 */
function prefixStyle(style) {
    let vendor = (() => {
        let elementStyle = document.createElement('div').style
        let tranformNames = {
            webkit: 'webkitTransform',
            Moz: 'MozTransform',
            O: 'OTransform',
            ms: 'msTransform',
            standard: 'transform',
        }
        for (let key in tranformNames) {
            if (elementStyle[tranformNames[key]] !== undefined) {
                return key
            }
        }
        return false
    })()
    if (vendor === false) {
        return false
    }
    if (vendor === 'standard') {
        return style
    }
    return vendor + style.charAt(0).toUpperCase() + style.substr(1)
}



/**
 * 图片下载，将canvas，或者base64，下载下来
 * @param canvas 可以是canvas 元素，或者是base64字符串
 * @param name 文件名
 * @param format 图片格式
 */
function download(canvas, name, format) {

    // 这里是获取到的图片base64编码,这里只是个例子哈，要自行编码图片替换这里才能测试看到效果
    let imgUrl = canvas;
    if (canvas.toDataURL) {
        imgUrl = canvas.toDataURL();
    }

    // 如果浏览器支持msSaveOrOpenBlob方法（也就是使用IE浏览器的时候），那么调用该方法去下载图片
    if (window.navigator.msSaveOrOpenBlob) {
        let bstr = atob(imgUrl.split(',')[1]);
        let n = bstr.length;
        let u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        let blob = new Blob([u8arr]);
        window.navigator.msSaveOrOpenBlob(blob, name + '.' + format)
    } else {
        // 这里就按照chrome等新版浏览器来处理
        const a = document.createElement('a');
        a.href = imgUrl;
        a.setAttribute('download', name + '.' + format);
        a.click();
    }
}

/**
 * 蒋图片转成base64
 * width、height调用时传入具体像素值，控制大小 ,不传则默认图像大小
 * 可以会有跨域问题，建议是同源
 * @param imgSrc 图片地址
 * @param width 
 * @param height
 * @returns {string}
 */
function getBase64Image(imgSrc, width, height) {
    return new Promise((resolve) => {
        const newImg = new Image();
        newImg.setAttribute('crossOrigin', 'anonymous');
        newImg.src = imgSrc;
        const canvas = document.createElement('canvas');
        canvas.width = width || img.width;
        canvas.height = height || img.height;
        const ctx = canvas.getContext('2d');
        newImg.onload = function () {
            ctx.drawImage(newImg, 0, 0, canvas.width, canvas.height);
            const dataURL = canvas.toDataURL('image/png', 1);
            resolve(dataURL);
        };
    });
}

/**
 * canvas标签转换成img标签
 * @param canvas 标签，不是jquery对象
 * @returns {HTMLElement}
 */
function canvasToImage(canvas) {
    const img = document.createElement('img');
    img.style.backgroundColor = canvas.style.backgroundColor;
    img.width = canvas.width;
    img.height = canvas.height;
    const dataURL = canvas.toDataURL('image/png', 1);
    img.src = dataURL;
    return img;
}

/**
* Base64转Blob对象
* @param base64Data
* @return {Blob}
*/
function dataURItoBlob(base64Data = '') {
    try {
        let byteString;
        let mimeString = '';
        if (base64Data.split(',')[0].indexOf('base64') >= 0) {
            byteString = window.atob(base64Data.split(',')[1]);
        } else {
            byteString = unescape(base64Data.split(',')[1]);
        }
        mimeString = base64Data.split(',')[0].split(':')[1].split(';')[0];
        const ia = new Uint8Array(byteString.length);
        for (let i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new window.Blob([ia], { type: mimeString });
    } catch (error) {
        console.log(error);
    }
}

/**
 * 创建一个canvas，并获取 CanvasRenderingContext2D
 * @returns {{canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D}}
 */
export function create2dContext(width, height) {
    let canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height
    let ctx = canvas.getContext('2d')
    return {
        canvas,
        ctx
    }
}

/**
 * 将内容以文件形式下载下来
 */
function downloadFile(json, fileName, format) {
    // 这里就按照chrome等新版浏览器来处理
    const a = document.createElement('a');
    let blob = new Blob([json]);
    a.href = URL.createObjectURL(blob);
    a.setAttribute('download', fileName + '.' + format);
    a.click();
}

/**
 * 
 * @desc 判断浏览器是否支持webP格式图片
 * @return {Boolean} 
 */
function isSupportWebP() {
    return !![].map && document.createElement('canvas').toDataURL('image/webp').indexOf('data:image/webp') == 0;
}


/**
* 计算两点的距离
* @param x0 两点的坐标
* @param y0
* @param x1
* @param y1
* @return {number}
*/
function distance(x0, y0, x1, y1) {
    return Math.hypot(x1 - x0, y1 - y0)
}

/**
 * 求：组合C(m, n)，m为上标，n为下标。m选n的所有项
 * m {必传} 原始数据
 * n {必传} 当前项还需元素的个数
 * currentIndex 当前索引
 * choseArr 当前项的部分元素集合（不是完整项，是生成完整项的一个中间状态）
 * result 所有项的结果结合
 * 例子：
 * var arr1 = ['a', 'b', 'c', 'd']
 & console.log('arr1111', cmn(arr1, 2))
 */
function cmn(m, n, currentIndex = 0, choseArr = [], result = []) {
    let mLen = m.length
    // 可选数量小于项所需元素的个数，则递归终止
    if (currentIndex + n > mLen) {
        return
    }
    for (let i = currentIndex; i < mLen; i++) {
        // n === 1的时候，说明choseArr在添加一个元素，就能生成一个新的完整项了。
        // debugger
        if (n === 1) {
            // 再增加一个元素就能生成一个完整项，再加入到结果集合中
            result.push([...choseArr, m[i]])
            // 继续下一个元素生成一个新的完整项
            i + 1 < mLen && cmn(m, n, i + 1, choseArr, result)
            break
        }
        // 执行到这，说明n > 2，choseArr还需要两个以上的元素，才能生成一个新的完整项。则递归，往choseArr添加元素
        cmn(m, n - 1, i + 1, [...choseArr, m[i]], result)
    }
    return result
}

/**
* 求最大公约数
* @param a
* @param b
* @return {*}
*/
function gcd(a, b) {
    let x = a, y = b;
    function _gcd(_x, _y) {
        return !_y ? _x : _gcd(_y, _x % _y)
    }
    return _gcd(a, b);
}

/**
* 是否可以整除
* @param dividend 被除数
* @param divisor 除数
* @return {boolean}
*/
function isDivisible(dividend, divisor) {
    return dividend % divisor === 0
}

/**
* 最小公倍数
* @param x
* @param y
* @return {number}
*/
function lcm(x, y) {
    const gcd = (x, y) => !y ? x : gcd(y, x % y);
    return Math.abs(x * y) / (gcd(x, y));
}

/**
 * 斐波那契数组生成器
 * 创建一个特定长度的空数组，初始化前两个值（0和1）。使用Array.reduce（）向数组中添加值，后面的一个数等于前面两个数相加之和（前两个除外）。
 * @since 1.2.1
 * @param num
 * @returns {*}
 * @example
 * fibonacci(5);
 * // => [0,1,1,2,3]
 */
function fibonacci(num) {
    return Array(num).fill(0).reduce((acc, val, i) => acc.concat(i > 1 ? acc[i - 1] + acc[i - 2] : i), []);
}

/**
 * 给数字位数前面补0
 * @param num 数字
 * @param len 数字的位数
 * @returns {string|*}
 */
function formatZero(num, len) {
    if (String(num).length > len) return num;
    return (Array(len).join(0) + num).slice(-len);
}

/**
* 角度转换为弧度
* @param x 角度
* @return {number}
*/
function deg2arc(x) {
    return x / 180 * Math.PI;
}

/**
* 弧度转换为角度
* @param a 弧度
* @return {number}
*/
function arc2deg(a) {
    return a * 180 / Math.PI;
}


/**
 * 生成随机数， 在区间范围内
 * @param min 区间最小值
 * @param max 区间最大值
 * @return {null|number}
 */
function random(min, max) {
    if (arguments.length === 2) {
        return Math.floor(min + Math.random() * ((max + 1) - min))
    } else {
        return null;
    }

}

/**
 * 将阿拉伯数字翻译成中文的数字
 */
function numberToChinese(num) {
    let AA = new Array("零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十");
    let BB = new Array("", "十", "百", "仟", "萬", "億", "点", "");
    let a = ("" + num).replace(/(^0*)/g, "").split("."),
        k = 0,
        re = "";
    for (let i = a[0].length - 1; i >= 0; i--) {
        switch (k) {
            case 0:
                re = BB[7] + re;
                break;
            case 4:
                if (!new RegExp("0{4}//d{" + (a[0].length - i - 1) + "}$")
                    .test(a[0]))
                    re = BB[4] + re;
                break;
            case 8:
                re = BB[5] + re;
                BB[7] = BB[5];
                k = 0;
                break;
        }
        if (k % 4 == 2 && a[0].charAt(i + 2) != 0 && a[0].charAt(i + 1) == 0)
            re = AA[0] + re;
        if (a[0].charAt(i) != 0)
            re = AA[a[0].charAt(i)] + BB[k % 4] + re;
        k++;
    }

    if (a.length > 1) // 加上小数部分(如果有小数部分)
    {
        re += BB[6];
        for (let i = 0; i < a[1].length; i++)
            re += AA[a[1].charAt(i)];
    }
    if (re == '一十')
        re = "十";
    if (re.match(/^一/) && re.length == 3)
        re = re.replace("一", "");
    return re;
}

/**
 * 将数字转换为大写金额
 */
function changeToChinese(Num) {
    //判断如果传递进来的不是字符的话转换为字符
    if (typeof Num == "number") {
        Num = new String(Num);
    };
    Num = Num.replace(/,/g, "") //替换tomoney()中的“,”
    Num = Num.replace(/ /g, "") //替换tomoney()中的空格
    Num = Num.replace(/￥/g, "") //替换掉可能出现的￥字符
    if (isNaN(Num)) { //验证输入的字符是否为数字
        //alert("请检查小写金额是否正确");
        return "";
    };
    //字符处理完毕后开始转换，采用前后两部分分别转换
    let part = String(Num).split(".");
    let newchar = "";
    //小数点前进行转化
    for (let i = part[0].length - 1; i >= 0; i--) {
        if (part[0].length > 10) {
            return "";
            //若数量超过拾亿单位，提示
        }
        let tmpnewchar = ""
        let perchar = part[0].charAt(i);
        switch (perchar) {
            case "0":
                tmpnewchar = "零" + tmpnewchar;
                break;
            case "1":
                tmpnewchar = "壹" + tmpnewchar;
                break;
            case "2":
                tmpnewchar = "贰" + tmpnewchar;
                break;
            case "3":
                tmpnewchar = "叁" + tmpnewchar;
                break;
            case "4":
                tmpnewchar = "肆" + tmpnewchar;
                break;
            case "5":
                tmpnewchar = "伍" + tmpnewchar;
                break;
            case "6":
                tmpnewchar = "陆" + tmpnewchar;
                break;
            case "7":
                tmpnewchar = "柒" + tmpnewchar;
                break;
            case "8":
                tmpnewchar = "捌" + tmpnewchar;
                break;
            case "9":
                tmpnewchar = "玖" + tmpnewchar;
                break;
        }
        switch (part[0].length - i - 1) {
            case 0:
                tmpnewchar = tmpnewchar + "元";
                break;
            case 1:
                if (perchar != 0) tmpnewchar = tmpnewchar + "拾";
                break;
            case 2:
                if (perchar != 0) tmpnewchar = tmpnewchar + "佰";
                break;
            case 3:
                if (perchar != 0) tmpnewchar = tmpnewchar + "仟";
                break;
            case 4:
                tmpnewchar = tmpnewchar + "万";
                break;
            case 5:
                if (perchar != 0) tmpnewchar = tmpnewchar + "拾";
                break;
            case 6:
                if (perchar != 0) tmpnewchar = tmpnewchar + "佰";
                break;
            case 7:
                if (perchar != 0) tmpnewchar = tmpnewchar + "仟";
                break;
            case 8:
                tmpnewchar = tmpnewchar + "亿";
                break;
            case 9:
                tmpnewchar = tmpnewchar + "拾";
                break;
        }
        let newchar = tmpnewchar + newchar;
    }
    //小数点之后进行转化
    if (Num.indexOf(".") != -1) {
        if (part[1].length > 2) {
            // alert("小数点之后只能保留两位,系统将自动截断");
            part[1] = part[1].substr(0, 2)
        }
        for (i = 0; i < part[1].length; i++) {
            tmpnewchar = ""
            perchar = part[1].charAt(i)
            switch (perchar) {
                case "0":
                    tmpnewchar = "零" + tmpnewchar;
                    break;
                case "1":
                    tmpnewchar = "壹" + tmpnewchar;
                    break;
                case "2":
                    tmpnewchar = "贰" + tmpnewchar;
                    break;
                case "3":
                    tmpnewchar = "叁" + tmpnewchar;
                    break;
                case "4":
                    tmpnewchar = "肆" + tmpnewchar;
                    break;
                case "5":
                    tmpnewchar = "伍" + tmpnewchar;
                    break;
                case "6":
                    tmpnewchar = "陆" + tmpnewchar;
                    break;
                case "7":
                    tmpnewchar = "柒" + tmpnewchar;
                    break;
                case "8":
                    tmpnewchar = "捌" + tmpnewchar;
                    break;
                case "9":
                    tmpnewchar = "玖" + tmpnewchar;
                    break;
            }
            if (i == 0) tmpnewchar = tmpnewchar + "角";
            if (i == 1) tmpnewchar = tmpnewchar + "分";
            newchar = newchar + tmpnewchar;
        }
    }
    //替换所有无用汉字
    while (newchar.search("零零") != -1)
        newchar = newchar.replace("零零", "零");
    newchar = newchar.replace("零亿", "亿");
    newchar = newchar.replace("亿万", "亿");
    newchar = newchar.replace("零万", "万");
    newchar = newchar.replace("零元", "元");
    newchar = newchar.replace("零角", "");
    newchar = newchar.replace("零分", "");
    if (newchar.charAt(newchar.length - 1) == "元") {
        newchar = newchar + "整"
    }
    return newchar;
}
/**
* 生成唯一值uuid
* @return {string}
*/
function uuid() {
    const s4 = () => {
        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    };
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}

/**
 * @name 字节大小
 * @param {number} [byte=0] 字节
 */
function ByteSize(byte = 0) {
    if (byte === 0) return "0 B";
    const unit = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    const i = Math.floor(Math.log(byte) / Math.log(unit));
    return (byte / Math.pow(unit, i)).toPrecision(3) + " " + sizes[i];
}

/**
 * @name 千分数值格式
 * @param {number} [num=0] 数值
 */
function ThousandNum(num = 0) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * 加法函数，用来得到精确的加法结果
 * javascript的加法结果会有误差，在两个浮点数相加的时候会比较明显。这个函数返回较为精确的加法结果。
 *
 * @param {number} arg1
 * @param {number} arg2
 * @returns {number} arg1加上arg2的精确结果
 * @example
 * accAdd(0.1, 0.2)
 * // => 0.3
 */
function accAdd(arg1, arg2) {
    let r1, r2, m, c;
    try {
        r1 = arg1.toString().split('.')[1].length;
    } catch (e) {
        r1 = 0;
    }
    try {
        r2 = arg2.toString().split('.')[1].length;
    } catch (e) {
        r2 = 0;
    }
    c = Math.abs(r1 - r2);
    m = Math.pow(10, Math.max(r1, r2));
    if (c > 0) {
        let cm = Math.pow(10, c);
        if (r1 > r2) {
            arg1 = Number(arg1.toString().replace('.', ''));
            arg2 = Number(arg2.toString().replace('.', '')) * cm;
        } else {
            arg1 = Number(arg1.toString().replace('.', '')) * cm;
            arg2 = Number(arg2.toString().replace('.', ''));
        }
    } else {
        arg1 = Number(arg1.toString().replace('.', ''));
        arg2 = Number(arg2.toString().replace('.', ''));
    }
    return (arg1 + arg2) / m;
}

/**
 * 除法函数，用来得到精确的除法结果
 * javascript的除法结果会有误差，在两个浮点数相除的时候会比较明显。这个函数返回较为精确的除法结果。
 * @param {number} arg1
 * @param {number} arg2
 * @returns {number} arg1除以arg2的精确结果
 * @example
 * accDiv(0.2, 0.3)
 * // => 0.6666666666666666
 */
function accDiv(arg1, arg2) {
    let t1 = 0, t2 = 0, r1, r2;
    try {
        t1 = arg1.toString().split('.')[1].length;
    } catch (e) {
        console.error(e);
    }
    try {
        t2 = arg2.toString().split('.')[1].length;
    } catch (e) {
        console.error(e);
    }
    r1 = Number(arg1.toString().replace('.', ''));
    r2 = Number(arg2.toString().replace('.', ''));
    return (r1 / r2) * Math.pow(10, t2 - t1);
}


/**
 * 乘法函数，用来得到精确的乘法结果
 * javascript的乘法结果会有误差，在两个浮点数相乘的时候会比较明显。这个函数返回较为精确的乘法结果。
 * @param {number} arg1
 * @param {number} arg2
 * @returns {number} arg1乘以arg2的精确结果
 * @example
 * accMul(0.222, 0.3333)
 * // => 0.0739926
 */
function accMul(arg1, arg2) {
    let m = 0;
    let s1 = arg1.toString();
    let s2 = arg2.toString();
    try {
        s1.split('.')[1] && (m += s1.split('.')[1].length);
    } catch (e) {
        console.error(e);
    }
    try {
        s2.split('.')[1] && (m += s2.split('.')[1].length);
    } catch (e) {
        console.error(e);
    }
    return Number(s1.replace('.', '')) * Number(s2.replace('.', '')) / Math.pow(10, m);
}

/**
 * 减法函数，用来得到精确的减法结果
 * javascript的减法结果会有误差，在两个浮点数相减的时候会比较明显。这个函数返回较为精确的减法结果。
 * @param {number} arg1
 * @param {number} arg2
 * @returns {number} arg1减去arg2的精确结果
 * @example
 * accSub(0.3, 0.2)
 * // => 0.1
 */
function accSub(arg1, arg2) {
    let r1, r2, m, n;
    try {
        r1 = arg1.toString().split('.')[1].length;
    } catch (e) {
        r1 = 0;
    }
    try {
        r2 = arg2.toString().split('.')[1].length;
    } catch (e) {
        r2 = 0;
    }
    m = Math.pow(10, Math.max(r1, r2)); // last modify by deeka //动态控制精度长度
    n = (r1 >= r2) ? r1 : r2;
    return ((arg1 * m - arg2 * m) / m).toFixed(n);
}

/**
 * 校验对象是否是某个类型
 * @param obj 要校验的对象
 * @param type 类型
 * @returns {*|URL}
 */
function checkType(obj, type) {
    return Object.prototype.toString.call(obj).toLowerCase() === `[object ${type}]`;
}

/**
* 是否对象类型
* @param obj
* @return {*|URL}
*/
function isObject(obj) {
    return checkType(obj, 'object');
}

/**
* 是否数组类型
* @param arr
* @return {*|URL}
*/
function isArray(arr) {
    return checkType(arr, 'array');
}

/**
* 是否是函数
* @param fun
* @return {*|URL}
*/
function isFunction(fun) {
    return checkType(fun, 'function')
}

/**
 * 是否是字符串
 * @param {*} obj
 */
function isString(obj) {
    return checkType(obj, 'string')
}

/**
 * 是否时blob
 * @param {*} obj
 */
function isBlob(obj) {
    return checkType(obj, 'blob')
}

/**
 * 
 * @desc   判断对象是否为空
 * @param  {Object} obj
 * @return {Boolean}
 */
function isEmptyObject(obj) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj))
        return false
    return !Object.keys(obj).length
}

/**
* class 类多继承
* @param mixins
* @return {Mix}
*/
function mix(...mixins) {
    // 深拷贝
    function copyProperties(target, source) {
        for (let key of Reflect.ownKeys(source)) {
            if (key !== 'constructor' && key !== 'prototype' && key !== 'name') {
                let desc = Object.getOwnPropertyDescriptor(source, key);
                Object.defineProperty(target, key, desc);
            }
        }
    }
    class Mix {
        constructor(...param) {
            for (let mixin of mixins) {
                copyProperties(this, new mixin(...param)); // 拷贝实例属性
            }
        }
    }

    for (let mixin of mixins) {
        copyProperties(Mix, mixin); // 拷贝静态属性
        copyProperties(Mix.prototype, mixin.prototype); // 拷贝原型属性
    }
    return Mix;
}

/**
 * 深层克隆对象
 * @param obj
 * @returns {*}
 * @example
 * const a = { foo: 'bar', obj: { a: 1, b: 2 } };
 * const b = deepClone(a);
 * // => a !== b, a.obj !== b.obj
 */
function deepClone(obj) {
    let clone = Object.assign({}, obj);
    Object.keys(clone).forEach(
        (key) => (clone[key] = typeof obj[key] === 'object' ? deepClone(obj[key]) : obj[key])
    );
    return Array.isArray(obj) && obj.length
        ? (clone.length = obj.length) && Array.from(clone)
        : Array.isArray(obj)
            ? Array.from(obj)
            : clone;
}

/**
 * 两个对象（值）之间的深入比较，以确定它们是否相等
 * @param {Object} a
 * @param {Object} b
 * @returns {*}
 * @example
 * equals({ a: [2, { e: 3 }], b: [4], c: 'foo' }, { a: [2, { e: 3 }], b: [4], c: 'foo' });
 * // => true
 */
function equals(a, b) {
    if (a === b) return true;
    if (a instanceof Date && b instanceof Date) return a.getTime() === b.getTime();
    if (!a || !b || (typeof a !== 'object' && typeof b !== 'object')) return a === b;
    if (a === null || a === undefined || b === null || b === undefined) return false;
    if (a.prototype !== b.prototype) return false;
    let keys = Object.keys(a);
    if (keys.length !== Object.keys(b).length) return false;

    return keys.every((k) => equals(a[k], b[k]));
}

/**
 * 过滤对象中为空的属性
 * @param obj
 * @returns {*}
 * @example
 * filterEmptyPropObj({name: 'foo', sex: ''})
 * // => {name: 'foo'}
 */
function filterEmptyPropObj(obj) {
    if (!(typeof obj == 'object')) return;

    for (let key in obj) {
        if (obj.hasOwnProperty(key)
            && (obj[key] == null || obj[key] == undefined || obj[key] === '')) {
            delete obj[key];
        }
    }
    return obj;
}

/**
 * 反转对象的键值对
 * 而不会改变它。使用 Object.keys() 和 Array.reduce() 来反转对象的键值对。
 * @param obj
 * @returns {{}}
 * @example
 * invertKeyValues({ name: 'John', age: 20 });
 * // => { 20: 'age', John: 'name' }
 */
function invertKeyValues(obj) {
    Object.keys(obj).reduce((acc, key) => {
        acc[obj[key]] = key;
        return acc;
    }, {});
}

/**
 * 数组转换为键值对的对象
 * @since 1.2.1
 * @param array
 * @returns {*}
 * @example
 * objectFromPairs([['a',1],['b',2]]);
 * // => {a: 1, b: 2}
 */
function objectFromPairs(array) {
    return Array.isArray(array) && array.reduce((a, v) => (a[v[0]] = v[1], a), {});
}

/**
 * 对象转化为键值对
 * 使用 Object.keys() 和 Array.map() 遍历对象的键并生成一个包含键值对的数组。
 * @param obj
 * @returns {any[][]}
 * @example
 * objectToPairs({ a: 1, b: 2 });
 * // => [['a',1],['b',2]]
 */
function objectToPairs(obj) {
    return Object.keys(obj).map((k) => [k, obj[k]]);
} 

/**
 * 是否由 26 个英文字母组成的字符串
 * @param val string
 * @return {boolean}
 */
function isAZaz(val) {
    return /^[A-Za-z]+$/.test(val);
}

/**
 * 是否由 26 个英文字母的大写组成的字符串
 * @param val
 * @return {boolean}
 */
function isAZ(val) {
    return /^[A-Z]+$/.test(val);
}

/**
 * 是否由 26 个英文字母的小写组成的字符串
 * @param val
 * @return {boolean}
 */
function isaz(val) {
    return /^[a-z]+$/.test(val);
}

/**
 * 是否为数字
 * @return {boolean}
 */
function isNumber(str) {
    return /^[0-9]$/.test(str)
}

/**
 * 是否为中文
 * @return {boolean}
 */
function isChinese(str) {
    return /^[\u4E00-\u9FA5]+$/.test(str)
}

/**
 * 是否为手机号
 * @return {boolean}
 */
function isPhone(str) {
    return /^1[3|4|5|6|7|8|9][0-9]{9}$/.test(str)
}

/**
 * 是否电子邮件
 * @param val
 * @return {boolean}
 */
function isEmail(val) {
    return /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(val) || /w+([-+.]w+)*@w+([-.]w+)*.w+([-.]w+)*/.test(val);
}

/**
 * 是否为座机号
 * @return {boolean}
 */
function isTel(str) {
    return /^(0\d{2,3}-\d{7,8})(-\d{1,4})?$/.test(str)
}

/**
 * 是否为身份证
 * @return {boolean}
 */
function isIDCard(str) {
    return /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(str)
}

/**
 * 密码验证
 * 密码以字母开头，长度在6~18之间，只能包含字母、数字和下划线
 * @return {boolean}
 */
function isPWD(str) {
    return /^[a-zA-Z]\w{5,17}$/.test(str)
}

/**
 * 邮政编码
 * @return {boolean}
 */
function isPostal(str) {
    return /[1-9]\d{5}(?!\d)/.test(str)
}

/**
 * 是否为qq号
 * @param str
 * @return {boolean}
 */
function isQQ(str) {
    return /^[1-9][0-9]{4,9}$/.test(str)
}

/**
 * 是否为金额
 * 金额(小数点2位)
 * @param str
 * @return {boolean}
 */
function isMoney(str) {
    return /^\d*(?:\.\d{0,2})?$/.test(str)
}

/**
 * 是否为Url
 * @param str
 * @return {boolean}
 */
function isUrl(str) {
    return /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/.test(str)
}

/**
 * 是否为ip
 * @param str
 * @return {boolean}
 */
function isIp(str) {
    return /((?:(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d))/.test(str)
}

/**
 * 严格的身份证校验
 */
function isStrictIDCard(sId) {
    if (!/(^\d{15}$)|(^\d{17}(\d|X|x)$)/.test(sId)) {
        alert("你输入的身份证长度或格式错误");
        return false;
    }
    //身份证城市
    let aCity = {
        11: "北京",
        12: "天津",
        13: "河北",
        14: "山西",
        15: "内蒙古",
        21: "辽宁",
        22: "吉林",
        23: "黑龙江",
        31: "上海",
        32: "江苏",
        33: "浙江",
        34: "安徽",
        35: "福建",
        36: "江西",
        37: "山东",
        41: "河南",
        42: "湖北",
        43: "湖南",
        44: "广东",
        45: "广西",
        46: "海南",
        50: "重庆",
        51: "四川",
        52: "贵州",
        53: "云南",
        54: "西藏",
        61: "陕西",
        62: "甘肃",
        63: "青海",
        64: "宁夏",
        65: "新疆",
        71: "台湾",
        81: "香港",
        82: "澳门",
        91: "国外"
    };
    if (!aCity[parseInt(sId.substr(0, 2))]) {
        alert("你的身份证地区非法");
        return false;
    }

    // 出生日期验证
    let sBirthday = (
        sId.substr(6, 4) +
        "-" +
        Number(sId.substr(10, 2)) +
        "-" +
        Number(sId.substr(12, 2))
    ).replace(/-/g, "/"),
        d = new Date(sBirthday);
    if (
        sBirthday !=
        d.getFullYear() + "/" + (d.getMonth() + 1) + "/" + d.getDate()
    ) {
        alert("身份证上的出生日期非法");
        return false;
    }

    // 身份证号码校验
    let sum = 0,
        weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2],
        codes = "10X98765432";
    for (let i = 0; i < sId.length - 1; i++) {
        sum += sId[i] * weights[i];
    }
    let last = codes[sum % 11]; //计算出来的最后一位身份证号码
    if (sId[sId.length - 1] != last) {
        alert("你输入的身份证号非法");
        return false;
    }
    return true;
}

/**
 * 是否为 HTML 标签
 * @param {string} str
 * @returns {boolean}
 * @example
 * isHTML('<p>123</p>');
 * // => true
 */
function isHTML(str) {
    let reg = /<("[^"]*"|'[^']*'|[^'">])*>/;
    return reg.test(str);
}

/**
 * 检查是否为特殊字符
 * @param {string} value 正则校验的变量
 * @returns {boolean} 正则校验结果 true: 是特殊字符 false: 不是特殊字符
 */
function isSpecialChar(value) {
    var regEn = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]\s]/im;
    var regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]\s]/im;

    return regEn.test(value) || regCn.test(value);
}

/**
 * 是否为有效的统一社会信用代码
 * @param {string} val
 * @returns {boolean}
 * @example
 * isUnifiedSocialCreditCode('91230184MA1BUFLT44');
 * // => true
 * isUnifiedSocialCreditCode('92371000MA3MXH0E3W');
 * // => true
 */
function isUnifiedSocialCreditCode(val) {
    const reg = /[0-9A-HJ-NPQRTUWXY]{2}\d{6}[0-9A-HJ-NPQRTUWXY]{10}/;
    return reg.test(val);
}

/**
 * 是否为有效的A股代码
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidAShareCode('sz000858');
 * // => true
 * isValidAShareCode('SZ002136');
 * // => true
 * isValidAShareCode('SH600600');
 * // => true
 * isValidAShareCode('sh600600');
 * // => true
 */
function isValidAShareCode(val) {
    const reg = /^(s[hz]|S[HZ])(000[\d]{3}|002[\d]{3}|300[\d]{3}|600[\d]{3}|60[\d]{4})$/;
    return reg.test(val);
}

/**
 * 是否为有效的银行卡号（10到30位, 覆盖对公/私账户, 参考[微信支付](https://pay.weixin.qq.com/wiki/doc/api/xiaowei.php?chapter=22_1)）
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidBankNo('6234567890');
 * // => true
 * isValidBankNo('6222026006705354217');
 * // => true
 */
function isValidBankNo(val) {
    const reg = /^[1-9]\d{9,29}$/;

    return reg.test(val);
}

/**
 * 是否为有效的 base64格式
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidBase64Format('data:image/gif;base64,xxxx==')
 * => true
 */
function isValidBase64Format(val) {
    const reg = /^\s*data:(?:[a-z]+\/[a-z0-9-+.]+(?:;[a-z-]+=[a-z0-9-]+)?)?(?:;base64)?,([a-z0-9!$&',()*+;=\-._~:@/?%\s]*?)\s*$/i;
    return reg.test(val);
}

/**
 * 是否为有效的ed2k链接(宽松匹配)
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidEd2kLinkLoose('ed2k://|file|%E5%AF%84%E7%94%9F%E8%99%AB.PARASITE.2019.HD-1080p.X264.AAC-UUMp4(ED2000.COM).mp4|2501554832|C0B93E0879C6071CBED732C20CE577A3|h=5HTKZPQFYRKORN52I3M7GQ4QQCIHFIBV|/');
 * // => true
 */
function isValidEd2kLinkLoose(val) {
    const reg = /^ed2k:\/\/\|file\|.+\|\/$/;
    return reg.test(val);
}

/**
 * 是否为有效的IP v4
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidIPV4('172.16.0.0');
 * // => true
 * isValidIPV4('127.0.0.0');
 * // => true
 */
function isValidIPV4(val) {
    const reg = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return reg.test(val);
}

/**
 * 是否为有效的IP v6
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidIPV6('2031:0000:130f:0000:0000:09c0:876a:130b');
 * // => true
 */
function isValidIPV6(val) {
    const reg = /^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$/i;
    return reg.test(val);
}

/**
 * 是否为有效的md5格式(32位)
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidMD5('21fe181c5bfc16306a6828c1f7b762e8');
 * // => true
 */
function isValidMD5(val) {
    const reg = /^[a-f0-9]{32}$/;
    return reg.test(val);
}

/**
 * 是否为有效的护照（包含香港、澳门）
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidPassport('s28233515');
 * // => true
 * isValidPassport('141234567');
 * // => true
 * isValidPassport('159203084');
 * // => true
 * isValidPassport('MA1234567');
 * // => true
 * isValidPassport('K25345719');
 * // => true
 */
function isValidPassport(val) {
    const reg = /(^[EeKkGgDdSsPpHh]\d{8}$)|(^(([Ee][a-fA-F])|([DdSsPp][Ee])|([Kk][Jj])|([Mm][Aa])|(1[45]))\d{7}$)/;
    return reg.test(val);
}

/**
 * 是否为有效的子网掩码
 * @param {string} val
 * @returns {boolean}
 * @example
 * isValidSubnetMask('255.255.255.0');
 * // => true
 */
function isValidSubnetMask(val) {
    const reg = /^(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(?:\.(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/;
    return reg.test(val);
}


/**
 * 设置localStorage
 *
 */
function setLocalStorage(key, val) {
    let setting = arguments[0];
    if (Object.prototype.toString.call(setting).slice(8, -1) === 'Object') {
        for (let i in setting) {
            window.localStorage.setItem(i, JSON.stringify(setting[i]))
        }
    } else {
        window.localStorage.setItem(key, JSON.stringify(val))
    }
}
/**
 * 获取localStorage
 */
function getLocal(key) {
    if (key) return JSON.parse(window.localStorage.getItem(key))
    return null;
}

/**
 * 移除localStorage
 */
function removeLocal(key) {
    window.localStorage.removeItem(key)
}

/** 
 * 移除所有localStorage
 */
function clearLocal() {
    window.localStorage.clear()
}

/**
 * 设置sessionStorage
 */
function setSession(key, val) {
    let setting = arguments[0];
    if (Object.prototype.toString.call(setting).slice(8, -1) === 'Object') {
        for (let i in setting) {
            window.sessionStorage.setItem(i, JSON.stringify(setting[i]))
        }
    } else {
        window.sessionStorage.setItem(key, JSON.stringify(val))
    }
}

/**
 * 获取sessionStorage
 */
function getSession(key) {
    if (key) return JSON.parse(window.sessionStorage.getItem(key))
    return null;
}

/**
 * 移除sessionStorage
 */
function removeSession(key) {
    window.sessionStorage.removeItem(key)
}

/**
 * 移除所有sessionStorage
 */
function clearSession() {
    window.sessionStorage.clear()
}

/**
 * 去除空格
 * @param  {str}
 * @param  {type} :  1-所有空格  2-前后空格  3-前空格 4-后空格
 * @return {String}
 */
function trim(str, type) {
    type = type || 1
    switch (type) {
        case 1:
            return str.replace(/\s+/g, "");
        case 2:
            return str.replace(/(^\s*)|(\s*$)/g, "");
        case 3:
            return str.replace(/(^\s*)/g, "");
        case 4:
            return str.replace(/(\s*$)/g, "");
        default:
            return str;
    }
}

/**
 * 字符大小写转换
 * @param  {str}
 * @param  {type}:  1:首字母大写  2：首页母小写  3：大小写转换  4：全部大写  5：全部小写
 * @return {String}
 */
function changeCase(str, type) {
    type = type || 4
    switch (type) {
        case 1:
            return str.replace(/\b\w+\b/g, function (word) {
                return word.substring(0, 1).toUpperCase() + word.substring(1).toLowerCase();

            });
        case 2:
            return str.replace(/\b\w+\b/g, function (word) {
                return word.substring(0, 1).toLowerCase() + word.substring(1).toUpperCase();
            });
        case 3:
            return str.split('').map(function (word) {
                if (/[a-z]/.test(word)) {
                    return word.toUpperCase();
                } else {
                    return word.toLowerCase()
                }
            }).join('')
        case 4:
            return str.toUpperCase();
        case 5:
            return str.toLowerCase();
        default:
            return str;
    }
}

/**
 * @name 翻转字符
 * @param {string} [text=""] 字符
 */
function ReverseText(text = "") {
    return text.split("").reduceRight((t, v) => t + v);
}

/**
 * 下划线格式字符串转为驼峰格式
 * @param {string} text处理前字符串
 * @return {string} 处理后的字符串
 * @runkit true
 * @example
 * toCamelCase('to_camel_case')
 * // 'toCamelCase'
 */
function toCamelCase(str) {
    return str.replace(/\_[a-z]/g, function (item) {
        return item[1].toUpperCase();
    });
}

/**
 * 驼峰格式字符串转为下划线格式
 * @param {string} text处理前字符串
 * @return {string} 处理后的字符串
 */
function toSnakeCase(str) {
    return str.replace(/[A-Z]/g, function (item) {
        return "_" + item[0].toLowerCase();
    });
}

/**
 * 转义html(防XSS攻击)
 * @param str 字符串
 */
function escapeHTML(str) {
    return str.replace(
        /[&<>'"]/g,
        tag =>
            ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            }[tag] || tag)
    );
}


/**
 * 按类型格式化日期
 * @param {*} date 具体日期变量
 * @param {string} dateType 需要返回类型,包括（'yyyy年mm月dd日'，'yyyy-mm-dd'， 'yyyy.mm.dd'，'yyyy-mm-dd MM:mm:ss'， 'mm-dd MM:mm:ss'， 'yyyy年mm月dd日 MM:mm:ss'）
 * @return {string} dateText 返回为指定格式的日期字符串
 */
function getFormatDate(date, dateType) {
    let dateObj = new Date(date);
    let month = dateObj.getMonth() + 1;
    let strDate = dateObj.getDate();
    let hours = dateObj.getHours();
    let minutes = dateObj.getMinutes();
    let seconds = dateObj.getSeconds();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;

    }
    if (hours >= 0 && hours <= 9) {
        hours = "0" + hours
    }
    if (minutes >= 0 && minutes <= 9) {
        minutes = "0" + minutes
    }
    if (seconds >= 0 && seconds <= 9) {
        seconds = "0" + seconds
    }

    let dateText = dateObj.getFullYear() + '年' + (dateObj.getMonth() + 1) + '月' + dateObj.getDate() + '日';
    if (dateType == "yyyy-mm-dd") {
        dateText = dateObj.getFullYear() + '-' + (dateObj.getMonth() + 1) + '-' + dateObj.getDate();
    }
    if (dateType == "yyyy.mm.dd") {
        dateText = dateObj.getFullYear() + '.' + (dateObj.getMonth() + 1) + '.' + dateObj.getDate();
    }
    if (dateType == "yyyy-mm-dd MM:mm:ss") {
        dateText = dateObj.getFullYear() + '-' + month + '-' + strDate + ' ' + hours + ":" + minutes + ":" + seconds;
    }
    if (dateType == "mm-dd MM:mm:ss") {
        dateText = month + '-' + strDate + ' ' + hours + ":" + minutes + ":" + seconds;
    }
    if (dateType == "yyyy年mm月dd日 MM:mm:ss") {
        dateText = dateObj.getFullYear() + '年' + month + '月' + strDate + '日' + ' ' + hours + ":" + minutes + ":" + seconds;
    }
    return dateText;
}

/**
 * 设置几天后的日期
* @param  {string} date 起始日期
* @param  {number} day 向后的天数
* @return {string} 返回想要得到的日期
*/
function convertDate(date, day) {
    let tempDate = new Date(date);
    tempDate.setDate(tempDate.getDate() + day);
    let Y = tempDate.getFullYear();
    let M = tempDate.getMonth() + 1 < 10 ? '0' + (tempDate.getMonth() + 1) : tempDate.getMonth() + 1;
    let D = tempDate.getDate() < 10 ? '0' + (tempDate.getDate()) : tempDate.getDate();
    let result = Y + "-" + M + "-" + D
    return result;
}

/**
 * 获取当前时间的n天后的时间戳
 * @param {number} n 天数
 * @returns {Number} 返回值为时间毫秒值
 */
function toNextTimes(n) {
    let timestamp = +new Date() + n * 86400000;
    return timestamp;
}

/***
 * 本周第一天
 *  @return {*} WeekFirstDay 返回本周第一天的时间
 */
function showWeekFirstDay() {
    let Nowdate = new Date();
    let WeekFirstDay = new Date(Nowdate - (Nowdate.getDay() - 1) * 86400000);
    return WeekFirstDay;
}

/***
 * 本周最后一天
 *  @return {*} WeekLastDay 返回本周最后一天的时间
 */
function showWeekLastDay() {
    let nowDate = new Date();
    let weekFirstDay = new Date(nowDate - (nowDate.getDay() - 1) * 86400000);
    let WeekLastDay = new Date((weekFirstDay / 1000 + 6 * 86400) * 1000);
    return WeekLastDay;
}

/***
 * 本月第一天
 *  @return {*} MonthFirstDay 返回本月第一天的时间
 */
function showMonthFirstDay() {
    let Nowdate = new Date();
    let MonthFirstDay = new Date(Nowdate.getFullYear(), Nowdate.getMonth());
    return MonthFirstDay;
}

/***
 * 本月最后一天
 *  @return {*} MonthLastDay 返回本月最后一天的时间
 */
function showMonthLastDay() {
    let Nowdate = new Date();
    let MonthNextFirstDay = new Date(Nowdate.getFullYear(), Nowdate.getMonth() + 1);
    let MonthLastDay = new Date(MonthNextFirstDay - 86400000);
    return MonthLastDay;
}

/**
 * 日期转时间戳
 * @param {String} time - 日期字符串，如'2018-8-8','2018,8,8','2018/8/8'
 * @returns {Number} 返回值为时间毫秒值
 */
function timeToTimestamp(time) {
    let date = new Date(time);
    let timestamp = date.getTime();
    return timestamp;
}

/**
 * 返回指定时间戳之间的时间间隔
 *  @param {*} startTime 开始时间的时间戳
 *  @param {*} endTime 结束时间的时间戳
 *  @return {string} str 返回时间字符串 格式：yyyy年mm月dd日MM小时mm分钟ss秒前
 */
function getTimeInterval(startTime, endTime) {
    let runTime = parseInt((endTime - startTime) / 1000);
    let year = Math.floor(runTime / 86400 / 365);
    runTime = runTime % (86400 * 365);
    let month = Math.floor(runTime / 86400 / 30);
    runTime = runTime % (86400 * 30);
    let day = Math.floor(runTime / 86400);
    runTime = runTime % 86400;
    let hour = Math.floor(runTime / 3600);
    runTime = runTime % 3600;
    let minute = Math.floor(runTime / 60);
    runTime = runTime % 60;
    let second = runTime;
    let str = '';
    if (year > 0) {
        str = year + '年';
    }
    if (year <= 0 && month > 0) {
        str = month + '月';
    }
    if (year <= 0 && month <= 0 && day > 0) {
        str = day + '天';
    }
    if (year <= 0 && month <= 0 && day <= 0 && hour > 0) {
        str = hour + '小时';
    }
    if (year <= 0 && month <= 0 && day <= 0 && hour <= 0 && minute > 0) {
        str = minute + '分钟';
    }
    if (year <= 0 && month <= 0 && day <= 0 && hour <= 0 && minute <= 0 && second > 0) {
        str += second + '秒';
    }
    str += '前';
    return str;
}

/**
 * 星期转换，将数字转换成英文 0为sunday
 * @param num
 * @returns {null}
 */
function weekNumToStr(num) {
    let week = null;
    switch (num) {
        case 1: {
            week = 'MONDAY';
            break;
        }
        case 2: {
            week = "TUESDAY";
            break;
        }
        case 3: {
            week = "WEDNESDAY";
            break;
        }
        case 4: {
            week = "THURSDAY";
            break;
        }
        case 5: {
            week = "FRIDAY";
            break;
        }
        case 6: {
            week = "SATURDAY";
            break;
        }
        case 0: {
            week = "SUNDAY";
            break;
        }
    }
    return week;
}

/**
 * 月份转换，将数字转换成英文 0为January
 * @param num
 * @returns {null}
 */
function monthNumToStr(num) {
    let month = null;
    switch (num) {
        case 0: {
            month = 'JANUARY';
            break;
        }
        case 1: {
            month = "FEBRUARY";
            break;
        }
        case 2: {
            month = "MARCH";
            break;
        }
        case 3: {
            month = "APRIL";
            break;
        }
        case 4: {
            month = "MAY";
            break;
        }
        case 5: {
            month = "JUNE";
            break;
        }
        case 6: {
            month = "JULY";
            break;
        }
        case 7: {
            month = "AUGUST";
            break;
        }
        case 8: {
            month = "SEPTEMBER";
            break;
        }
        case 9: {
            month = "OCTOBER";
            break;
        }
        case 10: {
            month = "NOVEMBER";
            break;
        }
        case 11: {
            month = "DECEMBER";
            break;
        }

    }
    return month;
}

/**
 * 判断是否为闰年
* @param  {number} year 要判断的年份
* @return {boolean} 返回布尔值
*/
export function leapYear(year) {
    return !(year % (year % 100 ? 4 : 400));
}



/** 
 * 返回两个年份之间的闰年
* @param  {number} start 开始年份
* @param  {number} end 结束年份
* @return {array}  arr 返回符合闰年的数组
*/
export function leapYears(start, end) {
    let arr = [];
    for (var i = start; i < end; i++) {
        if (leapYear(i)) {
            arr.push(i)
        }
    }
    return arr
}

/**
* 判断是否在微信环境
* @return {boolean}
*/
function isWeixin() {
    // 如果需要可以增加判断电脑版微信和开发者工具:/WindowsWechat/i.test(ua) && /WechatDevTools/i.test(ua)
    return (/MicroMessenger/i.test(window.navigator.userAgent));
}

/**
* 是否安卓环境
* @return {boolean}
*/
function isAndroid() {
    return /Android/i.test(navigator.userAgent) || /Linux/i.test(navigator.appVersion);
}

/**
* 是否iphone环境
* @return {boolean}
*/
function iphoneCheck() {
    return /iPhone/i.test(navigator.userAgent);
}

/**
* 是否ios环境（包括iPhone和ipad）
* @return {boolean}
*/
function isIOS() {
    return (/ipad|iphone/i.test(navigator.userAgent));
}

/**
* 是否safari环境
* @return {boolean}
*/
function isSafari() {
    return (/msie|applewebkit.+safari/i.test(navigator.userAgent));
}

/** * 是否为windows系统 * */
const isWindows = function () {
    return /windows|win32/i.test(navigator.userAgent);
}

/** * 是否为mac系统（包含iphone手机） * */
const isMac = function () {
    return /macintosh|mac os x/i.test(navigator.userAgent);
}

/**
 * 是否是支付宝内核
 * @returns {boolean}
 * @example
 * inAlipay();
 * // => false
 */
function inAlipay() {
    if (typeof navigator === 'undefined') return;
    const ua = navigator.userAgent.toLowerCase();
    return ua.indexOf('alipayclient') !== -1;
}

/**
 * 是否是QQ浏览器内核
 * @returns {boolean}
 * @example
 * inQQBrowser();
 * // => false
 */
function inQQBrowser() {
    if (typeof window.navigator === 'undefined') return;
    const ua = window.navigator.userAgent.toLowerCase();
    return ua.indexOf('mqqbrowser') !== -1;
}

/**
 * 是否是UC浏览器内核
 * @returns {boolean}
 * @example
 * inUCBrowser();
 * // => false
 */
function inUCBrowser() {
    if (typeof window.navigator === 'undefined') return;
    const ua = window.navigator.userAgent.toLowerCase();
    return ua.indexOf('ucbrowser') !== -1;
}

/**
 * 是否是微博内核
 * @returns {boolean}
 * @example
 * inWeibo();
 * // => false
 */
function inWeibo() {
    if (typeof navigator === 'undefined') return;
    const ua = navigator.userAgent.toLowerCase();
    return ua.indexOf('weibo') !== -1;
}

/**
* 获取浏览器的类型
* @return {string}
*/
function browserType() {
    let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
    let isOpera = userAgent.indexOf("Opera") > -1; //判断是否Opera浏览器
    let isIE =
        userAgent.indexOf("compatible") > -1 &&
        userAgent.indexOf("MSIE") > -1 &&
        !isOpera; //判断是否IE浏览器
    let isIE11 =
        userAgent.indexOf("Trident") > -1 && userAgent.indexOf("rv:11.0") > -1;
    let isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
    let isFF = userAgent.indexOf("Firefox") > -1; //判断是否Firefox浏览器
    let isSafari =
        userAgent.indexOf("Safari") > -1 && userAgent.indexOf("Chrome") == -1; //判断是否Safari浏览器
    let isChrome =
        userAgent.indexOf("Chrome") > -1 && userAgent.indexOf("Safari") > -1; //判断Chrome浏览器

    if (isIE) {
        let reIE = new RegExp("MSIE (\\d+\\.\\d+);");
        reIE.test(userAgent);
        let fIEVersion = parseFloat(RegExp["$1"]);
        if (fIEVersion == 7) return "IE7";
        else if (fIEVersion == 8) return "IE8";
        else if (fIEVersion == 9) return "IE9";
        else if (fIEVersion == 10) return "IE10";
        else return "IE7以下"; //IE版本过低
    }
    if (isIE11) return "IE11";
    if (isEdge) return "Edge";
    if (isFF) return "FF";
    if (isOpera) return "Opera";
    if (isSafari) return "Safari";
    if (isChrome) return "Chrome";
}

/**
 * 获取设备像素比
 * @returns {number}
 * @example
 * // window.navigator.appVersion(5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1)
 * getPixelRatio();
 * // => 2
 */
function getPixelRatio() {
    let ctx = document.createElement('canvas').getContext('2d');
    let dpr = window.devicePixelRatio || 1;
    let bsr = ctx.webkitBackingStorePixelRatio ||
        ctx.mozBackingStorePixelRatio ||
        ctx.msBackingStorePixelRatio ||
        ctx.oBackingStorePixelRatio ||
        ctx.backingStorePixelRatio || 1;
    return dpr / bsr;
}

/**
 * 判断 iPhone X Series 机型，刘海屏
 * @returns {boolean}
 * @example
 * isPhoneX()
 * => true
 */
function isPhoneX() {
    // X XS, XS Max, XR
    const xSeriesConfig = [
        {
            devicePixelRatio: 3,
            width: 375,
            height: 812
        },
        {
            devicePixelRatio: 3,
            width: 414,
            height: 896
        },
        {
            devicePixelRatio: 2,
            width: 414,
            height: 896
        }
    ];
    // h5
    if (typeof window !== 'undefined' && window) {
        const isIOS = /iphone/gi.test(window.navigator.userAgent);
        if (!isIOS) return false;
        const { devicePixelRatio, screen } = window;
        const { width, height } = screen;
        return xSeriesConfig.some((item) => item.devicePixelRatio === devicePixelRatio && item.width === width && item.height === height);
    }
    return false;
}


/**
 * 给定 url, 返回一个 window.URL 实例
 * @param url
 * @returns {*|URL}
 */
function parseUrl(url) {
    if (url.startsWith('//')) {
        url = location.protocol + url;
    }
    return new window.URL(url);
}

/**
 * 获取url中的参数
 * @param name 为参数名
 * @param url 为获取参数的URL
 */
function getUrlParam(name, url = window.location.href) {
    return parseUrl(url).searchParams.get(name);
}

/**
 * 删除url中参数
 * @param name 为参数名
 * @returns {String}
 */
function removeUrlParam(param, url = window.location.href) {
    let obj = parseUrl(url);
    obj.searchParams.delete(param);
    return obj.href;
}

/**
 * 增加url中的参数
 * @param key
 * @param value
 * @param url
 * @returns {String}
 */
function addUrlParam(key, value, url = window.location.href) {
    let obj = parseUrl(url);
    obj.searchParams.set(key, value);
    return obj.href;
}

/**
 * 获取URL里domain
 * 举例: url = "http://jira.yqxiu.cn/browse/REFACT-17"
 * 返回 "jira.yqxiu.cn"
 */
function getUrlHost(url = window.location.href) {
    return parseUrl(url).host;
}

/**
 * 返回url的pathName
 * @param url
 */
function getPathName(url = window.location.href) {
    var obj = parseUrl(url);
    return obj.pathname;
}

/**
* http协议转换为https
* @param url
* @return {*}
*/
function url2https(url) {
    return addProtocol(url).replace(/^http:/, 'https:');
}

/**
 * 将dataURL转换为blob
 * @param {*} dataURL
 */
function dataURL2Blob(dataURL) {
    const arr = dataURL.split(',')
    const type = arr[0].match(/:(.*?);/)[1]
    const text = window.atob(arr[1]) // 将base64转换成文本
    let n = text.length
    const uint8Array = new Uint8Array(n)
    while (n--) {
        uint8Array[n] = text.charCodeAt(n)
    }
    return new Blob([uint8Array], { type })
}

/**
 * 将blob转换为dataURL
 * @param {*} blob
 */
function blob2DataURL(blob) {
    return new Promise(resolve => {
        const fileReader = new FileReader()
        fileReader.onload = e => resolve(e.target.result)
        fileReader.readAsDataURL(blob)
    })
}


/**
 * 图片压缩
 * @param  {string}   file [压缩文件]
 * @param  {object}   obj [压缩参数]
 * @param  {function} cb   [回调函数]
 * @return {string}        [返回压缩前和压缩后的格式]
 */
/* istanbul ignore next */
function photoCompress(file, obj, cb) {
    // obj = {
    //    width: 图片宽,
    //    height: 图片高,
    //    quality: 图像质量，
    //    blob: 是否转换成Blob
    //  }
    // 将以base64的图片url数据转换为Blob
    function convertBase64UrlToBlob(urlData) {
        let arr = urlData.split(',');
        let mime = arr[0].match(/:(.*?);/)[1];
        let bstr = atob(arr[1]);
        let n = bstr.length, u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], { type: mime });
    }

    // canvas 绘制图片
    function canvasDataURL(oldBase64) {
        let img = new Image();
        img.src = oldBase64;
        img.onload = function () {
            let that = this;
            // 默认按比例压缩
            let w = that.width,
                h = that.height,
                scale = w / h;
            w = obj.width || w;
            h = obj.height || (w / scale);
            let quality = 0.7;  // 默认图片质量为0.7
            //生成canvas
            let canvas = document.createElement('canvas');
            let ctx = canvas.getContext('2d');
            // 创建属性节点
            let anw = document.createAttribute('width');
            anw.nodeValue = w;
            let anh = document.createAttribute('height');
            anh.nodeValue = h;
            canvas.setAttributeNode(anw);
            canvas.setAttributeNode(anh);
            ctx.drawImage(that, 0, 0, w, h);
            // 图像质量
            if (obj.quality && obj.quality <= 1 && obj.quality > 0) {
                quality = obj.quality;
            }
            // quality值越小，所绘制出的图像越模糊
            let base64 = canvas.toDataURL('image/jpeg', quality);
            // 回调函数返回base64的值
            if (obj.blob) {
                cb && cb(convertBase64UrlToBlob(base64), convertBase64UrlToBlob(oldBase64))
            } else {
                cb && cb(base64, oldBase64);
            }
        }
    }

    // 读取图片的base64格式
    let ready = new FileReader();
    ready.readAsDataURL(file);
    ready.onload = function () {
        let re = this.result;
        canvasDataURL(re)
    }
}